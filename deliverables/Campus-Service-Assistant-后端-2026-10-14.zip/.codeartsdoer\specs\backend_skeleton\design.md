# 后端骨架（backend_skeleton）技术设计

> 依据：`.codeartsdoer/specs/backend_skeleton/spec.md`（需求规格）、`docs/api.md`（前后端唯一权威契约）、《校园办事小秘书实施方案》第六章目录规划与第3周计划
> 技术栈：Python 3.12 + FastAPI + Pydantic v2 + Pytest（骨架阶段无数据库、无 SQLAlchemy 依赖）
> 编制日期：2026-10-08

---

# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

本任务为**全新增组件**：仓库当前无 `backend/` 目录（`docs/api.md` §0 已确认后端"尚未实现"）。存量侧可供对齐与复用的只有：前端已实现的契约消费端、代理/反代链路配置、密钥忽略规则与容器编排约定。

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 密钥不入库：`.env` 不进版本库 | `.gitignore` 已忽略 `.env`、`.env.*`，并显式放行 `.env.example` / `.env.sample` 样例入库 | `.gitignore:32-36` | 100% |
| 开发环境 `/api` → 8000 端口转发链路 | Vite dev server 已配置 `/api` 代理，目标 `http://localhost:8000`（`changeOrigin: true`） | `frontend/vite.config.ts:10-12` | 100% |
| 生产环境 `/api` → `backend:8000` 反代链路 | Nginx 已配置 `location /api/` 反代 `http://backend:8000$request_uri`（保留完整路径） | `frontend/nginx.conf:23-33` | 100% |
| 健康检查消费端 | 前端 `client.ts` 已按契约定义全部类型与 `checkHealth()` 调用函数 | `frontend/src/api/client.ts` | 100% |
| 配置环境变量约定 | docker-compose backend 注释段已约定环境变量名：`AGENTARTS_API_KEY`（必填）、`DATABASE_URL`（含缺省值） | `docker-compose.yml:24-37` | 75% |

**匹配度判定依据**：

- 100% 项：存量规则/配置已存在，且与 spec 要求（spec 4.3.2、4.5.2、5.1.1 规则 3）逐字一致；骨架无需改动即可被其约束，直接受益。
- 75% 项（编排约定）：环境变量**名**已定，但存在三点差异：(a) backend 段处于注释状态，且本任务明确不启用、不修改 compose（spec 1.4.7）；(b) 装载方（配置代码）完全缺失；(c) compose 的 `:?` 强制必填语义与 spec 5.1.3 场景 3"本地缺密钥以占位值启动"存在语义冲突，需由配置缺省值设计吸收（见 1.1.2）。

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| Python 工件不入库 | `.gitignore` 覆盖 node_modules、构建产物、密钥/证书、凭据等前端生态 | 差异：**无 Python 专属忽略项**。骨架交付后 `__pycache__/`、`*.pyc`、`.pytest_cache/`、`.venv/` 会作为未跟踪文件出现在工作区，污染版本库 | 在 `.gitignore` 追加"Python"分组（`__pycache__/`、`*.py[cod]`、`.pytest_cache/`、`.venv/`、`venv/`），**不改动任何既有规则**，无兼容性风险 |
| 配置缺省值与编排注入的语义衔接 | compose 注释约定 `AGENTARTS_API_KEY: ${AGENTARTS_API_KEY:?请在 .env 中设置}`（强制必填） | 差异：编排侧要求密钥**必填**才能启动容器；而 spec 5.1.3 场景 3 要求**本地无密钥也能以占位值启动**并正常响应健康检查 | 两层职责分离：骨架配置层将 `AGENTARTS_API_KEY` 内置缺省定为空占位字符串（本地开箱即用，spec 5.1.1 EARS b）；"强制必填"语义留给未来编排层 `:?` 语法保证。骨架阶段零改动，未来启用容器化时语义自然衔接 |
| `.env.example` 样例文件 | `.gitignore` 已放行 `.env.example` 入库，但该文件**尚不存在** | 差异：忽略规则就绪而样例缺失，开发者无配置参考，易出现漏配或误提交真实密钥 | 在仓库根新建 `.env.example`，列出全部 4 个配置项及安全占位值（与 2.1.2 配置表一致），绝不包含真实密钥 |

### 1.1.3 需要新增的功能或接口

按业务模块分组（目录命名遵循实施方案第六章 `backend/` 规划）：

**分组 A：应用入口模块（`backend/app/main.py`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|---|---|---|---|---|
| `create_app` 应用工厂 | `Settings`（可选，缺省内部装载） | 装配完成的 FastAPI 实例 | 挂载健康检查路由、注册统一异常处理器 | 分组 B、C、D |
| 模块级 `app` 实例 | 工厂产物 | 可被 `uvicorn app.main:app` 加载的对象 | 与未来容器化启动方式（compose backend 段）兼容 | 本分组 |
| 本地启动入口（`python -m app.main`） | 环境变量 / `.env` | uvicorn 监听 8000 端口 + 控制台就绪信息 | 装载配置 → 创建应用 → 启动监听；配置非法时输出可读错误退出 | 分组 B |

**分组 B：核心配置模块（`backend/app/core/config.py`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|---|---|---|---|---|
| `Settings` 配置类 | 环境变量（优先）、`.env` 文件 | 类型安全的配置对象（4 个字段，见 2.1.2 配置表） | pydantic-settings 装载 + 强类型校验 + 安全内置缺省值 | pydantic-settings |
| `get_settings` 单例访问 | 无 | 进程级唯一 `Settings` 实例 | `lru_cache` 缓存，重复调用零开销 | 本分组 |

**分组 C：健康检查路由（`backend/app/api/health.py`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|---|---|---|---|---|
| `GET /api/health` | 无参数、无请求体、匿名访问 | HTTP 200 + `{"status": "ok"}`（`application/json; charset=utf-8`） | 固定只读响应，不触碰数据库/云服务/文件系统 | 响应模型（2.3.2） |

**分组 D：统一错误响应（`backend/app/core/errors.py`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|---|---|---|---|---|
| 统一异常处理器 | 404 / 405 / 422 / 500 异常 | `{"error": {"code", "message"}}` 统一错误体 | 静态映射表：状态码 → 错误码 → 安全文案，不动态拼接异常信息 | 无 |

**分组 E：交付物与工具链（`backend/` 根与仓库根）**

| 功能点 | 位置 | 说明 |
|---|---|---|
| 运行时依赖清单 | `backend/requirements.txt` | `fastapi`、`uvicorn`、`pydantic-settings` |
| 测试依赖清单 | `backend/requirements-dev.txt` | `pytest`、`httpx`（TestClient 底层依赖） |
| 测试发现配置 | `backend/pytest.ini` | 指定测试目录与用例文件模式 |
| 环境变量样例 | 仓库根 `.env.example` | 全部配置项占位值，不含真实密钥（`.gitignore` 已放行） |
| 测试套件 | `backend/tests/` | `conftest.py`、`test_health.py`、`test_config.py` |

依赖关系总览：`main.py` → `api/health.py` + `core/config.py` + `core/errors.py`；`api/health.py` 不依赖 `core/config.py`（健康检查不读配置，仅响应模型约束）；`tests/` → `main.py`（经 `create_app` 构建测试实例）。

## 1.2 存量功能详细分析

### 1.2.1 前端契约消费端（`frontend/src/api/client.ts`）

- **接口契约**：`checkHealth()` 发起 `GET /api/health`，期望 200 + `{"status": "ok"}`；前端请求超时 8 秒、超时不自动重试（契约 §1.1）。
- **业务规则**：`checkHealth` 用于联调探测与部署自测（`frontend/docs/deploy.md` §6），前端据此判断后端可达性。
- **扩展点**：前端按 `error.code` / `error.message` 解析错误并构造 `ApiError(status, code)`（契约 §2.1）——这构成对后端**错误体格式的硬约束**，是 5.2.1 决策点的关键判定依据。
- **约束**：若后端返回框架默认错误体 `{"detail": "Not Found"}`，前端读取 `error.message` 得到 `undefined`，表现为静默的文案异常而非显式错误，联调排查成本高。

### 1.2.2 Vite 代理（`frontend/vite.config.ts:10-12`）

- **接口契约**：`/api` 前缀请求代理到 `http://localhost:8000`，`changeOrigin: true`。
- **业务规则**：代理按前缀匹配且**保留 `/api` 前缀原样转发**——后端收到的请求路径自带 `/api` 前缀，因此路由必须注册在 `/api` 路径下，而非裸路径 `/health`。
- **扩展点**：无。
- **约束**：后端必须监听 **8000 端口**（spec 4.5.2），否则联调阶段全部请求 502/ECONNREFUSED。

### 1.2.3 Nginx 反代（`frontend/nginx.conf:23-33`）

- **接口契约**：`location /api/` → `http://backend:8000$request_uri`（`$request_uri` 保留完整路径含 `/api` 前缀），与 Vite 代理行为一致。
- **业务规则**：`proxy_read_timeout 30s`；生产环境前后端同域，无需 CORS（契约 §1.3）。
- **扩展点**：无。
- **约束**：上游服务名必须是 `backend`（compose 服务名，spec 领域术语）；本任务不修改该文件与 compose，但骨架的端口与路径设计必须满足其转发语义。

### 1.2.4 密钥忽略规则（`.gitignore:32-36`）

- **业务规则**：`.env` 与 `.env.*` 全部忽略，`!.env.example` / `!.env.sample` 显式放行样例文件。
- **扩展点**：`.env.example` 可安全入库，作为新成员的配置参考。
- **约束**：骨架新建的 `.env.example` 只能含占位值（如 `AGENTARTS_API_KEY=` 留空或 `your-api-key-here` 样式注释），不得写入任何真实云密钥（spec 4.3.1）。

### 1.2.5 容器编排约定（`docker-compose.yml:24-37`，注释状态）

- **业务规则**：backend 服务以 `./backend` 为构建上下文、`expose 8000`、`restart: unless-stopped`、注入 `AGENTARTS_API_KEY` 与 `DATABASE_URL`（后者缺省 `mysql+pymysql://app:app@db:3306/campus`）。
- **扩展点**：未来启用时**零改动兼容**的三个前提——后端可被 uvicorn 以 `app.main:app` 加载、监听 8000 端口、环境变量名与 compose 注释段严格一致。
- **约束**：本任务不修改 compose（spec 1.4.7），不提供 Dockerfile；但骨架的模块布局与依赖清单必须使上述三个前提天然成立。

---

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
skinparam componentStyle rectangle

actor "后端开发者\n（成员三）" as Dev
rectangle "前端应用\nVue 3 + Vite (:5173)" as FE
rectangle "Docker Compose 编排\n（backend 段计划中）" as Compose
rectangle "Git 版本库" as Git

rectangle "后端骨架 (backend/)\nuvicorn 监听 :8000\nGET /api/health" as BE #D6EAF8

Dev --> BE : python -m app.main 启动（一次性）\n环境变量 / .env 配置装载
FE --> BE : GET /api/health（HTTP）\n开发经 Vite 代理 / 联调低频\n生产经 Nginx 反代
Compose --> BE : ./backend 构建上下文 +\nAGENTARTS_API_KEY / DATABASE_URL 注入\n（未来启用，一次性）
BE --> Git : 源码提交（.env 被忽略，密钥不入库）
@enduml
```

交互说明：运行期唯一稳定交互是前端对 `GET /api/health` 的 HTTP 请求（联调低频）；启动与配置装载为一次性事件；生产链路（Nginx → `http://backend:8000`）与开发链路（Vite 代理 → `localhost:8000`）目标端口一致，骨架对两者无感知差异。

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
left to right direction
skinparam componentStyle rectangle

package "backend/app" {
  component "main.py\ncreate_app() 应用工厂\n模块级 app 实例\n__main__ 本地启动入口" as Main
  component "api/health.py\n健康检查路由\nAPIRouter(prefix=/api)" as Health
  component "core/config.py\nSettings 配置类\nget_settings() 单例" as Config
  component "core/errors.py\n统一错误响应构造\n状态码 → 错误码 → 安全文案" as Errors
}

package "backend/tests" {
  component "conftest.py +\ntest_health.py +\ntest_config.py" as Tests
}

Main --> Health : 挂载路由（启动时 1 次）
Main --> Errors : 注册处理器（启动时 1 次）
Main --> Config : 装载配置（启动时 1 次）
Tests --> Main : create_app() 构建测试实例（每用例）
@enduml
```

**模块职责**：

| 模块 | 职责 | 依赖方向 |
|---|---|---|
| `main.py` | 应用装配唯一入口：工厂、路由挂载、异常处理器注册、本地启动 | → api、core |
| `api/health.py` | 健康检查路由：固定只读响应 | → 响应模型（无外部依赖） |
| `core/config.py` | 配置装载：环境变量 / `.env` → 强类型配置对象 | → pydantic-settings |
| `core/errors.py` | 统一错误体构造：静态映射，防泄露 | 无 |
| `tests/` | 自动化测试：健康检查 + 配置装载 + 错误体 | → main（经工厂） |

**配置项及取值策略**（对齐 spec §6.2，环境变量名与 compose 注释段严格一致）：

| 配置项 | 环境变量 | 类型 | 内置缺省值 | 取值策略 |
|---|---|---|---|---|
| 监听端口 | `APP_PORT` | int | `8000` | 契约与编排约定端口；非数字 → 启动失败并输出可读错误 |
| 运行环境标识 | `APP_ENV` | Literal["local", "production"] | `local` | 原型阶段仅两态（spec 6.2.2"待定项"在此定稿），防过度设计；非法值 → 启动失败 |
| 数据库连接串 | `DATABASE_URL` | str | `mysql+pymysql://app:app@db:3306/campus` | 本阶段仅装载不使用；占位缺省与 compose 注释段默认值一致 |
| AgentArts API Key | `AGENTARTS_API_KEY` | str | `""`（空占位） | 本阶段仅装载不使用；真实密钥只来自环境变量，绝不入代码/版本库 |

### 2.1.3 实现设计文档

**1. 启动流程（活动图）**

```plantuml
@startuml
start
:python -m app.main\n（本地开发）或 uvicorn app.main:app（容器/生产）;
:get_settings() 装载配置\n优先级：环境变量 > .env > 内置缺省值;
if (配置校验通过？) then (是)
else (否)
  :输出单行可读配置错误说明\n（不含堆栈）并退出;
  stop
endif
:create_app()\n挂载 /api/health 路由\n注册统一异常处理器;
:uvicorn 监听 settings.app_port;
:控制台输出就绪信息\n（uvicorn 默认日志含监听地址与端口）;
:服务就绪，GET /api/health 可响应;
stop
@enduml
```

异常分支说明（对齐 spec 5.1.3）：

- **配置值非法**：pydantic-settings 类型校验失败（如 `APP_PORT=abc`）→ 启动入口捕获 ValidationError，输出单行可读错误后以非零退出码退出，不输出堆栈。
- **端口被占用**：uvicorn 绑定失败时框架自身已输出可读的端口冲突错误并退出（框架默认行为已满足 spec 要求，骨架不重复处理）。
- **密钥缺失**：`AGENTARTS_API_KEY` 未设置时以空占位值启动，健康检查不受影响（spec 5.1.3 场景 3）。

**2. 配置装载流程**

- **优先级**：环境变量 > `.env` 文件（`model_config` 指定 `env_file=".env"`）> 代码内置安全缺省值（spec 5.1.1 EARS a/b）。
- **强类型**：4 个配置项全部显式类型（int / str / Literal），禁止无类型散装读取；`Literal` 约束 `APP_ENV` 防非法枚举值静默通过。
- **开箱即用**：`.env` 不存在时以缺省值成功装载（pydantic-settings 对缺失 env_file 静默忽略），满足 spec 5.1.1 EARS b"安全内置缺省值"。
- **密钥语义分离**：骨架缺省空占位（本地可启动）与未来编排层 `:?` 强制必填（容器化不白启动）两层各司其职（见 1.1.2）。

**3. 统一错误响应设计（含决策点裁决）**

【决策点】spec 5.2.1 规则 5：未定义路径的 404 错误体，是沿用框架默认 `{"detail": "Not Found"}`，还是骨架阶段即实现契约 §2.1 的统一错误体？

> **决策：骨架阶段即实现统一错误响应结构。**

理由：

1. **契约权威性**：`docs/api.md` 是唯一权威契约，§2.1 明确"所有 4xx/5xx 响应统一为 `{"error": {code, message}}`"，无骨架例外条款。
2. **前端已硬依赖该结构**：`client.ts` 按 `error.code` / `error.message` 解析（契约 §2.1）；框架默认 `{"detail": ...}` 会使前端解析出 `undefined`，联调时表现为静默文案异常，排查成本远高于实现成本。
3. **实现成本极低**：集中一个异常处理器（纯静态映射，无任何业务代码），不违背"最简单起步"原则——省下的几行代码换来的是联调期排查成本。
4. **避免中途返工**：若推迟，后续业务接口接入时错误格式需中途切换，前端已按契约开发完毕，切换引入联调混乱与回归测试负担。
5. **安全性集中收敛**：统一处理器是错误脱敏的唯一收口（不泄露堆栈、SQL、内部主机名、密钥），满足 DFX 4.3.4；越早建立收口，后续业务异常路径越不容易遗漏脱敏。

错误码映射表（spec 5.2.1 EARS a + 契约 §2.3）：

| 触发条件 | HTTP 状态码 | `error.code` | `error.message`（安全文案） |
|---|---|---|---|
| 请求未定义路径 | 404 | `INVALID_REQUEST` | 资源不存在 |
| 请求方法不支持（如 POST /api/health） | 405 | `INVALID_REQUEST` | 请求方法不支持 |
| 请求参数校验失败 | 422 | `INVALID_REQUEST` | 请求参数校验失败 |
| 未捕获异常兜底 | 500 | `INTERNAL_ERROR` | 服务内部错误，请稍后重试 |

补充说明：

- **405**：FastAPI 路由对未注册方法默认返回 405，经统一处理器包装错误体即可满足 spec 5.2.1 规则 4，无需额外路由逻辑。
- **422**：骨架阶段健康检查无入参，422 实际不会触发；一并注册是因边际成本为零，且保证未来业务接口上线前错误格式已统一（契约 §2.2 将 422 列为 FastAPI 默认校验行为）。
- **文案来源**：`error.message` 全部来自静态映射表，禁止动态拼接异常信息 / exception 类名 / 内部路径（防泄露，spec 4.3.4）。
- **响应头**：错误体与成功响应共用同一媒体类型常量（见下节）。

**4. 健康检查设计**

- **纯只读、无外部依赖**：不读配置之外的服务状态，不触碰数据库/云服务/文件系统（spec 5.2.1 规则 3）——该约束同时保证未来接入 MySQL 后健康检查**仍保持固定响应结构**（DFX 4.2.1），不会因数据库不可用而失败。
- **响应体**：固定 `{"status": "ok"}`，由 Pydantic 模型（`status: Literal["ok"]`）约束序列化，响应体不含任何其他字段（spec 6.1）。
- **Content-Type**：显式 `"application/json; charset=utf-8"`。**注意点**：FastAPI 默认 JSONResponse 的 Content-Type 为 `application/json`（不带 charset 参数），为满足 DFX 4.5.3 与契约 §1.1，成功与错误响应统一以显式媒体类型构造 JSON 响应（同一常量收敛，避免散落）。
- **幂等**：重复调用任意次数返回相同结果（spec 5.2.1 EARS c）。

**5. 可扩展性设计（为后续任务预留挂载点）**

| 扩展方向 | 挂载点 | 骨架改动量 |
|---|---|---|
| 业务路由（/api/service-items、/api/chat/messages 等） | `create_app` 统一挂载 APIRouter；后续以独立路由模块（`app/api/chat.py` 等）按实施方案第六章归位 | 零结构改动，仅增挂载行 |
| 配置项扩展（LLM 超时、限流阈值等） | `Settings` 增量添加字段，缺省值策略不变 | 仅增字段 |
| 服务层/数据层 | `services/`、`models/`、`db/` 目录由对应任务创建，骨架不预建空壳（spec 5.3.1 规则 1） | 无 |
| 容器化 | `app.main:app` 可被 uvicorn 直接加载 + 依赖清单完整 + 监听 8000，未来启用 compose backend 段零改动可构建 | 无 |

**6. 状态机与事务设计说明**

- **无状态机**：服务为无状态 HTTP 服务，健康检查无状态流转；配置装载后在进程内为不可变单例（唯一"状态"是进程配置，无流转场景）。
- **无事务设计**：骨架不连接数据库，无数据一致性场景（后续数据库任务再行设计）。

## 2.2 接口设计

### 2.2.1 总体设计

接口按层次分两类：**HTTP 对外接口**（受 `docs/api.md` 契约约束，稳定）与 **Python 内部接口**（模块间契约，随模块演进）。无接口继承体系——功能单一，不引入抽象基类。

| 接口 | 层次 | 类型 | 稳定性 | 说明 |
|---|---|---|---|---|
| `GET /api/health` | HTTP 对外 | REST | 稳定 | 唯一对外接口，契约 §4.1 |
| 统一错误响应（404/405/422/500） | HTTP 对外 | REST | 稳定 | 契约 §2.1 统一错误体 |
| `create_app(settings)` | Python 内部 | 工厂函数 | 稳定 | 应用装配唯一入口 |
| `get_settings()` | Python 内部 | 工厂函数 | 稳定 | 配置单例访问 |
| `register_error_handlers(app)` | Python 内部 | 模块函数 | 稳定 | 异常处理器注册（由工厂调用） |

**变更策略**：HTTP 接口字段增删必须同步 `docs/api.md` 并写入其变更记录（契约头部规则）；内部接口新增参数一律带安全缺省值，保持调用方兼容。

**测试策略**：HTTP 层行为（健康检查、错误体、405）经 httpx TestClient 断言；配置装载行为（缺省值、环境变量覆盖、非法值）经 `get_settings` 直测；密钥零泄露经代码静态检查 + `.env.example` 占位值评审保障。

### 2.2.2 接口清单

#### 2.2.2.1 GET /api/health（HTTP 对外）

```text
GET /api/health
→ 200 OK
  Content-Type: application/json; charset=utf-8
  {"status": "ok"}
```

- **业务说明**：联调探测与部署自测的唯一入口；前端 `checkHealth()`（契约 §4.1）与部署文档 §6 消费。
- **前置条件**：服务进程已启动并监听 8000 端口；无认证要求（匿名访问，spec 5.2.1 规则 2）。
- **后置条件**：无任何服务状态变化（纯只读，可幂等重复调用）。
- **异常映射**：
  - 非 GET 方法（POST/PUT/DELETE 等）→ 405 + `{"error": {"code": "INVALID_REQUEST", "message": "请求方法不支持"}}`
  - 服务未启动 → 无响应（前端产生本地 `TIMEOUT` / `NETWORK_ERROR`，不属本组件异常映射，契约 §2.4）
- **调用示例**（实际命令）：

```powershell
curl http://localhost:8000/api/health
# 期待输出：{"status":"ok"}
```

#### 2.2.2.2 create_app（Python 内部，应用工厂）

```python
def create_app(settings: Settings | None = None) -> FastAPI: ...
```

- **业务说明**：唯一的应用装配入口——装载配置（缺省时内部调用 `get_settings`）、挂载 `/api` 前缀健康路由、注册统一异常处理器。
- **前置条件**：无 I/O 副作用；`settings` 为 None 时内部装载。
- **后置条件**：返回的 FastAPI 实例已可响应 `GET /api/health` 与统一错误体；每次调用返回独立实例（测试隔离）。
- **异常映射**：配置校验失败时由 `get_settings` 抛出 ValidationError，工厂不捕获（交由启动入口转译为可读错误）；调用方传入非法 Settings 时同样上抛。
- **调用示例**（`backend/tests/conftest.py` 的实际用法）：

```python
from fastapi.testclient import TestClient
from app.main import create_app

client = TestClient(create_app())
```

#### 2.2.2.3 get_settings（Python 内部，配置单例）

```python
@lru_cache
def get_settings() -> Settings: ...
```

- **业务说明**：进程级单例访问配置；装载顺序为环境变量 > `.env` > 内置缺省值（spec 5.1.1 EARS a/b）。
- **前置条件**：无（`.env` 不存在时以缺省值成功返回）。
- **后置条件**：首次调用后配置在进程内固化，重复调用零开销。
- **异常映射**：环境变量类型非法（如 `APP_PORT=abc`）→ ValidationError 上抛，由启动入口输出单行可读错误（不含堆栈）后以非零码退出（spec 5.1.3 场景 1）。
- **调用示例**（`backend/app/main.py` 本地启动入口的实际用法）：

```python
settings = get_settings()
uvicorn.run(app, host="0.0.0.0", port=settings.app_port)
```

#### 2.2.2.4 register_error_handlers（Python 内部，异常处理器注册）

```python
def register_error_handlers(app: FastAPI) -> None: ...
```

- **业务说明**：为 app 注册 404/405/422/500 统一错误体处理器（映射表见 2.1.3 §3）。
- **前置条件**：app 为尚未注册处理器的 FastAPI 实例（装配顺序由 `create_app` 保证）。
- **后置条件**：任何 4xx/5xx 响应均为 `{"error": {code, message}}`，Content-Type 携带 charset。
- **异常映射**：处理器内部不抛异常；文案来自静态映射表，不动态拼接异常信息（防泄露）。
- **调用示例**：由 `create_app` 内部调用，无外部直接调用场景；其行为经 HTTP 层测试验证（请求未定义路径，断言 404 + 错误体结构）。

## 2.3 数据模型

### 2.3.1 设计目标

- **支持场景**：覆盖 spec §6 数据约束的全部三个对象——①健康检查响应体 ②统一错误响应体 ③服务配置装载。
- **无持久化**：骨架阶段无数据库（spec 1.4.2），配置项仅装载进内存，不落库、不写文件；后续 MySQL 接入为独立任务。
- **性能与容量**：配置对象进程级单例（内存占用可忽略）；响应体固定小体积 JSON，无容量目标（spec 4.1.3 骨架阶段不设吞吐指标）。
- **兼容策略**：配置项名与 docker-compose 注释段环境变量名严格一致（`AGENTARTS_API_KEY` / `DATABASE_URL`），未来编排启用零改动衔接；响应体结构与契约 §4.1 / §2.1 逐字段一致。

### 2.3.2 模型实现

```plantuml
@startuml
class Settings {
  app_env: Literal["local", "production"]
  app_port: int
  database_url: str
  agentarts_api_key: str
}

class HealthResponse {
  status: Literal["ok"]
}

class ErrorResponse {
  error: ErrorBody
}

class ErrorBody {
  code: str
  message: str
}

ErrorResponse "1" *-- "1" ErrorBody : 组成

note right of Settings
  来源：环境变量 / .env / 内置缺省值
  生命周期：进程启动时构造 1 次
  进程退出即销毁（单例）
end note

note right of HealthResponse
  生命周期：请求级即时构造，即弃
  不缓存、不落库
end note
@enduml
```

**关系与约束说明**：

- **ErrorResponse 组成 ErrorBody（1:1）**：每个错误响应恰好包含一个错误体；`code` 取值限于契约 §2.3 错误码表（骨架阶段仅涉及 `INVALID_REQUEST` 与 `INTERNAL_ERROR`），`message` 取自静态安全文案映射。
- **Settings 与两个响应模型之间无关联**：配置对象不进入任何响应体——这是安全约束（spec 6.1"响应体不得额外携带内部信息"、4.3.4"错误不泄露密钥"）在模型层的体现，`database_url` / `agentarts_api_key` 等敏感字段在类型上就无法被响应序列化路径触及。
- **对象创建与销毁策略**：`Settings` 进程启动时构造一次（`lru_cache` 单例），进程退出销毁；`HealthResponse` / `ErrorResponse` 每次请求即时构造、即弃，无缓存。
- **持久化策略**：无持久化。配置的唯一持久化形态是开发者本地 `.env`（不入库，`.gitignore` 已覆盖）与仓库根 `.env.example`（占位样例，可入库）；三类对象均为内存对象。