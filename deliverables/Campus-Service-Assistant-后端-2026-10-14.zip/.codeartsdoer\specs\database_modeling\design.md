# 数据库建模（database_modeling）技术设计

> 依据：`.codeartsdoer/specs/database_modeling/spec.md`（需求规格）、`docs/api.md`（前后端唯一权威契约，§3 数据模型 / §3.5 标识符规范 / §4.6 知识来源响应字段）、《校园办事小秘书实施方案》第九章「数据库设计」/ 第六章目录规划
> 技术栈（上游既定）：Python 3.11.9（本机实际版本）+ SQLAlchemy 2（同步）+ Alembic + PyMySQL + MySQL 8.x
> 编制日期：2026-10-10

---

# 一、需求与存量功能关系分析

**任务性质**：在既有后端骨架（backend_skeleton，已交付）之上新增持久化底座，属**扩展型新增**——骨架已提供配置装载、测试体系与工程约定，本任务在其上叠加 SQLAlchemy 模型层、数据库会话管理、Alembic 迁移与演示数据脚本。仓库当前无 `backend/app/models/`、`backend/app/db/`、`backend/alembic/`、`scripts/` 等目录，四张表相关交付物全部待建。

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 数据库连接串配置装载（spec 5.2.1 规则 3：环境变量 > `.env` > 内置缺省） | `Settings` 已含 `database_url` 字段，内置缺省 `mysql+pymysql://app:app@db:3306/campus`，与 compose db 段缺省值逐字一致 | `backend/app/core/config.py:19` | 100% |
| `.env` 口令不入库（spec 4.3.2） | `.gitignore` 已忽略 `.env` / `.env.*`，显式放行 `.env.example` / `.env.sample` 样例入库 | `.gitignore:32-36` | 100% |
| Pytest 测试命令与用例发现（spec 4.4.3） | `pytest.ini` 已配置 `testpaths = tests`、`test_*.py` 模式；`requirements-dev.txt` 已含 pytest / httpx | `backend/pytest.ini:1-3`、`backend/requirements-dev.txt:1-2` | 100% |
| 配置隔离测试钩子（可复用的测试约定） | `conftest.py` 已有 `clear_settings_cache` autouse fixture（每用例前后清 `lru_cache`），保证配置装载测试互不污染 | `backend/tests/conftest.py:13-16` | 100% |
| compose db 段连接约定（spec 3.2 外部系统） | db 段注释已约定 `mysql:8` 镜像、`campus` 库名、`app` 用户、口令经 `.env` 注入 | `docker-compose.yml:39-49` | 100%（约定侧；段本身保持注释，spec 1.4.6 明确不启用） |
| 运行时 Python 依赖管理体系 | `requirements.txt` / `requirements-dev.txt` 双清单模式已建立 | `backend/requirements.txt:1-3` | 75% |

**匹配度判定依据**：

- 100% 项：存量代码/规则与 spec 对应条款逐字一致或直接可复用，本任务零改动受益——连接串装载链是本任务 `alembic/env.py` 与 `db/session.py` 的直接上游（spec 5.2.1 规则 3 明确要求"与骨架 `Settings` 一致"）。
- 75% 项（依赖清单体系）：清单**模式**已建立，但本任务所需的数据库依赖条目缺失，属"体系就绪、条目待补"，扩展方式见 1.1.2。

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 运行时依赖完备（spec 5.4.3 异常场景 2） | `requirements.txt` 仅 fastapi / uvicorn / pydantic-settings；`requirements-dev.txt` 仅 pytest / httpx | 差异：无 SQLAlchemy / Alembic / PyMySQL；本机 `backend/.venv` 三者均未安装。**另有一个隐性缺口**：MySQL 8 默认认证插件为 `caching_sha2_password`，PyMySQL 连接真实 MySQL 8 时需要 `cryptography` 包支持，缺失将导致冒烟阶段连接报错 | `requirements.txt` 追加 `sqlalchemy>=2.0`、`alembic`、`pymysql`、`cryptography` 四条，**不改动任何既有条目**；`requirements-dev.txt` 不重复（约定开发环境两清单一起装） |
| 测试 fixtures | `tests/conftest.py` 仅应用层 fixtures（`client`） | 差异：无数据库测试 fixture——内存 SQLite engine、迁移建表、会话供给均缺失 | 在既有 `conftest.py` 增量追加数据库 fixtures，既有 `client` / `clear_settings_cache` fixture 原样保留（兼容性无风险） |
| MySQL 专属行为验证载体 | 无（骨架阶段无数据库） | 差异：utf8mb4 字符集落库、原生 ENUM DDL、`caching_sha2_password` 认证、连接字符集等 MySQL 专属行为不属 SQLite 自动化测试覆盖范围，需独立验证入口 | 新增文档化冒烟清单 `backend/docs/mysql-smoke-checklist.md`（见 2.1.3 决策 1），列出检查项与命令形态，供真实 MySQL 可用时手动执行 |

### 1.1.3 需要新增的功能或接口

按业务模块分组（目录命名遵循实施方案第六章 `backend/` 规划；其中会话模型文件为 spec 4.4.1 明确要求的补齐项）：

**分组 A：ORM 模型模块（`backend/app/models/`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|---|---|---|---|---|
| `base.py` 声明基类与约束命名约定 | 无 | `Base`（DeclarativeBase 子类）及其 `metadata`（含统一约束命名约定） | 为四张表提供统一声明基类；命名约定保证 Alembic autogenerate 产出稳定约束名、SQLite 批量操作可用 | SQLAlchemy 2 |
| `service_item.py` 事项模型 | `Base` | `ServiceItem` ORM 类（`service_items` 表） | 字段与约束按 spec §6.1 / 实施方案 9.1（2.3.2 列规格） | 分组 A 基类 |
| `source_document.py` 来源文档模型 | `Base` | `SourceDocument` ORM 类（`source_documents` 表） | 字段覆盖契约 §4.6 全部响应字段（spec 4.5.2）；知识状态四态枚举 | 基类、`ServiceItem` |
| `conversation.py` 匿名会话模型 | `Base` | `Conversation` ORM 类（`conversations` 表） | UUID 主键 + 匿名红线（无任何 PII 字段）；回答状态六态枚举 | 基类、`ServiceItem` |
| `feedback.py` 反馈模型 | `Base` | `Feedback` ORM 类（`feedback` 表） | 反馈原因码四态枚举（可空）+ 会话外键 | 基类、`Conversation` |
| `__init__.py` 汇总导出 | 各模型文件 | 四个模型类的统一导入出口 | 供 `alembic/env.py`（target_metadata）与后续业务层单点导入 | 分组 A 全部 |

**分组 B：数据库会话管理（`backend/app/db/session.py`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|---|---|---|---|---|
| engine 工厂 | 连接 URL（可选，缺省取 `Settings.database_url`） | SQLAlchemy `Engine`（惰性连接、pool_pre_ping、pool_recycle） | 同步引擎创建；连接参数为可靠性设计点（见 2.1.3 §7） | 分组 A 无依赖；`core/config.py` |
| session 工厂 | engine | `sessionmaker` 会话工厂 | 统一会话构造参数（`expire_on_commit=False`） | engine 工厂 |
| `get_db` 会话依赖生成器 | 无 | 请求级 `Session`（yield 交付、 finally 关闭） | FastAPI 依赖注入形态（骨架任务预留的挂载点，2.1.2 扩展表）；本任务不接入任何路由 | session 工厂 |

**分组 C：Alembic 迁移（`backend/alembic.ini` + `backend/alembic/`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|---|---|---|---|---|
| `alembic.ini` | 无 | Alembic 配置文件 | 脚本位置指向 `alembic/`；连接串**不写入 ini**（由 env.py 装载，防口令入库） | 无 |
| `alembic/env.py` | 环境变量 / `.env` / 缺省值 | 迁移执行上下文 | 复用骨架 `Settings` 装载连接串；`target_metadata` 指向 `app.models` 的 Base.metadata（spec 5.2.1 规则 3"与骨架 Settings 一致"） | 分组 A、`core/config.py` |
| `script.py.mako` | 无 | 迁移脚本模板 | Alembic 默认模板 | 无 |
| 初始迁移脚本 `versions/0001_initial_schema.py` | 模型元数据 | 四张表 + 索引 + 约束的 DDL（upgrade）；逆序 drop（downgrade） | **单迁移一次性建立全部四张表**（spec 5.2.1 规则 2a）；含 utf8mb4 与 InnoDB 方言参数（2.1.3 决策 2） | 分组 A |

**分组 D：脚本（仓库根 `scripts/`，实施方案第六章规划位置）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|---|---|---|---|---|
| `create_database.py` 幂等建库 | 连接配置（Settings 装载链） | `campus` 库（utf8mb4） | `CREATE DATABASE IF NOT EXISTS ... CHARACTER SET utf8mb4`，重复执行不报错不破坏数据（spec 5.2.1 规则 1） | `core/config.py`、PyMySQL |
| `seed_demo_data.py` 演示数据 | 已建表的数据库 | S01–S08 事项 + 配套来源 + 演示会话与反馈 | 前置检查（表就绪？）→ 单事务按稳定逻辑键 upsert（2.1.3 决策 3）→ 写入数量报告；核心函数可注入 session（可测性） | 分组 A/B、分组 C 前置 |

**分组 E：测试套件（`backend/tests/`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|---|---|---|---|---|
| `test_models.py` 模型约束测试 | 内存 SQLite | 断言结果 | 四类断言：字段齐备、唯一约束、三组枚举约束、引用完整性 + 隐私红线（spec 5.4.1 规则 3） | 分组 A、conftest fixtures |
| `test_migrations.py` 迁移测试 | 内存 SQLite | 断言结果 | upgrade → downgrade → upgrade 回环、四张表数量与版本正确、模型-迁移零漂移（compare_metadata） | 分组 C、conftest fixtures |
| `test_seed.py` 演示数据测试 | 内存 SQLite | 断言结果 | seed 幂等（两遍执行计数不变）、S01–S08 覆盖、来源地址协议校验 | 分组 D（核心函数注入测试 session） |

**分组 F：冒烟清单（`backend/docs/mysql-smoke-checklist.md`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|---|---|---|---|---|
| MySQL 冒烟清单文档 | 真实 MySQL 8.x 可用 | 逐项检查清单 | 建库 → 迁移 → seed → `alembic check` → 字符集/认证/时间抽样核验（2.1.3 决策 1、决策 2） | 分组 C/D 交付物 |

**依赖关系总览**：`models/*` → `models/base.py`；`models/base.py` → SQLAlchemy 2；`db/session.py` → `core/config.py`（复用骨架装载链，零改动）；`alembic/env.py` → `core/config.py` + `models/__init__.py`；`scripts/*` → `core/config.py` + `models/` + `db/session.py`；`tests/*` → 分组 A/B/D（经 fixtures）。**无反向依赖**：模型层不 import db 层与 api 层。

## 1.2 存量功能详细分析

### 1.2.1 Settings 配置装载链（`backend/app/core/config.py`）

- **接口契约**：`Settings`（pydantic-settings BaseSettings 子类）暴露 4 个强类型字段——`app_port: int`、`app_env: Literal["local", "production"]`、`database_url: str`、`agentarts_api_key: str`；`get_settings()` 经 `lru_cache` 提供进程级单例。
- **业务规则**：装载优先级为环境变量 > `.env` > 内置缺省值（`model_config` 指定 `env_file` 指向仓库根 `.env`，经 `PROJECT_ROOT` 由 `parents[3]` 推导）；`database_url` 内置缺省 `mysql+pymysql://app:app@db:3306/campus`，与 compose db 段缺省逐字一致。
- **扩展点**：本任务**零改动复用**——`alembic/env.py`、`db/session.py`、`scripts/*` 三处均经 `get_settings()`（或直接构造 `Settings()`）取得连接串，不再各自实现装载逻辑；`tests/conftest.py` 的 `clear_settings_cache` 模式可被数据库测试沿用。
- **约束**：连接串含口令，禁止硬编码进任何代码文件（spec 4.3.2）；`alembic.ini` 因此**不得**写入 `sqlalchemy.url`，必须由 env.py 运行时注入。

### 1.2.2 Pytest 测试体系（`backend/pytest.ini` + `tests/`）

- **接口契约**：`pytest -q`（backend/ 目录下执行）为唯一测试命令（实施方案第十二章）；用例文件模式 `test_*.py`，目录 `tests/`。
- **业务规则**：既有 `conftest.py` 以 autouse fixture 清理配置缓存，确立"每用例隔离"约定；`tests/` 为 Python 包（含 `__init__.py`）。
- **扩展点**：数据库 fixtures 按 pydantic 系约定追加进同一 `conftest.py`——`pytest.ini` 与既有 fixture 均无需改动，新增用例文件自动被 `testpaths` 收集。
- **约束**：测试不得依赖外部 MySQL 实例（决策 1）；测试数据库每用例重建（内存 SQLite 生命周期天然隔离），不依赖执行顺序。

### 1.2.3 骨架工程约定（`.codeartsdoer/specs/backend_skeleton/design.md`）

- **目录不预建空壳**：骨架 design 明确 `services/`、`models/`、`db/` 目录"由对应任务创建，骨架不预建空壳"——本任务创建 `models/` 与 `db/` 属约定内的按需交付；`services/` 仍属后续任务（spec 1.4.2），本任务**不创建**。
- **配置项名与 compose 注释段严格一致**：`DATABASE_URL` 环境变量名不改、缺省值不改——本任务所有配置消费点（env.py / session / scripts）均以 `Settings.database_url` 为唯一来源，不引入第二套配置名。
- **应用工厂挂载点预留**：骨架 design 2.1.3 §5 已为"服务层/数据层"预留挂载说明；本任务 `db/session.py` 的 `get_db` 以 FastAPI 依赖注入形态实现，与该挂载点天然衔接，但不挂载任何路由。
- **约束**：本任务不触碰 `app/main.py`、`api/health.py`、`core/errors.py`——骨架交付物保持原样。

### 1.2.4 契约消费端对表结构的隐含约束（`docs/api.md` + `frontend/src/api/client.ts`）

- **接口契约**：契约 §3.1 定义 `service_items` 表 → `ServiceItem` 响应的字段映射（`title` ← `name`、`category`、`description` 直取、`enabled` 过滤）；§4.6 定义知识来源响应的 12 个字段（`id`、`service_item_id`、`item_code`、`title`、`department`、`official_url`、`publish_date`、`effective_from`、`effective_to`、`audience`、`campus`、`status`、`version`、`reviewed_at`）。
- **业务规则**：`item_code`（S01–S08）为统一业务主键（§3.5 定稿），事项编码映射表共 8 项——`seed_demo_data.py` 的演示数据必须逐项一致。
- **扩展点**：`source_documents` 表**不需要** `item_code` 冗余列——§4.6 响应中的 `item_code` 由 `service_item_id` 关联查询 `service_items.code` 派生（spec §6.2 字段清单亦无该列）；枚举值集（知识状态四态、回答状态六态、反馈原因码四态）与契约 §3.2 / §3.3 / §3.6 逐值一致。
- **约束**：表名与列名必须与 spec §6.1–6.4 完全一致（snake_case），保证后续业务接口按契约字段映射取数时零转换（spec 4.4.4）；`comment` 列长度对齐契约 §4.5 的 ≤ 200 字；时间字段必须能还原为 ISO 8601 带时区格式（契约 §1.1）。

---

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
skinparam componentStyle rectangle

actor "后端开发者\n（成员三）" as Dev
actor "测试/验收人员" as Tester
rectangle "Docker Compose 编排\n（db 段计划中，mysql:8）" as Compose #F5F5F5
rectangle "Git 版本库" as Git #F5F5F5

rectangle "数据库建模 (backend/)\nSQLAlchemy 2 模型 × 4\nAlembic 迁移\nseed 脚本" as DM #D6EAF8
database "MySQL 数据库\n（campus 库，utf8mb4）" as DB #E8F6EF

Dev --> DM : 定义模型 / alembic upgrade / 执行 scripts\n（低频，一次性事件为主）
Tester --> DM : cd backend && pytest -q\n（SQLite 内存库，零外部依赖）
DM --> DB : 建库 / 建表 / 灌入演示数据\n（PyMySQL，同步，低频）
Compose --> DB : 提供容器化 MySQL（未来启用，一次性）
DM --> Git : 提交模型与迁移脚本\n（.env 被忽略，口令不入库）
@enduml
```

交互说明：运行期唯一持久交互是开发者经 PyMySQL 对 MySQL 的建库/迁移/灌数操作（联调阶段低频）；Pytest 验收测试全程使用 SQLite 内存库，**不触碰 MySQL**（决策 1）；生产链路（compose backend → db）本阶段不启用，连接串缺省值已与其对齐，未来启用零改动。

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
left to right direction
skinparam componentStyle rectangle

package "backend/app" {
  component "core/config.py\nSettings（骨架，零改动复用）" as Config
  package "models" {
    component "base.py\nBase + 约束命名约定" as Base
    component "service_item.py\nServiceItem" as SI
    component "source_document.py\nSourceDocument" as SD
    component "conversation.py\nConversation" as CV
    component "feedback.py\nFeedback" as FB
  }
  package "db" {
    component "session.py\nengine 工厂 / session 工厂 / get_db" as DBSession
  }
}

package "backend/alembic" {
  component "env.py\n装载 Settings.database_url\ntarget_metadata → Base.metadata" as Env
  component "versions/0001\n_initial_schema.py\n四张表 + 索引 + 约束" as Rev
}

package "scripts（仓库根）" {
  component "create_database.py\n幂等建库（utf8mb4）" as CDB
  component "seed_demo_data.py\n前置检查 + 单事务 upsert" as Seed
}

package "backend/tests" {
  component "conftest.py\n内存 SQLite fixtures\n（既有 fixture 保留）" as TF
  component "test_models.py / test_migrations.py / test_seed.py" as TS
}

SI --> Base : 声明
SD --> Base : 声明
CV --> Base : 声明
FB --> Base : 声明
Env --> Base : target_metadata（启动时 1 次）
Env --> Config : database_url 装载（启动时 1 次）
Rev --> Env : 由 alembic 装载执行
DBSession --> Config : 缺省连接串（惰性）
CDB --> Config : database_url 解析
Seed --> DBSession : 取得 session（每执行 1 次）
TS --> TF : 注入 fixtures（每用例）
TS --> SI : 导入模型与 seed 核心函数
@enduml
```

**模块职责**：

| 模块 | 职责 | 依赖方向 |
|---|---|---|
| `models/base.py` | 统一声明基类 + 约束命名约定（Alembic autogenerate 稳定性） | → SQLAlchemy |
| `models/{四表}.py` | 四张表的字段、约束、枚举定义（唯一定义点） | → base |
| `db/session.py` | 同步 engine/会话工厂/`get_db` 依赖生成器 | → core/config（装载链复用） |
| `alembic/env.py` | 迁移上下文：连接串装载 + metadata 注册 | → core/config、models |
| `alembic/versions/` | 版本化 DDL 脚本（初始迁移一张口） | 由 env.py 装载 |
| `scripts/create_database.py` | 幂等建库（含 charset） | → core/config、PyMySQL |
| `scripts/seed_demo_data.py` | 演示数据：前置检查 + 单事务 upsert + 数量报告 | → models、db |
| `tests/` | 四类断言 + 迁移回环 + 漂移检测 + seed 幂等 | → models、alembic、scripts |

**配置项及取值策略**（本任务**不新增**任何配置项，`database_url` 为唯一消费配置）：

| 配置项 | 环境变量 | 类型 | 内置缺省值 | 取值策略（本任务） |
|---|---|---|---|---|
| 数据库连接串 | `DATABASE_URL` | str | `mysql+pymysql://app:app@db:3306/campus` | 唯一消费点；经 `Settings` 装载链（环境变量 > `.env` > 缺省）取得；`alembic.ini` 不写入连接串（防口令入库，spec 4.3.2） |
| 连接字符集 | —（不新增） | — | PyMySQL 驱动内建 | 不在缺省串追加 `?charset` 参数以维持与 compose 缺省逐字一致（spec 4.5.5）；字符集保障交给建库/建表显式 utf8mb4（决策 2），连接字符集列入冒烟清单核验 |

### 2.1.3 实现设计文档

**1. ER 关系图**

```plantuml
@startuml
entity "service_items" as SI {
  * id : INT (PK, 自增)
  --
  * code : VARCHAR(8) (UNIQUE)
  * name : VARCHAR(128)
  * category : VARCHAR(32)
  * description : VARCHAR(255)
  * enabled : BOOLEAN (default true)
  * created_at / updated_at : DATETIME
}

entity "source_documents" as SD {
  * id : INT (PK, 自增)
  --
  * service_item_id : INT (FK → service_items.id)
  * title : VARCHAR(255)
  * department : VARCHAR(128)
  * official_url : VARCHAR(512)
  * publish_date / effective_from / effective_to : DATE
  * audience : VARCHAR(128)
  * campus : VARCHAR(64)
  * status : ENUM(4 态, default draft)
  * version : VARCHAR(32)
  o reviewed_at : DATE (可空)
  CHECK: effective_to >= effective_from
}

entity "conversations" as CV {
  * id : VARCHAR(36) (PK, UUID v4)
  --
  * question : TEXT
  o last_intent : VARCHAR(8) (FK → service_items.code, 可空)
  * result_status : ENUM(6 态)
  * started_at / last_message_at : DATETIME (索引 last_message_at)
}

entity "feedback" as FB {
  * id : INT (PK, 自增)
  --
  * conversation_id : VARCHAR(36) (FK → conversations.id)
  * helpful : BOOLEAN
  o reason_code : ENUM(4 态, 可空)
  o comment : VARCHAR(200) (可空)
  * created_at : DATETIME
}

SI ||--o{ SD : "1:N（RESTRICT）"
SI |o--o{ CV : "0:N（last_intent 可空，RESTRICT）"
CV ||--o{ FB : "1:N（RESTRICT）"
@enduml
```

**2. 关键设计决策裁决**（spec 5.2.1 决策点 4 及设计阶段裁决项）

**【决策 1】测试数据库选型 —— SQLite 内存库为 Pytest 主方案 + 文档化 MySQL 冒烟清单为辅助验证。**

> **裁决：采纳 spec 倾向方案——SQLite 内存库 + 真实库手动冒烟。**

理由：

1. **零环境门槛**：本机当前无 MySQL 实例（.venv 亦未装 PyMySQL），SQLite 内存库使 `cd backend && pytest -q` 无任何外部依赖即可全通过，恰好命中 spec 5.2.1 决策点验收条件 a"本机无 MySQL 实例时测试套件仍全部通过"；验收人员跑测试无需申请实例。
2. **四类断言全覆盖**：SQLite 支持唯一约束、外键（开启 `foreign_keys=ON` PRAGMA）与 CHECK 约束——spec 5.4.1 规则 3 要求的四类断言（字段齐备、唯一性、枚举、引用完整性）加隐私红线，全部可在内存库断言；`sa.Enum` 在 SQLite 上落为 `VARCHAR + CHECK`，非法值写入同样被拒绝，约束语义等价于 MySQL 严格模式下的原生 ENUM。
3. **迁移可在 SQLite 上执行**：迁移脚本中的 `mysql_engine` / `mysql_charset` 等方言参数被非 MySQL 方言静默忽略，初始迁移可对内存 SQLite programmatic 执行 upgrade → downgrade → upgrade 回环测试，迁移脚本正确性获得自动化验证。
4. **MySQL 专属行为边界清晰**：utf8mb4 落库、原生 ENUM DDL、`caching_sha2_password` 认证、连接字符集不属 SQLite 覆盖范围——以**文档化冒烟清单**（`backend/docs/mysql-smoke-checklist.md`）承载：建库 → 迁移 → seed → `alembic check` → 字符集/认证/时间抽样核验，真实 MySQL 可用时按清单逐项执行。
5. **本机 MySQL 方案落选理由**：需本机安装 MySQL 且测试引入外部实例依赖（实例未启动即全套失败），违背"测试可运行规则"的稳定性要求；原型阶段数据量小（8 事项 + 十余条来源），SQLite 与 MySQL 的引擎差异对断言结论无实质影响；异步/容器化测试基建为后续业务接口阶段再评估的过度设计。

**【决策 2】字符集选型 —— utf8mb4（建库与建表两层显式声明）。**

理由：中文内容必须可正确存取（spec 4.5.1）；utf8mb4 覆盖完整 Unicode（含中文与 emoji）；MySQL 8 默认即 utf8mb4，但**显式声明防漂移**——建库脚本带 `CHARACTER SET utf8mb4`，建表 DDL 带 `mysql_charset="utf8mb4"`（方言参数，SQLite 忽略），两层一致；连接串缺省值不加 `?charset` 参数以维持与 compose 缺省逐字一致（spec 4.5.5），连接字符集列入冒烟清单核验（`SHOW VARIABLES LIKE 'character%'`），发现异常时仅在本地 `.env` 的连接串追加参数，不改动缺省对齐约束。

**【决策 3】演示数据幂等策略 —— 按稳定逻辑键 upsert（非先清后插）。**

理由：

1. **先清后插有破坏性**：会连带删除联调期间产生的真实数据（演示库与联调库同实例），且清空反馈/会话表后无法恢复；upsert 只影响演示数据涉及的行，破坏面最小。
2. **满足幂等验收条件**：spec 4.2.3 与 5.3.1 规则 3 要求"重复执行后数据总量保持不变"——按唯一逻辑键"存在即更新、不存在即插入"天然满足。
3. **逻辑键选取**（依据各表可用唯一键）：

| 表 | 逻辑幂等键 | 选取理由 |
|---|---|---|
| `service_items` | `code` | 表上唯一约束（spec §6.1），天然逻辑键 |
| `source_documents` | `service_item_id + official_url` | 表无业务唯一列；演示数据由 seed 自控保证该组合唯一，同一来源通知的更新以 URL 定位 |
| `conversations` | 固定演示 `id`（预置固定 UUID 字符串） | 主键即逻辑键；固定 UUID 满足"非可枚举顺序数字"约束（spec 5.1.1 规则 5a），演示数据非运行时行为，固定值换取幂等 |
| `feedback` | `conversation_id` | 演示数据中每会话至多一条演示反馈，以会话定位更新 |

4. **单事务包裹**：全程一个 session 事务，任一步骤失败整体回滚不留半截数据（spec 5.3.3 异常场景 2）；实现采用跨方言的"查询-判断-插入/更新"通用模式（种子数据量小，逐条开销可忽略），使 seed 核心函数在 SQLite 测试库上可执行。

**【决策 4】匿名标识维度 —— `conversations.id`（UUID v4 主键）即匿名标识本身，不另设会话签名/匿名 token 列。**

理由：契约 §3.4 定稿 `id` 即"随机会话标识（建议 `crypto.randomUUID`，不可预测）"，§4.4 隔离查询的锚点就是该标识——同一 UUID 既是对外标识又是隔离维度，冗余列无消费方；模型层为主键设 UUID v4 默认值，保证"新会话记录被创建时即以不可预测随机标识唯一标识"（spec 5.1.1 规则 5a，禁止可枚举顺序数字）；原型阶段无认证体系，会话签名/token 的验签机制属接口层安全设计（后续任务），若后续需要更强校验，凭 Alembic 迁移增量加列即可，当前不做超前设计。

**【决策 5】反馈-会话关联校验策略 —— 数据库层外键约束（严格拒绝）。**

理由：spec §6.4 规定 `conversation_id` 必填，反馈必须携带会话标识建立业务关联（spec 5.1.1 规则 11）；引用完整性交由数据库外键保证，比应用层逐次查询校验可靠且零维护成本；严格拒绝使引用完整性测试可直接断言 `IntegrityError`（spec 5.4.1 规则 3）；原型阶段无会话清理机制，`RESTRICT` 删除策略无副作用（反馈表不随会话删除而级联，未来引入清理机制时再评估级联策略）。`seed` 演示数据先插会话后插反馈，满足外键前置。

**【决策 6】时间与时区约定 —— `DateTime(timezone=True)` 列 + 统一存 UTC + 序列化层输出带时区 ISO 8601。**

理由：契约 §1.1 要求时间戳"ISO 8601 带时区"（如 `2026-09-27T09:42:00+08:00`）；MySQL 的 DATETIME 不保留时区信息，`TIMESTAMP` 虽含时区转换行为但有 2038 上限且受会话时区变量干扰，**不选**；统一约定：所有时间列以 UTC 写入（模型层 default 自动维护），列类型声明 `timezone=True` 表达意图并在未来切换 PostgreSQL 时零改动；"还原为 ISO 8601 带时区格式输出"由后续 schema 序列化层以固定 UTC 偏移（`+00:00`）实现——UTC 亦是带时区的 ISO 8601 合法形态，联调若需 +08:00 由序列化层转换，数据层不需要变更。

**【决策 7】迁移策略 —— 单初始迁移 + 程序化回环测试 + `alembic check` 冒烟。**

理由：

1. **Alembic 初始化**：`alembic init` 于 `backend/` 下建立 `alembic/`（`env.py`、`script.py.mako`、`versions/`）与 `alembic.ini`；连接串不写入 ini，由 `env.py` 经骨架 `Settings` 装载（spec 5.2.1 规则 3，与 compose 缺省一致）；`target_metadata` 指向 `app.models` 的 Base.metadata。
2. **单迁移建全表**：初始迁移 `0001_initial_schema.py` 一次性建立全部四张表 + 索引 + 约束（spec 5.2.1 规则 2a"一次性建立全部四张表"），`downgrade` 逆序 drop，可回滚不留残留（规则 2b）。
3. **建库与建表分离**：Alembic 只管表结构不管建库——`scripts/create_database.py` 以 `CREATE DATABASE IF NOT EXISTS ... CHARACTER SET utf8mb4` 幂等建库（spec 5.2.1 规则 1a/1b），与迁移命令形成两步固定操作序列（建库 → `alembic upgrade head`），写入冒烟清单。
4. **幂等升级**：`alembic upgrade head` 对已处于最新版本的库重复执行为 no-op（Alembic 框架原生行为，spec 4.2.1 满足，不重复造轮子）。
5. **模型-迁移不漂移**：自动化测试经 Alembic `compare_metadata` 断言"以迁移建立的 schema 与模型元数据零差异"（spec 4.2.4，在 SQLite 上执行）；MySQL 侧冒烟清单纳入 `alembic check` 命令双保险。
6. **禁止手工改表**：spec 4.4.2 的红线约束，通过"迁移为唯一定义点 + 漂移检测"两条机制保障。

**3. 迁移与建库流程（活动图）**

```plantuml
@startuml
start
:读取连接配置\n（环境变量 > .env > 内置缺省，经 Settings）;
:scripts/create_database.py\n解析连接串 → 剥离库名直连 server;
if (目标库 campus 存在？) then (否)
  :CREATE DATABASE campus\nCHARACTER SET utf8mb4;
else (是)
  :跳过建库（幂等）;
endif
:alembic upgrade head\n（env.py 装载连接串与 metadata）;
if (库为空？) then (是)
  :应用初始迁移 0001\n建立四张表 + 索引 + 约束;
else (已有版本记录)
  :比对版本链\n已在最新版本 → no-op;
endif
:输出迁移结果（版本号记录在案）;
stop
@enduml
```

异常分支说明（对齐 spec 5.2.3）：

- **数据库不可达**：连接失败输出可读错误（主机/实例状态提示），错误信息不含口令（spec 4.3.4）。
- **迁移版本冲突**：版本链分叉时 Alembic 拒绝执行并报告差异，不自动改写版本记录（spec 5.2.3 场景 2）。
- **重复执行**：建库与升级均幂等静默跳过（spec 5.2.3 场景 3）。

**4. 演示数据初始化流程（活动图）**

```plantuml
@startuml
start
:读取连接配置（Settings 装载链）;
:创建同步 session;
if (四张表已存在？) then (否)
  :输出可读提示\n「请先执行建库与 alembic upgrade head」;
  :终止（非零退出码）;
  stop
else (是)
endif
partition "单事务 upsert（异常整体回滚）" {
  :写入/更新 S01–S08 事项\n（按 code upsert，8 条与契约 §3.5 逐项一致）;
  :写入/更新演示来源文档\n（每事项 ≥1 条，example.edu.cn，\n按 service_item_id + official_url upsert，\n知识状态覆盖 draft/verified/expired/conflict）;
  :写入/更新演示会话\n（固定演示 UUID，六态取代表性子集）;
  :写入/更新演示反馈\n（关联演示会话，\n按 conversation_id upsert）;
}
:提交事务;
:报告各表写入/更新数量\n（不输出任何口令与 PII）;
stop
@enduml
```

**5. 状态机与事务设计说明**

- **无状态机**：本组件无状态流转场景；唯一的"状态"是数据库迁移版本（`alembic_version` 表），其流转由 Alembic 框架管理（upgrade/downgrade 线性版本链，分叉冲突时拒绝执行）。
- **事务设计**：迁移由 Alembic 按脚本管理事务边界；seed 脚本单事务（决策 3）；本任务不提供业务写入路径，无跨表业务事务场景（后续业务服务层任务再行设计）。

---

## 2.2 接口设计

本任务**不新增任何 HTTP 对外接口**（spec 1.4.1 职责边界：五类业务接口均不在范围），接口全部为 **Python 内部接口**（模块间契约与脚本入口契约），随模块演进。

### 2.2.1 总体设计

无接口继承体系——按职责分三类：**模型声明接口**（ORM 类与基类）、**会话管理接口**（engine/工厂/依赖生成器）、**脚本入口接口**（建库与 seed）；另含 **Alembic 装载契约**（env.py 与迁移脚本的框架接口）。

| 接口 | 层次 | 类型 | 稳定性 | 说明 |
|---|---|---|---|---|
| `Base` | Python 内部 | 声明基类 | 稳定 | 四张表统一 DeclarativeBase，含约束命名约定 |
| `ServiceItem` / `SourceDocument` / `Conversation` / `Feedback` | Python 内部 | ORM 模型类 | 稳定 | 表结构唯一定义点（spec 4.2.4"模型与迁移不得漂移"的基准侧） |
| `create_db_engine(url)` | Python 内部 | 工厂函数 | 稳定 | 同步 engine 工厂，缺省取 `Settings.database_url` |
| `create_session_factory(engine)` | Python 内部 | 工厂函数 | 稳定 | 统一会话构造参数 |
| `get_db()` | Python 内部 | 依赖生成器 | 实验（原型） | FastAPI 依赖注入形态；本任务不接入路由，为业务接口阶段预留 |
| `create_database()` | 脚本入口 | 模块函数 | 稳定 | 幂等建库（utf8mb4） |
| `seed_demo_data(session)` | 脚本入口 | 模块函数 | 稳定 | 演示数据核心函数（可注入 session，可测性） |
| `alembic/env.py` 装载契约 | Alembic 框架 | 框架接口 | 稳定 | 连接串经 `Settings` 注入；`target_metadata` 指向 Base.metadata |

**变更策略**：模型类列变更必须同步 Alembic 迁移（禁止漂移，spec 4.4.2）并同步 spec §6 数据约束与契约 §3/§4.6（涉及响应字段时）；内部接口新增参数一律带安全缺省值；表名列名与 spec §6.1–6.4 锁定（snake_case，spec 4.4.4）。

**测试策略**：模型声明行为（字段/约束/枚举/引用/隐私）经内存 SQLite 断言；迁移行为（回环/漂移）经程序化 upgrade/downgrade 断言；seed 行为（幂等/覆盖/协议）经注入测试 session 断言；MySQL 专属行为经文档化冒烟清单手动核验（决策 1）。

### 2.2.2 接口清单

#### 2.2.2.1 Base（声明基类，`backend/app/models/base.py`）

```python
class Base(DeclarativeBase): ...
```

- **业务说明**：四张表的统一声明基类；`metadata` 携带统一约束命名约定（索引 `ix_%(column_0_label)s`、唯一 `uq_%(table_name)s_%(column_0_name)s`、检查 `ck_%(table_name)s_%(constraint_name)s`、外键 `fk_%(table_name)s_%(referred_table_name)s_%(referred_column_0_name)s`、主键 `pk_%(table_name)s`）。
- **前置条件**：无（纯声明，无 I/O 副作用）。
- **后置条件**：四张模型表注册于同一 `Base.metadata`，供 `alembic/env.py` 的 `target_metadata` 与漂移检测引用。
- **异常映射**：无（声明期无异常路径；模型类间循环引用由文件级依赖顺序保证不出现）。
- **调用示例**（`models/service_item.py` 的实际用法）：

```python
from app.models.base import Base

class ServiceItem(Base):
    __tablename__ = "service_items"
    ...
```

#### 2.2.2.2 四个 ORM 模型类（`backend/app/models/`）

```python
class ServiceItem(Base): ...        # service_items 表
class SourceDocument(Base): ...     # source_documents 表
class Conversation(Base): ...       # conversations 表
class Feedback(Base): ...           # feedback 表
```

- **业务说明**：四张领域表的唯一定义点——列名/类型/约束按 2.3.2 列规格表实现，SQLAlchemy 2.0 类型注解风格（`Mapped` / `mapped_column`，强类型对齐骨架约定）；三组枚举以 Python `enum.Enum` 类定义（`KnowledgeStatus` 四态、`AnswerStatus` 六态、`FeedbackReasonCode` 四态）并以 `sa.Enum` 落库（决策/约束实现见 2.1.3）。
- **前置条件**：无；类间依赖顺序 `Feedback → Conversation → ServiceItem`、`SourceDocument → ServiceItem` 由文件拆分保证无循环。
- **后置条件**：表结构元数据与初始迁移一致（compare_metadata 零差异，spec 4.2.4）；新会话记录构造时 `id` 自动获得 UUID v4 字符串（决策 4，spec 5.1.1 规则 5a）；时间列 `created_at`/`updated_at` 等由 UTC 默认值自动填充（决策 6）。
- **异常映射**：唯一/枚举/外键/检查约束违反 → 数据库层 `IntegrityError`（写入方捕获转译属后续业务层职责）；本任务测试以 `IntegrityError` 为四类断言的期望异常。
- **调用示例**（`scripts/seed_demo_data.py` 的实际用法）：

```python
from app.models import ServiceItem

item = ServiceItem(code="S01", name="学生证补办", ...)
```

#### 2.2.2.3 create_db_engine（会话工厂组，`backend/app/db/session.py`）

```python
def create_db_engine(url: str | None = None) -> Engine: ...
```

- **业务说明**：同步 engine 工厂——`url` 为 None 时取 `Settings.database_url`（骨架装载链，零改动复用）；连接池参数：`pool_pre_ping=True`（取用前探活，连接失效自愈）、`pool_recycle=3600`（早于 MySQL `wait_timeout` 回收，防演示现场断连，spec 4.2.5 可靠性）。
- **前置条件**：`url` 若显式提供须为 SQLAlchemy 可识别的数据库 URL；engine 创建为惰性连接（不立即触碰数据库）。
- **后置条件**：返回的 engine 可被 session 工厂与 Alembic 测试复用；每次调用返回独立实例（测试隔离）。
- **异常映射**：URL 格式非法 → `ArgumentError` 上抛（测试与脚本可读）；连接不可达不在工厂层处理（惰性，首次取用时报错），错误信息由调用方/框架呈现且不含口令（spec 4.3.4）。
- **调用示例**（`alembic/env.py` 测试路径的实际用法）：

```python
from app.db.session import create_db_engine

engine = create_db_engine("sqlite://")
```

#### 2.2.2.4 create_session_factory（会话工厂组，`backend/app/db/session.py`）

```python
def create_session_factory(engine: Engine) -> sessionmaker[Session]: ...
```

- **业务说明**：统一会话构造参数（`expire_on_commit=False`，提交后对象属性仍可读，便于 seed 报告与测试断言）；原型阶段同步会话。
- **前置条件**：engine 已创建。
- **后置条件**：返回的工厂产出的 session 共享同一 engine 与连接池。
- **异常映射**：无（工厂本身无 I/O）。
- **调用示例**（`scripts/seed_demo_data.py` 入口的实际用法）：

```python
engine = create_db_engine()
session_factory = create_session_factory(engine)
with session_factory() as session:
    seed_demo_data(session)
```

#### 2.2.2.5 get_db（依赖生成器，`backend/app/db/session.py`）

```python
def get_db() -> Iterator[Session]: ...
```

- **业务说明**：FastAPI 依赖注入形态——yield 交付请求级 session，finally 关闭释放；骨架 design 2.1.3 §5 预留的"数据层挂载点"的具体实现。本任务**不挂载任何路由**（spec 1.4.1），属后续业务接口阶段的直接消费接口。
- **前置条件**：session 工厂已就绪（模块级惰性构造，缺省经 `Settings.database_url`）。
- **后置条件**：请求结束（含异常路径）session 必然关闭，无连接泄漏。
- **异常映射**：数据库不可达 → `OperationalError` 上抛，由骨架统一异常处理器兜底转译为 500 错误体（骨架已交付，无需本任务处理）。
- **调用示例**（未来业务接口阶段的实际用法，本任务不实现）：

```python
from app.db.session import get_db

@router.get("/service-items")
def list_items(db: Session = Depends(get_db)): ...
```

#### 2.2.2.6 create_database（建库脚本入口，`scripts/create_database.py`）

```python
def create_database(url: str | None = None) -> None: ...
```

- **业务说明**：幂等建库——从连接串剥离库名直连 server 端，执行 `CREATE DATABASE IF NOT EXISTS <库> CHARACTER SET utf8mb4`；库已存在时静默跳过（spec 5.2.1 规则 1a/1b）。
- **前置条件**：MySQL server 可达；连接配置经 `Settings` 装载链（环境变量 > `.env` > 缺省）。
- **后置条件**：目标库 `campus` 存在且字符集为 utf8mb4；既有数据不受影响。
- **异常映射**：server 不可达/口令错误 → 输出可读错误说明（不含口令，spec 4.3.4）后以非零退出码退出；脚本路径解析失败（不支持的 URL 形态）→ 可读错误退出。
- **调用示例**（实际命令）：

```powershell
python scripts/create_database.py
# 期待输出：数据库 campus 已就绪（新建或已存在）
```

#### 2.2.2.7 seed_demo_data（演示数据入口，`scripts/seed_demo_data.py`）

```python
def seed_demo_data(session: Session) -> SeedReport: ...
```

- **业务说明**：演示数据核心函数——前置检查（四张表存在性，未建表则提示"先执行建库与 `alembic upgrade head`"并终止，spec 5.3.1 规则 5）→ 单事务按稳定逻辑键 upsert（决策 3 的逻辑键表）→ 返回各表写入/更新数量的 `SeedReport`；数据内容：S01–S08 事项（与契约 §3.5 映射表逐项一致）+ 每事项至少一条来源（`example.edu.cn` 示例域名、虚构部门与人员，知识状态覆盖四态）+ 少量演示会话（固定演示 UUID，六态代表性子集）与配套反馈（四原因码覆盖）。
- **前置条件**：调用方已建表并交付 session（脚本入口先执行前置检查；测试路径由 conftest fixture 保证表就绪）。
- **后置条件**：各表演示数据齐备且与既有数据无重复行（幂等，spec 5.3.1 规则 3）；事务失败整体回滚不留半截数据（spec 5.3.3 异常场景 2）；报告与日志不含口令与任何个人身份信息（spec 4.3.4）。
- **异常映射**：表结构未就绪 → 可读提示后终止（非零退出码）；唯一冲突/连接中断 → 单事务回滚 + 可读错误输出。
- **调用示例**（实际命令，脚本入口已包含前置检查与配置装载）：

```powershell
python scripts/seed_demo_data.py
# 期待输出：service_items 8 条、source_documents N 条、conversations N 条、feedback N 条
```

#### 2.2.2.8 Alembic 装载契约（`backend/alembic/env.py`）

- **业务说明**：迁移执行上下文——连接串经骨架 `Settings` 装载链注入（环境变量 > `.env` > 缺省，spec 5.2.1 规则 3），`alembic.ini` 不写入连接串；`target_metadata` 指向 `app.models` 的 `Base.metadata`（漂移检测基准）。
- **前置条件**：`backend/` 在 Python 路径（alembic 于 `backend/` 目录下执行）。
- **后置条件**：迁移命令在目标库上按版本链执行；测试路径经 `config.set_main_option` 覆盖为内存 SQLite URL。
- **异常映射**：配置装载失败（非法环境变量）→ ValidationError 透传，可读错误呈现；数据库不可达 → 可读错误呈现（不含口令）。
- **调用示例**（实际命令，`backend/` 目录下执行）：

```powershell
alembic upgrade head    # 升级到最新版本（首次执行建立四张表）
alembic downgrade base  # 回滚（验证用）
alembic check           # 冒烟清单项：模型与迁移零漂移核验
```

---

## 2.3 数据模型

### 2.3.1 设计目标

- **支持场景**：覆盖 spec §6 数据约束的全部四张表——①办事事项（`service_items`，spec 6.1）②来源文档（`source_documents`，spec 6.2）③匿名会话（`conversations`，spec 6.3）④反馈（`feedback`，spec 6.4），支撑后续 `/api/service-items`、`/api/knowledge/sources`、`/api/conversations`、`/api/feedback` 等接口的逐字段取数（spec 4.5.2/4.5.3）。
- **性能与容量**：原型阶段无吞吐指标（spec 4.1.3）；迁移空库总耗时 ≤ 30 秒、seed 耗时 ≤ 10 秒（spec 4.1.1/4.1.2）——数据量小（8 事项 + 十余条来源 + 少量会话反馈），索引集最小化（仅外键列 + 排序列），不设分库分表等超前设计。
- **匿名性红线（最高优先级）**：`conversations` 表不得包含姓名、学号、身份证号、银行卡号、账号密码等任何个人身份信息字段或内容（spec 4.3.1、6.3.8）——以列集合白名单核验（测试断言，见 2.1.2 测试策略）。
- **与存量数据兼容策略**：全新建库，无存量迁移包袱；与 compose 编排的兼容体现为连接串缺省值逐字一致（spec 4.5.5，未来启用 db 段零改动衔接）；与契约的兼容体现为表名列名与 spec §6.1–6.4 完全一致（spec 4.4.4）。

### 2.3.2 模型实现

```plantuml
@startuml
class Base <<DeclarativeBase>> {
  metadata: MetaData（含约束命名约定）
}

class ServiceItem {
  id: Mapped[int]
  code: Mapped[str]
  name: Mapped[str]
  category: Mapped[str]
  description: Mapped[str]
  enabled: Mapped[bool]
  created_at: Mapped[datetime]
  updated_at: Mapped[datetime]
  documents: relationship[SourceDocument]
}

class SourceDocument {
  id: Mapped[int]
  service_item_id: Mapped[int]
  title: Mapped[str]
  department: Mapped[str]
  official_url: Mapped[str]
  publish_date: Mapped[date]
  effective_from: Mapped[date]
  effective_to: Mapped[date]
  audience: Mapped[str]
  campus: Mapped[str]
  status: Mapped[KnowledgeStatus]
  version: Mapped[str]
  reviewed_at: Mapped[date | None]
}

class Conversation {
  id: Mapped[str]
  question: Mapped[str]
  last_intent: Mapped[str | None]
  result_status: Mapped[AnswerStatus]
  started_at: Mapped[datetime]
  last_message_at: Mapped[datetime]
}

class Feedback {
  id: Mapped[int]
  conversation_id: Mapped[str]
  helpful: Mapped[bool]
  reason_code: Mapped[FeedbackReasonCode | None]
  comment: Mapped[str | None]
  created_at: Mapped[datetime]
}

enum KnowledgeStatus {
  DRAFT
  VERIFIED
  EXPIRED
  CONFLICT
}

enum AnswerStatus {
  ANSWERED
  NEED_CLARIFICATION
  UNSUPPORTED
  INSUFFICIENT_EVIDENCE
  CONFLICT
  SERVICE_ERROR
}

enum FeedbackReasonCode {
  SOURCE_ERROR
  INCOMPLETE_STEPS
  OUTDATED_CONTENT
  OTHER
}

Base <|-- ServiceItem
Base <|-- SourceDocument
Base <|-- Conversation
Base <|-- Feedback
ServiceItem "1" *-- "0..*" SourceDocument : documents
ServiceItem "1" o-- "0..*" Conversation : last_intent（可空）
Conversation "1" *-- "0..*" Feedback : feedbacks
Conversation ..> KnowledgeStatus : 无直接关联
Conversation ..> AnswerStatus : result_status 取值域
SourceDocument ..> KnowledgeStatus : status 取值域
Feedback ..> FeedbackReasonCode : reason_code 取值域（可空）
@enduml
```

**关系与约束说明**：

- **ServiceItem 1:N SourceDocument（组成）**：来源文档依赖事项存在——`service_item_id` 外键 → `service_items.id`（决策/约束见 2.1.3 ER 图；`RESTRICT` 删除策略，原型阶段事项不物理删除仅 `enabled` 软开关，spec 5.1.1 规则 2）。
- **ServiceItem 0:N Conversation（last_intent 可空关联）**：`last_intent` 外键 → `service_items.code`（nullable，决策见 2.1.3）——保证"非空时取值须在事项范围内"（spec 6.3.3）由数据库层实现。
- **Conversation 1:N Feedback（组成）**：反馈依赖会话存在——`conversation_id` 外键 → `conversations.id`（决策 5，严格拒绝策略）。
- **枚举为取值域关联（虚线）而非组成**：三组枚举以独立 Python enum 类定义，模型列按取值域引用；`FeedbackReasonCode` 可空（`helpful = true` 时无原因码，spec 5.1.1 规则 10a）。
- **`conversations` 无 PII 字段（隐私红线）**：类属性仅为 `id`/`question`/`last_intent`/`result_status`/`started_at`/`last_message_at`——测试以列集合白名单断言黑名单字段（姓名/学号/身份证/银行卡/账号密码等）零出现（spec 5.1.1 规则 5b、6.3.8）。
- **对象创建与销毁策略**：ORM 对象由调用方（seed 脚本、后续业务层、测试）按需构造、随 session 提交落库；`Conversation.id` 由模型层默认值自动生成 UUID v4 字符串（36 位，不可预测）；时间列由 UTC 默认值自动填充；无对象级缓存。

**列规格表**（表名与列名与 spec §6.1–6.4 锁定；类型为 SQLAlchemy 层声明，MySQL 落库形态随附）：

**① `service_items`（spec 6.1 / 实施方案 9.1 / 契约 §3.1 映射）**

| 列 | 类型 | 约束 | 说明 |
|---|---|---|---|
| `id` | Integer | PK，自增 | 代理主键（实施方案 9.1"id 主键"；契约 §4.6 响应 `service_item_id` 的指向目标） |
| `code` | String(8) | NOT NULL，UNIQUE | 事项编码 S01–S08（契约 §3.5 业务主键）；长度 3 字符 + 裕量 |
| `name` | String(128) | NOT NULL | 事项名称（契约 `title` 的来源字段） |
| `category` | String(32) | NOT NULL | 事项类别（证件/生活/学业，供前端筛选） |
| `description` | String(255) | NOT NULL | 一句话说明 |
| `enabled` | Boolean | NOT NULL，default True | 开放状态；停用保留记录不物理删除（spec 5.1.1 规则 2a） |
| `created_at` | DateTime(timezone=True) | NOT NULL，default UTC now | 创建时间（决策 6） |
| `updated_at` | DateTime(timezone=True) | NOT NULL，default UTC now，onupdate UTC now | 更新时间（自动维护） |

**② `source_documents`（spec 6.2 / 实施方案 9.2 / 契约 §4.6 逐字段覆盖）**

| 列 | 类型 | 约束 | 说明 |
|---|---|---|---|
| `id` | Integer | PK，自增 | 代理主键（契约 §4.6 响应 `id`） |
| `service_item_id` | Integer | NOT NULL，FK → `service_items.id`，索引 | 关联事项（引用完整性，spec 5.1.1 规则 3b） |
| `title` | String(255) | NOT NULL | 来源标题 |
| `department` | String(128) | NOT NULL | 发布部门 |
| `official_url` | String(512) | NOT NULL | 官方地址（http/https 绝对地址由应用层写入校验 + seed 数据保证；数据库层不设 URL 格式校验约束） |
| `publish_date` | Date | NOT NULL | 发布日期 `YYYY-MM-DD`（契约 §1.1 纯日期格式） |
| `effective_from` | Date | NOT NULL | 有效期起始 |
| `effective_to` | Date | NOT NULL，CHECK ≥ `effective_from` | 有效期截止（CheckConstraint，SQLite 与 MySQL 8.0.16+ 均强制执行） |
| `audience` | String(128) | NOT NULL | 适用对象 |
| `campus` | String(64) | NOT NULL | 适用校区 |
| `status` | Enum(KnowledgeStatus) | NOT NULL，default DRAFT | 知识状态四态（spec 5.1.1 规则 4；默认草稿——新来源未核验即草稿的业务语义） |
| `version` | String(32) | NOT NULL | 版本号（如 `v1.0`） |
| `reviewed_at` | Date | NULL | 最后核验时间（未核验时为空，spec 6.2.11） |

**③ `conversations`（spec 6.3 / 实施方案 9.3 + 契约 §3.4 补齐项）**

| 列 | 类型 | 约束 | 说明 |
|---|---|---|---|
| `id` | String(36) | PK，default UUID v4（模型层生成） | 随机会话标识，不可预测（决策 4，spec 5.1.1 规则 5a）；即匿名标识维度 |
| `question` | Text | NOT NULL | 最近一次用户提问（契约 §3.4 必返回；首轮发起问答时 message 即 question，创建时总有值） |
| `last_intent` | String(8) | NULL，FK → `service_items.code` | 最近识别事项编码（可空；外键保证取值域，spec 6.3.3） |
| `result_status` | Enum(AnswerStatus) | NOT NULL | 回答状态六态（spec 5.1.1 规则 8；无默认值，写入方显式提供） |
| `started_at` | DateTime(timezone=True) | NOT NULL，default UTC now | 会话开始时间 |
| `last_message_at` | DateTime(timezone=True) | NOT NULL，default UTC now，索引 | 最近一条消息时间（契约 §3.4 补齐项；索引服务契约 §4.4 按其倒序的最近会话查询） |

**④ `feedback`（spec 6.4 / 实施方案 9.4 / 契约 §3.6、§4.5）**

| 列 | 类型 | 约束 | 说明 |
|---|---|---|---|
| `id` | Integer | PK，自增 | 代理主键（实施方案 9.4） |
| `conversation_id` | String(36) | NOT NULL，FK → `conversations.id`，索引 | 关联会话（严格拒绝策略，决策 5） |
| `helpful` | Boolean | NOT NULL | 是否有帮助 |
| `reason_code` | Enum(FeedbackReasonCode) | NULL | 反馈原因码四态（可空：`helpful = true` 时无原因码，spec 5.1.1 规则 10a） |
| `comment` | String(200) | NULL | 可选短评（长度对齐契约 §4.5 ≤ 200 字） |
| `created_at` | DateTime(timezone=True) | NOT NULL，default UTC now | 提交时间 |

**持久化策略**：

- **落库形态**：MySQL 8.x，库 `campus`、字符集 utf8mb4（决策 2）、引擎 InnoDB（初始迁移方言参数）；SQLite 仅作为测试落库形态（决策 1），两侧行为差异（原生 ENUM vs VARCHAR+CHECK、FK 索引自动建 vs 显式声明）已对齐。
- **唯一持久化入口**：Alembic 迁移（spec 4.4.2 禁止手工改表）；演示数据经 seed 脚本（幂等 upsert）；**无其他写入路径**（业务写入属后续任务）。
- **枚举落库值**：以字符串值存储（`draft`/`verified`/`expired`/`conflict`、六态小写、原因码大写）与契约 §3.2/§3.3/§3.6 的对外取值逐字一致，保证后续接口取数零转换。
- **索引策略（最小集）**：仅外键列（`source_documents.service_item_id`、`feedback.conversation_id`、`conversations.last_intent` 经 FK）与排序列（`conversations.last_message_at`）；`status`/`item_code` 过滤索引暂不加（原型数据量小，spec 4.1.3，避免过度设计）。
- **生命周期**：表结构随初始迁移建立、随 downgrade 移除；数据生命周期（会话留存/清理策略）属后续任务，本任务不设清理机制。