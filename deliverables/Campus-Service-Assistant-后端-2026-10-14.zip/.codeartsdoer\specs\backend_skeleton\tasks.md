# 后端骨架（backend_skeleton）实施任务清单

> 依据：`.codeartsdoer/specs/backend_skeleton/spec.md`（需求规格）、`.codeartsdoer/specs/backend_skeleton/design.md`（技术设计）
> 技术栈：Python 3.12 + FastAPI + Pydantic v2 + Pytest（骨架阶段无数据库、无外部服务依赖）
> 验证方式：PowerShell 中进入 `backend/` 目录后执行 `pytest -q`，退出码 0 表示全部通过
> 编制日期：2026-10-08

---

## 任务依赖顺序总览

```
任务1（目录与工具链）
  ├─→ 任务2（配置装载）──┐
  ├─→ 任务3（统一错误体）─┼─→ 任务5（应用工厂与启动入口）→ 任务6（测试套件）→ 任务7（验证与验收）
  └─→ 任务4（健康检查）──┘
```

- 任务 2、3、4 相互无依赖，可并行开发
- 任务 5 依赖任务 2、3、4（组装配置装载、错误处理器与健康路由）
- 任务 6 依赖任务 5（经 `create_app` 构建测试实例）
- 任务 7 依赖任务 6（测试全部通过后进行启动冒烟与安全验收）

## 1. 搭建后端目录与工具链

基础设施任务，为后续全部编码任务提供目录、依赖与测试发现配置。

- [ ] 1.1 创建 `backend/` 目录骨架：在仓库根新建 `backend/` 及其子目录 `backend/app/`、`backend/app/core/`、`backend/app/api/`、`backend/tests/`，并放置 `__init__.py` 使各包可导入；不预建 `services/`、`models/`、`db/` 空壳目录（留待对应任务创建，spec 5.3.1 规则 1）
- [ ] 1.2 编写 `backend/requirements.txt`：列出运行时依赖 `fastapi`、`uvicorn`、`pydantic-settings` 三项；确保仅凭该清单安装后骨架即可启动，不含数据库或其他外部依赖
- [ ] 1.3 编写 `backend/requirements-dev.txt`：列出测试依赖 `pytest` 与 `httpx`（TestClient 底层依赖），与 requirements.txt 配套使用
- [ ] 1.4 编写 `backend/pytest.ini`：指定测试目录 `tests/` 与用例文件模式 `test_*.py`，保证在 `backend/` 目录直接执行 `pytest -q` 即可发现并运行全部用例
- [ ] 1.5 更新仓库根 `.gitignore`：在不改动任何既有规则的前提下追加"Python"分组，忽略 `__pycache__/`、`*.py[cod]`、`.pytest_cache/`、`.venv/`、`venv/`，防止 Python 工件污染版本库（design 1.1.2 扩展点）

## 2. 实现核心配置装载

对应 spec 5.1 配置装载规则与 spec §6.2 服务配置项。

- [ ] 2.1 实现 `backend/app/core/config.py` 中的 Settings 配置类：定义四个配置项——运行端口（int，缺省 `8000`）、运行环境标识（Literal["local", "production"]，缺省 `local`）、数据库连接串（str，缺省占位值与 docker-compose 注释段一致）、AgentArts API Key（str，缺省空占位字符串）；装载优先级为环境变量 > `.env` 文件 > 内置缺省值；全部字段显式强类型校验，禁止硬编码真实密钥
- [ ] 2.2 实现 `get_settings` 单例访问函数：以 `lru_cache` 保证进程级唯一配置实例，重复调用零开销；`.env` 文件不存在时以缺省值成功装载（开箱即用，spec 5.1.3 场景 3）
- [ ] 2.3 创建仓库根 `.env.example` 样例文件：列出全部 4 个配置项及安全占位值（AgentArts API Key 留空或占位注释样式），绝不包含任何真实云密钥；该文件已被 `.gitignore` 既有规则放行入库，作为新成员配置参考

## 3. 实现统一错误响应

对应 spec 5.2.1 规则 5 决策点裁决（骨架阶段即实现统一错误体）与契约 §2.1/§2.3。

- [ ] 3.1 在 `backend/app/core/errors.py` 中定义错误响应模型与静态映射表：错误体结构为 `{"error": {"code", "message"}}`（与契约 §2.1 逐字段一致）；静态映射——404/405/422 → `INVALID_REQUEST`（安全文案分别为"资源不存在"/"请求方法不支持"/"请求参数校验失败"），500 → `INTERNAL_ERROR`（"服务内部错误，请稍后重试"）；文案全部来自静态映射表，禁止动态拼接异常信息、堆栈或内部路径（spec 4.3.4 防泄露）
- [ ] 3.2 在 `backend/app/core/errors.py` 中实现 `register_error_handlers(app)` 注册函数：为 FastAPI 实例注册 404/405/422/500 四类异常处理器，统一返回上述错误体，响应 Content-Type 携带 `charset=utf-8`；函数内部不抛异常，由 `create_app` 在装配时调用

## 4. 实现健康检查接口

对应 spec 5.2 服务健康自测与契约 §4.1。

- [ ] 4.1 在 `backend/app/api/health.py` 中定义 HealthResponse 响应模型：`status` 字段取值固定为 `"ok"`，约束响应体仅含 `{"status": "ok"}` 且不含任何其他字段（spec §6.1，响应不得携带堆栈、内部主机名等信息）
- [ ] 4.2 实现 `GET /api/health` 路由：以 APIRouter 挂载在 `/api` 前缀下（保留 `/api` 前缀，匹配 Vite 代理与 Nginx 反代的转发语义，契约 §4.5.1）；接口为纯只读、幂等、匿名访问，不触碰数据库/云服务/文件系统（无外部依赖，spec 5.2.1 规则 2/3）；响应 Content-Type 显式为 `application/json; charset=utf-8`（spec 4.5.3）

## 5. 实现应用工厂与启动入口

对应 spec 5.1 服务启动规则，依赖任务 2、3、4 完成后进行组装。

- [ ] 5.1 在 `backend/app/main.py` 中实现 `create_app` 应用工厂：可选接收配置对象（缺省时内部调用 `get_settings` 装载），装配时挂载健康检查路由并注册统一异常处理器；每次调用返回独立的 FastAPI 实例（保证测试隔离）；工厂不捕获配置校验异常（交由启动入口转译为可读错误）
- [ ] 5.2 在 `backend/app/main.py` 中提供模块级 `app` 实例：由工厂产物生成，保证 `uvicorn app.main:app` 可直接加载，与未来 Docker Compose backend 服务段（构建上下文 `./backend`）的启动方式零改动兼容（spec 4.5.4）
- [ ] 5.3 实现 `python -m app.main` 本地启动入口：装载配置 → 创建应用 → 以 uvicorn 监听配置端口（缺省 **8000 端口**，spec 4.5.2）；配置校验失败（如端口环境变量为非数字、环境标识非法）时输出单行可读配置错误说明（不含堆栈细节）并以非零退出码退出（spec 5.1.3 场景 1）；端口被占用时依赖 uvicorn 自身的可读错误输出（spec 5.1.3 场景 2，不重复处理）

## 6. 编写 Pytest 测试套件

对应 spec 5.3 测试保障规则，依赖任务 5 完成后进行。

- [ ] 6.1 编写 `backend/tests/conftest.py`：经 `create_app()` 构建 TestClient 测试实例供各用例复用；提供配置缓存清理夹具，支持用例间以环境变量注入方式验证配置覆盖行为
- [ ] 6.2 编写 `backend/tests/test_health.py`（健康检查 + 统一错误体）：至少覆盖——GET /api/health 返回 200 且响应体恰为 `{"status": "ok"}`；Content-Type 含 `charset=utf-8`；重复调用多次结果一致（幂等）；以 POST 请求 /api/health 返回 405 且错误体为 `{"error": {"code": "INVALID_REQUEST", "message": "请求方法不支持"}}`；请求未定义路径返回 404 且错误体为 `{"error": {"code": "INVALID_REQUEST", "message": "资源不存在"}}`（spec 5.3.1 规则 3 要求健康检查至少 1 条用例断言状态码与响应体）
- [ ] 6.3 编写 `backend/tests/test_config.py`（配置装载）：至少覆盖——不设置环境变量时按内置缺省值装载（含端口 8000、环境标识 local）；设置环境变量后覆盖内置缺省值（验证优先级）；端口环境变量为非数字时抛出校验异常；`get_settings` 返回进程级单例（重复调用为同一实例）

## 7. 验证与验收

最终验收任务，依赖任务 6 全部通过后进行。

- [ ] 7.1 运行测试套件：在 PowerShell 中进入 `backend/` 目录执行 `pytest -q`，确认全部用例通过且退出码为 0（spec 5.3.1 规则 2；实施方案第十二章测试命令 `cd backend && pytest -q`）
- [ ] 7.2 本地启动冒烟验证：执行 `python -m app.main` 启动服务，确认服务在 8000 端口监听且控制台输出就绪信息（含监听地址与端口，spec 4.4.3）；另开终端执行 `curl http://localhost:8000/api/health` 得到 `{"status":"ok"}`；验证完毕停止服务
- [ ] 7.3 密钥零泄露与忽略规则检查：对 `backend/` 全部源码与 `.env.example` 进行密钥检查，确认不存在任何真实云服务密钥（spec 4.3.1，第 3 周验收项"代码中不存在真实云密钥"）；执行 `git status` 确认 `.env`（若本地存在）与 `__pycache__/`、`.pytest_cache/` 等 Python 工件不出现在未跟踪文件列表中（验证任务 1.5 忽略规则生效）