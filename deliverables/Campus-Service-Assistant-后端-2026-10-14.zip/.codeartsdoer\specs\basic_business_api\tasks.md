# 基础业务接口（basic_business_api）实施任务清单

> 依据：`spec.md`（需求规格）、`design.md`（技术设计，7 项设计裁决）
> 验证方式：`cd backend && pytest -q`（PowerShell，内存 SQLite）
> 生成日期：2026-10-11

**依赖顺序总览**：任务 1（共享基础设施）与任务 2（迁移 0002）无前置依赖、可并行先行；任务 3 依赖任务 1；任务 4 依赖任务 1 + 2；任务 5 依赖任务 1；任务 6 依赖任务 2；任务 7 依赖任务 3–6 全部完成。

---

## 1. 准备共享基础设施与公共类型

> 无前置依赖，被三个接口共同依赖，最先实施。改动既有交付物（core 层）需保证回归行为不变。

- [ ] 1.1 提取 `UTF8JSONResponse` 到共享模块 `backend/app/core/responses.py`，并在 `backend/app/main.py` 的 `create_app` 中将其设为全局默认响应类；`backend/app/api/health.py` 原样保留（其显式 `response_class` 优先级更高，行为零变化）
- [ ] 1.2 在 `backend/app/core/errors.py` 新增 `BusinessError` 业务异常类型（携带状态码 + 错误码 + 安全文案三要素）与对应异常处理器，渲染为既有统一错误体格式 `{"error": {code, message}}`（charset utf-8）；既有 `ERROR_MAP` 4 项静态映射与 3 个异常处理器逐字原样保留（spec 4.2.4 回归保障）
- [ ] 1.3 新建 `backend/app/schemas/common.py`（含目录 `__init__.py`）：定义 `UtcDateTime` 注解类型——datetime 读回值无 tzinfo 时按 UTC 补齐时区标记，以 ISO 8601 带时区（`+00:00`）格式序列化输出（design 决策 5）；定义 `limit` 约束类型——整数、缺省 10、取值范围 1–50 含边界，越界或非整数触发 422（spec 6.6）

## 2. 交付会话匿名标识维度（迁移 0002 + 模型同步）

> 无前置依赖，可与任务 1 并行；被任务 4（会话查询）、任务 6（演示数据）依赖。

- [ ] 2.1 在 `backend/app/models/conversation.py` 的 `Conversation` 模型新增 `session_token` 列（字符串、可空、建索引），其余字段定义零变更（模型-迁移零漂移，`compare_metadata` 断言保持通过）；其余三个模型文件不动
- [ ] 2.2 新建迁移脚本 `backend/alembic/versions/0002_add_conversation_session_token.py`：`upgrade` 为 `conversations` 表追加 `session_token` 列与索引，`downgrade` 逆序删除索引与列，迁移可升级亦可回滚（spec 5.4.1 规则 2）
- [ ] 2.3 更新既有回归断言：`backend/tests/test_migrations.py` 中版本断言由 `"0001"` 改为 `"0002"`（断言逻辑本身不变）；`backend/tests/test_models.py` 中 `conversations` 列白名单补充 `session_token`（PII 禁入清单 10 项不变，`session_token` 不在禁入清单内）

## 3. 实现查询支持事项接口（GET /api/service-items）

> 依赖任务 1（默认响应类）。契约 §3.1 / §4.2；响应为直接数组，仅含四必返字段（design 决策 1）。

- [ ] 3.1 新建 `backend/app/schemas/service_item.py` 定义 `ServiceItemResponse` 响应模型：仅含 `id`、`title`、`description`、`category` 四个必返字段，`title` 取自 ORM `name` 列（契约 §3.1 映射），不输出 `icon`/`tone`/`prompt`（design 决策 1，方案 A 不改表）
- [ ] 3.2 新建 `backend/app/services/service_items.py` 实现事项查询服务 `list_enabled_service_items(session)`：仅查询 `enabled = true` 的事项、按 `code` 升序排列；在模块内定义 8 项契约映射表常量（S01→student-card、S02→campus-card、S03→repair、S04→leave、S05→scholarship、S06→grant、S07→major-transfer、S08→graduation）派生前端 UI 标识 `id`，映射表未覆盖的编码按全小写兜底派生（如 S09→s09，design 决策 6）；只读查询不调用 `commit`
- [ ] 3.3 新建 `backend/app/api/service_items.py` 实现 `GET /api/service-items` 路由：无查询参数（携带未定义参数时默认忽略正常返回）、响应为 `ServiceItem[]` 直接数组（无包装对象）、空表返回 200 空数组而非 404；通过 `Depends(get_db)` 注入数据库会话并委托事项查询服务；在 `backend/app/main.py` 的 `create_app` 中挂载该 router

## 4. 实现最近会话匿名隔离查询接口（GET /api/conversations）

> 依赖任务 1（公共类型）与任务 2（session_token 列）。契约 §3.4 / §4.4；隐私红线以短路实现（design 决策 2、3）。

- [ ] 4.1 新建 `backend/app/schemas/conversation.py` 定义会话摘要响应模型 `ConversationSummaryResponse`（`id`、`question`、`last_intent`、`result_status`、`started_at`、`last_message_at` 六字段）：`result_status` 直接复用既有 `AnswerStatus` 枚举类型约束并原样输出（不派生"待继续/已完成"字段）、`last_intent` 可空且无值时显式输出 null、两个时间字段使用 `UtcDateTime`；定义 `ConversationListResponse` 包装体（`{"conversations": [...], "total": N}`，`total` 非负整数，语义为该匿名标识下会话总数）
- [ ] 4.2 新建 `backend/app/services/conversations.py` 实现会话查询服务 `list_conversations(session, session_token, limit)`：`session_token` 缺失（None）或去除首尾空白后为空串时，短路返回 `{"conversations": [], "total": 0}` 且不执行任何数据库查询（隐私红线，杜绝全量返回路径）；标识存在时按 `session_token` 精确过滤 + `last_message_at` 倒序 + `limit` 截断取摘要列表，同过滤条件的 count 作为 `total`（design 决策 3 分页语义）；只读查询不调用 `commit`
- [ ] 4.3 新建 `backend/app/api/conversations.py` 实现 `GET /api/conversations` 路由：以 `Header(default=None)` 强类型读取 `X-Session-Token` 请求头、`limit` 查询参数使用约束类型（缺省 10、范围 1–50，越界走既有 422 通道）；通过 `Depends(get_db)` 注入会话并委托查询服务；在 `create_app` 中挂载该 router

## 5. 实现反馈提交接口（POST /api/feedback）

> 依赖任务 1（BusinessError 通道）。契约 §3.6 / §4.5；本任务唯一写事务路径（design 事务设计）。

- [ ] 5.1 新建 `backend/app/schemas/feedback.py` 定义 `FeedbackRequest` 请求模型：`conversation_id` 必填非空字符串、`helpful` 必填布尔、`reason_code` 直接复用既有 `FeedbackReasonCode` 四态枚举且允许缺省（保持枚举单一事实来源）、`comment` 可空且长度 ≤200 字；定义 `FeedbackResponse` 固定值模型（仅含 `{"status": "ok"}`，不携带额外字段）
- [ ] 5.2 新建 `backend/app/services/feedback.py` 实现反馈写入服务 `submit_feedback(session, payload)`：按 `conversation_id` 校验会话存在性，不存在时抛出 `BusinessError(404, "CONVERSATION_NOT_FOUND", ...)`（经任务 1.2 新增通道渲染，且不产生任何落库记录）；校验通过后构造完整反馈记录（`conversation_id`/`helpful`/`reason_code`/`comment`，提交时间由服务端 UTC 默认值填充）并 `commit` 提交事务，`commit` 异常时 `rollback` 回滚不留半截数据；同一会话重复提交为追加独立记录（不去重）
- [ ] 5.3 新建 `backend/app/api/feedback.py` 实现 `POST /api/feedback` 路由：请求体经 `FeedbackRequest` 强类型校验（缺必填/枚举越界/短评超长/非合法 JSON 均走既有 422 统一错误体通道），成功返回 200 `{"status": "ok"}`；通过 `Depends(get_db)` 注入会话并委托写入服务；在 `create_app` 中挂载该 router

## 6. 预置演示数据与测试基建

> 依赖任务 2（模型列）；任务 7 的前置。遵循"只追加、不改既有 fixture"约束（spec 4.4.3）。

- [ ] 6.1 修改 `scripts/seed_demo_data.py`：在 `DEMO_CONVERSATIONS` 中预置一个固定演示 token 常量（5 条演示会话共用该值填充 `session_token`），保持 upsert 幂等语义不变，使演示数据可被匿名隔离查询命中（联调可见性，design 1.1.2）
- [ ] 6.2 在 `backend/tests/conftest.py` 追加数据库路由测试客户端 fixture：复用既有 `db_engine`，以 `app.dependency_overrides[get_db]` 替换会话依赖，替换实现与原依赖同形（生成器 + finally 关闭），使接口路由的测试会话指向内存 SQLite；既有 5 个 fixture 原样保留，不引入第二套测试基建

## 7. 编写接口测试与全量回归验证

> 依赖任务 3–6 全部完成。测试必须覆盖正常路径与异常路径（spec 4.4.2），复用任务 6.2 的数据库路由客户端 fixture。

- [ ] 7.1 新建 `backend/tests/test_service_items.py` 覆盖事项接口：正常路径断言四字段齐全与 `title` ← `name` 映射；8 项契约映射逐一断言 `id` 派生正确；结果按编码升序；停用事项被排除且库中记录不删除；空表返回 200 空数组；未命中编码（如 S09）按全小写兜底派生；重复调用结果一致（幂等）；非 GET 方法返回 405 统一错误体
- [ ] 7.2 新建 `backend/tests/test_conversations.py` 覆盖会话接口：隐私红线断言——token A 的响应不包含 token B 下任何会话、不返回全量会话；`X-Session-Token` 缺失与空白头均返回 200 `{"conversations": [], "total": 0}` 且不触发数据库查询；`limit` 缺省 10、取 0/负数/大于 50/非整数时返回 422 统一错误体；结果按 `last_message_at` 倒序；摘要六字段齐全、`last_intent` 无值时显式输出 null；时间字段输出 ISO 8601 带时区格式；重复调用不改变会话数据（只读幂等）
- [ ] 7.3 新建 `backend/tests/test_feedback.py` 覆盖反馈接口：正常提交返回 200 `{"status": "ok"}` 且反馈记录完整落库（会话标识、是否有帮助、原因码、短评、服务端生成提交时间齐备）；同一会话重复提交产生相互独立记录；缺 `conversation_id`/`helpful` 返回 422；`reason_code` 四态之外取值返回 422、缺省时落库为空；短评超 200 字返回 422；会话不存在返回 404 与 `CONVERSATION_NOT_FOUND` 错误码且零落库；校验失败与不存在场景均不产生任何反馈记录
- [ ] 7.4 全量回归验证：在 `backend/` 目录执行 `pytest -q` 全部通过且退出码为 0（既有 34 用例 + 新增三接口用例）；确认既有 health/config/models/migrations/seed 用例行为不变（404/405 静态映射文案逐字不变、迁移版本链 0001→0002 升级正常）；抽验三接口响应结构、字段命名、错误码与 `docs/api.md` 契约逐项一致