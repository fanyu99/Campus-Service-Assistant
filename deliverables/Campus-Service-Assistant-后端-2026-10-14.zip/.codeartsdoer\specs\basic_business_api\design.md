# 基础业务接口（basic_business_api）技术设计

> 依据：`.codeartsdoer/specs/basic_business_api/spec.md`、`docs/api.md`（前后端唯一权威契约）
> 上游既定组件：backend_skeleton（应用骨架）、database_modeling（持久化底座）
> 编制日期：2026-10-11

---

# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

下表列出需求中与存量代码完全匹配、可直接复用的能力。匹配度判定依据：契约行为与存量实现逐项比对（响应结构、状态码、编码、依赖形态）。

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 统一错误响应体 `{"error": {code, message}}`（契约 §2.1）及 404/405/422/500 静态安全文案 | `ERROR_MAP` 静态映射 + 三个异常处理器 | `backend/app/core/errors.py:6-36` | 100% |
| 数据格式 `application/json; charset=utf-8`（spec 4.5.4） | `UTF8JSONResponse`（路由侧）+ `error_response` 显式 `media_type`（错误侧） | `backend/app/api/health.py:8-16`、`core/errors.py:18-22` | 100% |
| 路由内获取数据库会话（依赖注入形态） | `get_db` 依赖生成器（yield session、finally 关闭） | `backend/app/db/session.py:31-36` | 100% |
| 应用工厂路由挂载机制 | `create_app` 工厂 + `include_router` | `backend/app/main.py:10-15` | 100% |
| 会话/反馈 ORM 与枚举（回答状态六态、反馈原因码四态、外键严格校验） | `Conversation`/`Feedback`/`AnswerStatus`/`FeedbackReasonCode` | `backend/app/models/conversation.py:11-45`、`models/feedback.py:10-38` | 100% |
| 事项表（`code` 唯一、`enabled` 列）与 S01–S08 演示数据 | `ServiceItem` + seed 脚本幂等 upsert | `backend/app/models/service_item.py:9-23`、`scripts/seed_demo_data.py:26-35` | 100% |
| 测试基建（内存 SQLite、迁移建表、`PRAGMA foreign_keys=ON`、会话供给） | `alembic_cfg`/`db_engine`/`db_session` fixtures | `backend/tests/conftest.py:32-60` | 100% |
| 参数校验失败返回 HTTP 422 统一错误体（spec 5.2.1 规则 3b） | `handle_validation_exception` → 422 静态映射 | `backend/app/core/errors.py:30-32` | 100% |
| 服务端生成 UTC 时间戳（落库默认值） | `utc_now()`（`datetime.now(timezone.utc)`） | `backend/app/models/base.py:16-17` | 75%（存储侧齐备；**序列化输出带时区**需接口层补齐，见 1.1.2 第 7 行） |
| 反馈提交时间由服务端生成（spec 5.3.1 规则 4） | `Feedback.created_at` 默认值 `utc_now` | `backend/app/models/feedback.py:36` | 100% |

### 1.1.2 需要扩展的功能

下表列出存量实现与需求存在差距、需在既有基础上改造的部分。差异说明聚焦输入输出、业务逻辑与边界条件三个维度。

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 404 语义分流：会话不存在返回 `CONVERSATION_NOT_FOUND`（契约 §2.3） | `ERROR_MAP` 按状态码静态映射，404 一律返回 `INVALID_REQUEST` | 输出差异：同一 404 状态码需按资源语义输出两种 `error.code`；既有机制忽略异常携带的语义信息（`detail` 未参与映射） | 在 `core/errors.py` **新增**业务异常类型与对应异常处理器（携带状态码 + 错误码 + 文案），既有 4 项静态映射与既有 handler **原样保留**（spec 4.2.4 回归保障） |
| `create_app` 挂载三个新路由 | 工厂仅挂载 health 路由 | 输入差异：需注册 3 个新 router；行为差异：无既有逻辑变化 | `create_app` 函数体内新增挂载语句与默认响应类设置；函数签名、health 挂载顺序、错误处理器注册顺序均不动 |
| `conversations` 表匿名标识维度（spec 5.4 核心能力） | 表无独立匿名标识列（database_modeling 决策 4 曾裁定 `id` 即标识，未设维度列） | 边界差异：列表隔离查询需要"调用方持有什么标识"的过滤维度，仅凭会话 `id` 无法支撑匿名列表查询（前端不可能持有全量历史会话 id） | 新增版本化迁移 0002 加列（`session_token`，可空 + 索引）+ ORM 同步加列（模型-迁移零漂移约束）；标识**写入路径**属第 5 周问答任务，本任务仅交付维度定义与查询侧消费 |
| 迁移版本回归断言 | `test_migrations.py:53` 断言 `version == "0001"` | 输入差异：新增 0002 迁移后版本链头变为 0002 | 更新该断言值为 `"0002"`（预期内的回归修正，断言逻辑本身不变） |
| `conversations` 列白名单测试 | `test_models.py:71-93` 断言列集合恰为 6 列 + PII 禁入清单 | 输入差异：加列后列集合为 7 列 | 白名单集合补充 `session_token`；PII 禁入清单（`student_id`/`id_card`/`password` 等 10 项）**不变**，且 `session_token` 不在禁入清单内（非个人身份字段） |
| 演示数据可被隔离查询命中（联调可见性） | seed 演示会话无匿名标识值 | 边界差异：空标识记录不归属任何匿名标识（spec 5.4.3 场景 3），联调时携带任何 token 均查不到演示会话 | seed 脚本 `DEMO_CONVERSATIONS` 预置一个固定演示 token 常量（5 条会话共用），upsert 幂等语义不变 |
| 三个新路由复用 UTF-8 JSON 响应类 | `UTF8JSONResponse` 定义在 `health.py` 内 | 依赖差异：从 health 模块 import 会形成"基础接口依赖健康检查模块"的倒置耦合 | 将该类提取到 `core/responses.py` 共享模块，并在 `create_app` 设为全局默认响应类；`health.py` **原样保留**（其显式 `response_class` 优先级更高，行为零变化） |

### 1.1.3 需要新增的功能或接口

按业务模块分组。每组标注与其他模块的依赖关系。

**分组 A：响应模型层（`backend/app/schemas/`，新增目录）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|--------|------|------|---------|------|
| `ServiceItemResponse` | 事项 ORM 行 | `id`/`title`/`description`/`category` 四必返字段 | 契约 §3.1 字段映射：`title` ← `name` 列；`id` ← 编码派生；不含 icon/tone/prompt（决策 1） | models |
| `ConversationSummaryResponse` | 会话 ORM 行 | 契约 §3.4 六字段（`last_intent` 可空显式输出） | `result_status` 用回答状态枚举类型约束；时间戳经时区归一化类型序列化 | models、common |
| `ConversationListResponse` | 摘要数组 + 总数 | `{"conversations": [...], "total": N}` 包装体 | `total` 非负整数约束 | — |
| `FeedbackRequest` | HTTP 请求体 | 强类型请求模型 | 必填/可空、原因码四态枚举、短评 ≤200 字校验 | models（复用四态枚举） |
| `FeedbackResponse` | — | `{"status": "ok"}` | 固定值约束 | — |
| `UtcDateTime` 注解类型 | 落库读回的 datetime（可能无 tzinfo） | ISO 8601 带时区字符串（UTC `+00:00`） | 无时区信息时按 UTC 补齐（两个落库形态行为归一化） | — |
| `LimitParam` 约束类型 | `limit` 查询参数 | 1–50 整数（缺省 10） | 边界越界/非整数 → 422 | — |

**分组 B：业务服务层（`backend/app/services/`，新增目录）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|--------|------|------|---------|------|
| 事项查询服务 | 数据库会话 | 摘要模型数组 | 仅 `enabled = true`；按编码升序；编码 → 前端 UI 标识派生（8 项映射表 + kebab-case 兜底） | schemas、models |
| 会话查询服务 | 会话、匿名标识（可空）、limit | 列表包装响应 | 标识缺失短路返回空响应（不触碰数据库）；按标识过滤 + 最近消息时间倒序 + limit 截断；同条件计数作为 `total` | schemas、models |
| 反馈写入服务 | 会话、请求模型 | 无（成功即 200） | 会话存在性校验（不存在 → 404 `CONVERSATION_NOT_FOUND`）；追加独立反馈记录；事务提交失败回滚 | schemas、models |

**分组 C：接口路由层（`backend/app/api/`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|--------|------|------|---------|------|
| `GET /api/service-items` 路由 | 无参数请求 | `ServiceItem[]` 直接数组 | 依赖注入数据库会话，委托事项查询服务 | 分组 B、`get_db` |
| `GET /api/conversations` 路由 | `limit`（可缺省）+ `X-Session-Token` 请求头（可缺失） | 包装响应体 | 读取自定义请求头并委托会话查询服务 | 分组 B、`get_db` |
| `POST /api/feedback` 路由 | 请求体 | `{"status": "ok"}` | 请求体强类型校验（失败 422），委托反馈写入服务 | 分组 B、`get_db` |

**分组 D：版本化迁移（`backend/alembic/versions/`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|--------|------|------|---------|------|
| 迁移 0002：会话表补充匿名标识维度 | 0001 schema | `conversations.session_token` 列（可空、索引） | upgrade 加列加索引；downgrade 逆序删除；可升级可回滚 | 0001 |

**分组 E：接口测试（`backend/tests/`）**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|--------|------|------|---------|------|
| 事项接口测试 | HTTP 请求 | 断言结果 | 正常路径 + 异常路径（字段映射、排序、排除停用、空表、兜底派生、幂等、405） | conftest fixtures |
| 会话接口测试 | HTTP 请求 | 断言结果 | 正常路径 + 异常路径（隔离红线、token 缺失、limit 边界、排序、六字段、时间格式、只读幂等） | conftest fixtures |
| 反馈接口测试 | HTTP 请求 | 断言结果 | 正常路径 + 异常路径（校验失败、会话不存在、落库完整性、重复提交、事务回滚） | conftest fixtures |
| 数据库路由测试客户端 fixture | `db_engine` | 路由会话被替换的 TestClient | 复用既有引擎，`dependency_overrides` 替换 `get_db`（与原依赖同形：生成器 + finally 关闭） | 既有 fixtures |

## 1.2 存量功能详细分析

对 1.1.1 已实现功能的深入解读，聚焦与本任务设计相关的契约、规则、扩展点与约束。

**（1）数据库会话依赖 `get_db`（`backend/app/db/session.py:31-36`）**

- **接口契约**：无参生成器，产出 `Session`；请求结束后在 `finally` 中关闭会话。模块级惰性单例工厂（首次调用按 `Settings.database_url` 建引擎）。
- **扩展点**：FastAPI 的 `app.dependency_overrides[get_db]` 机制可在测试中整体替换该依赖——**替换者必须与原依赖同形**（生成器 + finally 关闭），否则会话生命周期行为漂移。
- **约束**：本任务查询服务通过该依赖拿到的会话是**请求级**的；服务函数不得缓存会话引用；查询接口为只读，不调用 `commit`（避免隐式开启写事务）。

**（2）统一错误处理器（`backend/app/core/errors.py`）**

- **接口契约**：`ERROR_MAP` 为 `状态码 → (错误码, 安全文案)` 的静态映射；`error_response(status_code)` 按状态码查表构造统一错误体，未命中回落 500 文案；三个处理器分别覆盖 Starlette HTTP 异常、请求校验异常、未捕获异常。
- **业务规则**：`RequestValidationError` 处理器返回 422 `INVALID_REQUEST`（文案"请求参数校验失败"）——`limit` 越界与反馈请求体校验失败天然走此通道，无需新增逻辑。
- **扩展点**：现有机制仅以状态码为键，**无法表达"同一状态码、不同错误码"**（404 的"未知路径"与"会话不存在"两种语义）。扩展必须在**不修改既有 4 项映射**的前提下新增独立通道（见 2.1.3 决策 4）。
- **约束**：既有测试 `test_health.py`/`test_config.py` 断言了 404/405 的错误码与文案，扩展后其行为必须逐字不变。

**（3）回答状态与反馈原因码枚举（`backend/app/models/conversation.py:11-17`、`models/feedback.py:10-15`）**

- **接口契约**：两者均为 `str` 子类枚举——Pydantic v2 原生支持其与字符串的互转，序列化输出枚举的字符串值（如 `need_clarification`、`OUTDATED_CONTENT`）。
- **扩展点**：响应模型**直接复用**这两个枚举作为字段类型（而非在 schemas 层重复定义 Literal），保证"四态/六态"单一事实来源，避免双份定义漂移。
- **约束**：`result_status` 必须原样输出枚举值（spec 5.2.1 规则 6），禁止在响应模型中派生"待继续/已完成"字段（该推导属前端职责）。

**（4）时间列的存储与读回行为（`backend/app/models/base.py:16-17`、各模型时间列）**

- **接口契约**：时间列统一 `DateTime(timezone=True)` + 默认值 `utc_now()`（UTC 带时区）。
- **边界条件**：SQLite（测试落库形态）不保留 tzinfo，读回为**无时区标记**的 datetime；MySQL `DATETIME`（生产落库形态）经 PyMySQL 读回同样是 naive datetime。两个落库形态读回值的 tzinfo 均缺失，但值本身是 UTC。
- **约束**：契约 §1.1 要求时间戳输出 ISO 8601 **带时区**格式。序列化层必须将 tzinfo 缺失的值**视为 UTC** 补齐时区标记后输出（见 2.1.3 决策 5），测试与生产行为才能一致。

**（5）测试基建 fixture 链（`backend/tests/conftest.py`）**

- **依赖关系**：`alembic_cfg`（内存 SQLite URL）→ `db_engine`（StaticPool 内存库 + 外键 PRAGMA + 经迁移建表）→ `db_session`（会话工厂实例化）。
- **关键规则**：`db_engine` 中 schema 由 Alembic 迁移建立（非 `create_all`）——**迁移 0002 合入后，接口测试的建表结果自动携带新列**，无需改 fixture 建表逻辑。
- **缺口**：既有 `client` fixture（`TestClient(create_app())`）未替换数据库依赖，路由会话将指向真实 `Settings.database_url`——接口测试**不能直接复用** `client`，需新增替换依赖的数据库路由客户端（spec 4.4.3"接口路由的会话依赖须可被测试替换"的落点）。
- **约束**：新增 fixture 只能**追加**，既有 5 个 fixture 原样保留（不引入第二套测试基建）。

---

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

本模块位于应用工厂与数据库会话之间，上游是前端应用与 Pytest 验收测试，下游是既有 `get_db` 依赖与 MySQL/SQLite 数据库。

```plantuml
@startuml
left to right direction
skinparam componentStyle rectangle

actor "前端应用\n(Vue 3 + Vite)" as FE
actor "Pytest 验收测试" as Test

rectangle "基础业务接口\n(basic_business_api)" as API #D6EAF8
rectangle "应用工厂 create_app\n(backend_skeleton 交付物)" as App #F5F5F5
rectangle "统一错误处理器\n(core/errors.py)" as Err #F5F5F5
rectangle "get_db 会话依赖\n(database_modeling 交付物)" as Sess #F5F5F5
database "MySQL 8.x / 内存 SQLite\n(测试形态)" as DB #E8F6EF

FE --> App : HTTP（开发经 Vite 代理 :8000，低频匿名）
Test --> App : TestClient（dependency_overrides 注入内存库）
App --> API : include_router 挂载三路由
App --> Err : register_error_handlers（既有 + 本任务新增通道）
API --> Sess : Depends(get_db)（每请求一个会话）
Sess --> DB : 只读查询 / 反馈写入（低频）
API --> Err : 会话不存在时抛业务异常（404 + CONVERSATION_NOT_FOUND）
@enduml
```

交互说明：前端为唯一运行期调用方（匿名、低频、演示数据量级）；Pytest 全程使用内存 SQLite（经 `dependency_overrides` 替换会话依赖），不触碰 MySQL；错误通道经既有错误处理器统一收口，本任务仅新增一条业务异常通道。

### 2.1.2 服务/组件总体架构

组件按"路由 → 服务 → 模型/Schema"三层组织，遵循实施方案第六章 `backend/` 规划（api / schemas / services）。

```plantuml
@startuml
skinparam componentStyle rectangle

component "api 路由层" {
  [service_items.py\nGET /api/service-items]
  [conversations.py\nGET /api/conversations]
  [feedback.py\nPOST /api/feedback]
}

component "services 服务层" {
  [service_items 服务\n开放事项查询 + id 派生]
  [conversations 服务\n匿名隔离查询 + 计数]
  [feedback 服务\n存在性校验 + 原子写入]
}

component "schemas 响应模型层" {
  [service_item.py\nServiceItemResponse]
  [conversation.py\nConversationSummary/ListResponse]
  [feedback.py\nFeedbackRequest/Response]
  [common.py\nUtcDateTime + LimitParam]
}

component "core 公共层（改动最小化）" {
  [errors.py\n既有映射 + 新增业务异常通道]
  [responses.py\nUTF8JSONResponse（提取共享）]
}

database "models 模型层（database_modeling）" {
  (ServiceItem)
  (Conversation + session_token)
  (Feedback + 枚举)
}

component "main.py create_app\n（挂载 + 默认响应类）" as Main

Main --> [service_items.py]
Main --> [conversations.py]
Main --> [feedback.py]
[service_items.py] --> [service_items 服务] : 高频（每请求一次）
[conversations.py] --> [conversations 服务] : 高频（每请求一次）
[feedback.py] --> [feedback 服务] : 低频（用户反馈触发）
[service_items 服务] --> [ServiceItem]
[conversations 服务] --> [Conversation + session_token]
[feedback 服务] --> [Feedback + 枚举]
[service_items 服务] ..> [ServiceItemResponse]
[conversations 服务] ..> [ConversationSummary/ListResponse]
[feedback 服务] ..> [FeedbackRequest/Response]
[conversations.py] ..> [UtcDateTime + LimitParam]
[feedback 服务] --> [既有映射 + 新增业务异常通道] : 会话不存在抛异常
@enduml
```

**目录结构与改动边界总览**（★ = 本任务新增，☆ = 本任务改动既有交付物）：

| 路径 | 状态 | 说明 |
|------|------|------|
| `backend/app/main.py` | ☆ | `create_app` 内新增：3 个 router 挂载 + 默认响应类设置；签名/既有逻辑不动 |
| `backend/app/api/health.py` | 保留 | 原样不动（显式 `response_class` 优先，行为零变化） |
| `backend/app/api/service_items.py` | ★ | 事项查询路由 |
| `backend/app/api/conversations.py` | ★ | 会话查询路由（含 `X-Session-Token` 头读取） |
| `backend/app/api/feedback.py` | ★ | 反馈提交路由 |
| `backend/app/schemas/`（5 个模块 + `__init__.py`） | ★ | 响应模型、请求模型、`UtcDateTime`/`LimitParam` 公共类型 |
| `backend/app/services/`（3 个模块 + `__init__.py`） | ★ | 业务查询/写入逻辑 |
| `backend/app/core/errors.py` | ☆ | 新增业务异常类型与处理器；既有 `ERROR_MAP` 4 项与 3 个 handler 原样保留 |
| `backend/app/core/responses.py` | ★ | `UTF8JSONResponse` 共享定义（`health.py` 内同名类保持不动，二者行为一致） |
| `backend/app/core/config.py` | 保留 | 原样不动 |
| `backend/app/models/conversation.py` | ☆ | 同步加 `session_token` 列（模型-迁移零漂移约束）；其余三模型不动 |
| `backend/app/db/session.py` | 保留 | 原样不动 |
| `backend/alembic/versions/0002_*.py` | ★ | 匿名标识维度迁移（可升级可回滚） |
| `backend/tests/conftest.py` | ☆ | 追加数据库路由客户端与预置数据 fixtures；既有 5 个 fixture 原样保留 |
| `backend/tests/test_service_items.py` / `test_conversations.py` / `test_feedback.py` | ★ | 三接口测试 |
| `backend/tests/test_migrations.py` | ☆ | 版本断言 `"0001"` → `"0002"` |
| `backend/tests/test_models.py` | ☆ | `conversations` 列白名单补充 `session_token` |
| `scripts/seed_demo_data.py` | ☆ | `DEMO_CONVERSATIONS` 预置演示 token 常量（upsert 幂等语义不变） |

**配置项**：本任务不新增任何配置项（不引入新环境变量；匿名标识由调用方生成，服务端无密钥类配置）。

### 2.1.3 实现设计文档

#### （1）设计决策（含 spec 三项决策点裁决）

**【决策 1】ServiceItem 的 icon/tone/prompt 输出形态 —— 采纳 spec 缺省建议方案 A：响应仅含 `id`/`title`/`description`/`category` 四个必返字段，三可选字段不输出，不改表。**

理由：
1. **职责边界约束**：spec 1.4 规则 6 明确唯一允许的表变更是"匿名标识维度"，方案 B（加三列）超出该边界，且需同步迁移与 seed，违反"最小起步"。
2. **数据库事实**：`service_items` 表无三字段对应列（`models/service_item.py:9-23`），真实值无处可取。
3. **契约兼容**：契约 §3.1 将三字段标注为"否"（非必返）且明示 icon 有前端本地兜底（`frontend/src/data/service-icons.ts` 的 `FALLBACK_SERVICE_ICON = 'i-doc'` 已核实存在）——缺省字段由前端兜底是契约预期内行为。
4. **归属正确**：icon/卡片主题色/输入框预填文案均为纯展示属性，无后端消费方；存入数据库只会造成展示与数据职责混淆。

**【决策 2】匿名标识传递形式与缺失行为 —— 采纳 spec 缺省建议：自定义请求头 `X-Session-Token` 传递；未携带时返回 HTTP 200 与空列表、`total=0`（不查询数据库，直接短路）。**

理由：
1. **请求头优于查询参数**：头信息不出现在 URL 中，不进访问日志（Nginx access log）、不进浏览器历史、不被 Referer 泄露——与 spec 4.3.4"不采集、不传输身份关联信息"的安全取向一致；FastAPI 以 `Header(default=None)` 强类型读取，类型安全。
2. **缺失行为选空响应**：spec 决策点已注明前端 `fetchConversations` 当前不传匿名标识——若返回 400，前端历史页在未接线状态下必然报错（与 spec 5.2.3 场景 1c"前端历史页显示'暂无对话'，不报错"的用户预期相悖）；空响应与正常响应**结构一致**（`{"conversations": [], "total": 0}`），前端后续接线补充头时契约与响应结构零变更（spec 4.5.5 向后兼容）。
3. **红线不妥协**：未携带标识时短路返回，**不执行任何会话查询**——从机制上杜绝"全量返回"路径（spec 4.3.1 隐私红线）；空字符串头按未携带处理（边界规则，防绕过）。

**【决策 3】total 语义 —— 采纳 spec 缺省建议：该匿名标识下会话总数（分页语义），而非本次返回条数。**

理由：
1. **前端可感知性**：前端可展示"共 N 条对话"；`total` + `limit` 构成标准分页协议，为未来分页扩展预留（`total = 本次条数` 时字段冗余无信息量）。
2. **与契约一致**：契约 §4.4 示例中 `total: 1` 且返回 1 条，两语义在该示例上恰好重合，采纳分页语义与契约无冲突。
3. **实现成本相同**：同一过滤条件下的 count 与 `len(结果)` 开销等价（演示数据量级）。

**【决策 4】`CONVERSATION_NOT_FOUND` 错误码扩展方式 —— 新增业务异常类型（携带状态码 + 错误码 + 文案）与对应异常处理器，不修改既有 `ERROR_MAP`。**

理由：
1. **404 语义分流需求**：同一 404 状态码需区分"未知路径"（`INVALID_REQUEST`）与"会话不存在"（`CONVERSATION_NOT_FOUND`）两种错误码；既有静态映射仅以状态码为键，无法表达。
2. **回归保障**：若直接改写 `ERROR_MAP[404]`，未知路径的 404 语义被破坏，违反 spec 4.2.4"既有错误处理器行为不得变化"；新增独立通道则既有 4 项映射与 3 个 handler 逐字不变。
3. **最小侵入**：业务异常处理器复用既有统一错误体构造形态（`{"error": {code, message}}` + charset utf-8），前端无需新增解析逻辑；服务层抛异常而非在路由层构造响应，保持"路由薄、服务厚"的分层。

**【决策 5】时间序列化时区归一化 —— schemas 层定义统一的时区归一化类型：落库读回的 datetime 若无 tzinfo，按 UTC 补齐后以 ISO 8601 带时区（`+00:00`）输出。**

理由：
1. **两个落库形态行为不一致的固有缺口**：SQLite（测试）与 MySQL `DATETIME`（生产）读回值均无 tzinfo；`utc_now()` 写入的是 UTC 值——"无 tzinfo 即 UTC"的归一化与写入语义一致，测试与生产行为统一。
2. **契约强制**：契约 §1.1 要求 ISO 8601 带时区（如 `2026-09-27T09:42:00+08:00`）；UTC `+00:00` 是其合法形态（spec 6.2 示例的 `+08:00` 为本地时区形态，后端统一输出 UTC 即可，前端按 ISO 8601 解析无歧义）。
3. **单点收敛**：归一化逻辑收敛在 schemas 层一个类型定义上，三个接口的时间字段共用，不在服务层散落处理。

**【决策 6】前端 UI 标识（`id`）派生算法 —— 模块级显式映射表承载契约 §3.5 的 8 项固定映射，未命中编码按全小写兜底派生。**

理由：
1. **契约映射表不可机械推导**：`S01→student-card`、`S03→repair` 等映射是业务命名（非编码形态转换），必须显式维护映射表，与前端 `SERVICE_ICON` 维护的 kebab-case 键对齐。
2. **兜底算法确定性**：spec 5.1.1 规则 2c 要求映射表未覆盖的编码按 kebab-case 规则派生——kebab-case 的最简确定性形态为**全小写**（如 `S09` → `s09`，无分隔符需求时不引入词形切分等不可靠启发式），规则简单、可测、无歧义。
3. **单点维护**：映射表收敛在事项查询服务模块内一处定义，排序与派生共用。

#### （2）流程设计

**反馈提交分支设计（活动图）**——本任务唯一写入路径，分支最多：

```plantuml
@startuml
start
:接收 POST /api/feedback;
:Pydantic 请求体校验
(必填/枚举四态/短评≤200字);
if (校验通过?) then (否)
  :异常处理器返回 422 统一错误体
  (INVALID_REQUEST，不产生落库);
  stop
else (是)
endif
:会话存在性检查 (按 conversation_id);
if (会话存在?) then (否)
  :服务层抛业务异常
  → 404 CONVERSATION_NOT_FOUND
  (不产生落库);
  stop
else (是)
endif
:构造反馈记录
(conversation_id/helpful/reason_code/comment
created_at = 服务端 UTC 时间);
:commit 提交事务;
if (写入成功?) then (是)
  :返回 200 {"status": "ok"};
else (否，数据库异常)
  :rollback 回滚（不留半截数据）;
  :异常处理器返回 500 统一错误体;
endif
stop
@enduml
```

**会话查询分支设计**（分支规则文字说明，红线以短路实现）：

| 分支 | 触发条件 | 处理策略 |
|------|---------|---------|
| 标识缺失/空白 | `X-Session-Token` 头缺失，或去除首尾空白后为空串 | **短路返回** 200 `{"conversations": [], "total": 0}`，不执行任何数据库查询（隐私红线，杜绝全量路径） |
| 正常隔离查询 | 头存在且非空白 | 按标识过滤 + 最近消息时间倒序 + `limit` 截断取摘要；同过滤条件计数作为 `total` |
| 标识下无会话 | 过滤结果为空 | 200 `{"conversations": [], "total": 0}`（与缺失形态结构一致） |
| limit 越界/非整数 | `limit` < 1、> 50 或非整数 | Pydantic 参数校验失败 → 既有处理器返回 422 统一错误体 |
| 数据库异常 | 查询执行失败 | 既有处理器返回 500 统一错误体，不泄露数据库细节 |

**事项查询分支设计**：

| 分支 | 触发条件 | 处理策略 |
|------|---------|---------|
| 正常查询 | 数据库存在记录 | 仅 `enabled = true` 行 → 按编码升序 → 派生 `id` → 输出四必返字段数组 |
| 库中无开放事项 | 过滤结果为空 | 200 空数组（**不得返回 404**，spec 5.1.1 规则 1c） |
| 编码不在 8 项映射表 | 兜底派生分支 | 按全小写派生 `id`（决策 6） |
| 携带未定义查询参数 | URL 含未定义参数 | FastAPI 默认忽略，正常返回（spec 5.1.1 规则 6a，无额外代码） |
| 数据库异常 | 查询执行失败 | 既有处理器返回 500 统一错误体 |

#### （3）扩展点设计

| 扩展点 | 扩展接口 | 默认实现 | 未来扩展方向 |
|--------|---------|---------|-------------|
| 业务错误码通道 | `core/errors.py` 新增业务异常类型（状态码 + 错误码 + 文案三要素）与处理器 | 会话不存在场景使用（404 + `CONVERSATION_NOT_FOUND`） | 问答接口任务（第 4/5 周）复用该通道新增 `RATE_LIMITED`/`UPSTREAM_TIMEOUT` 等错误码，无需再改错误处理器结构 |
| 前端 UI 标识派生 | 事项查询服务内映射表常量 + 兜底派生函数 | 8 项契约映射 + 全小写兜底 | 新增事项（S09+）时：库内插行即可（兜底生效）；纳入契约映射表则补一行映射 |
| 匿名标识写入 | `conversations.session_token` 列（本任务交付定义与查询侧消费） | 无 default（写入路径属第 5 周） | 问答接口任务在会话创建时落库调用方标识（UUID v4 形态，不可预测）；本任务测试 fixtures/seed 预置标识值 |
| 请求头契约 | `X-Session-Token` 头（本任务引入） | 服务端可选读取（缺失容错） | 前端接线时补充传递；契约 §1.2 补录该头定义（文档层面，随前端任务提交） |

#### （4）事务设计

- **唯一写事务**：反馈提交。边界为"会话存在性检查 → 构造记录 → commit"；`commit` 异常时 `rollback`——事务内仅一条 INSERT，原子性保证"校验失败或会话不存在时零落库、成功则记录完整"（spec 4.2.2），不存在半截数据形态。
- **会话生命周期**：服务函数持有请求级会话（`get_db` 依赖的 `finally` 关闭兜底资源释放）；查询接口只读不 `commit`（避免隐式写事务开启）。
- **数据库不可用**：既有 `Exception` 处理器兜底返回 500 统一错误体（8 秒内，本地引擎连接失败立即抛出，无挂起路径）；连接级超时由既有引擎配置（`pool_pre_ping`）与数据库侧保证。

## 2.2 接口设计

### 2.2.1 总体设计

接口分三类：HTTP 路由（对外契约）、服务层函数（内部契约）、公共类型与异常（基础设施契约）。无接口继承体系；HTTP 契约以 `docs/api.md` 为唯一权威，本任务不修改契约文档（`X-Session-Token` 头定义随前端接线任务补录）。

| 接口 | 类别 | 形态 | 稳定性 |
|------|------|------|--------|
| `GET /api/service-items` | HTTP 路由 | 同步查询，直数组响应 | 稳定（契约 §4.2 定稿） |
| `GET /api/conversations` | HTTP 路由 | 同步查询，包装响应 | 稳定（契约 §4.4，头名随前端任务补录文档） |
| `POST /api/feedback` | HTTP 路由 | 同步写入，确认响应 | 稳定（契约 §4.5 定稿） |
| 事项查询服务 | 服务层 | 会话 → 摘要数组 | 稳定（内部） |
| 会话查询服务 | 服务层 | 会话 + 标识 + limit → 包装响应 | 稳定（内部） |
| 反馈写入服务 | 服务层 | 会话 + 请求模型 → 无返回（异常表失败） | 稳定（内部） |
| 业务异常类型 | 基础设施 | 状态码 + 错误码 + 文案 | 稳定（问答任务复用） |
| `UtcDateTime` / `LimitParam` | 基础设施 | schemas 公共类型 | 稳定（内部） |

**接口变更策略**：HTTP 契约字段只增不删不改名（契约 §3 定稿）；服务层函数新增参数一律带安全缺省值；错误码只增不删（`INVALID_REQUEST`/`INTERNAL_ERROR` 语义锁定）。

### 2.2.2 接口清单

#### `GET /api/service-items`

- **接口签名**：`GET /api/service-items`，无查询参数；响应模型为摘要数组（**直接数组，无包装对象**）。
- **业务说明**：返回系统支持的办事事项，供首页服务行与支持事项列表消费。
- **前置条件**：无（匿名访问，无认证）。
- **后置条件**：无副作用（只读）；`enabled = false` 事项被排除但库中记录不变。
- **异常映射**：方法非 GET → 405 `INVALID_REQUEST`（既有）；数据库异常 → 500 `INTERNAL_ERROR`（既有）。**空表返回 200 空数组，非 404。**

响应形态（契约 §3.1，字段映射 `title` ← `name` 列，`id` ← 编码派生）：

```json
[
  {
    "id": "student-card",
    "title": "学生证补办",
    "description": "材料、流程与办理地点",
    "category": "证件"
  }
]
```

`id` 派生映射（契约 §3.5 逐项一致）：`S01→student-card`、`S02→campus-card`、`S03→repair`、`S04→leave`、`S05→scholarship`、`S06→grant`、`S07→major-transfer`、`S08→graduation`；未覆盖编码按全小写兜底（`S09→s09`）。

#### `GET /api/conversations`

- **接口签名**：`GET /api/conversations`，查询参数 `limit`（整数，缺省 10，取值 1–50 含边界）；请求头 `X-Session-Token`（可选，匿名标识）；响应模型为包装对象。
- **业务说明**：返回当前匿名标识下最近会话摘要，供历史记录页消费。
- **前置条件**：无（匿名访问）；**隐私红线**：仅返回请求头标识下的会话，禁止全量或他人会话（OWASP A01）。
- **后置条件**：无副作用（只读，重复调用结果一致）。
- **异常映射**：`limit` 越界/非整数 → 422 `INVALID_REQUEST`（既有）；标识缺失/空白 → **200 空响应**（非错误）；数据库异常 → 500 `INTERNAL_ERROR`（既有）。

响应形态（契约 §3.4 六字段，`last_intent` 无值时**显式输出 null**；时间 ISO 8601 带时区）：

```json
{
  "conversations": [
    {
      "id": "9f0d1b2e-3c4a-4d5e-8f60-1a2b3c4d5e01",
      "question": "学生证丢了怎么补办？",
      "last_intent": "S01",
      "result_status": "answered",
      "started_at": "2026-09-27T09:42:00+00:00",
      "last_message_at": "2026-09-27T09:43:10+00:00"
    }
  ],
  "total": 1
}
```

字段语义要点：`result_status` 原样输出回答状态枚举值（"待继续/已完成"推导属前端）；`total` 为该标识下会话总数（决策 3）；排序按最近消息时间倒序。

#### `POST /api/feedback`

- **接口签名**：`POST /api/feedback`，请求体含 `conversation_id`（字符串非空，必填）、`helpful`（布尔，必填）、`reason_code`（四态枚举，可空）、`comment`（字符串 ≤200 字，可空）；响应体仅含 `status`。
- **业务说明**：提交对某次回答的反馈，供反馈栏消费；同一会话允许多次提交（追加语义，不去重）。
- **前置条件**：`conversation_id` 必须为已存在会话的标识（外键严格校验策略）。
- **后置条件**：成功则反馈表新增一条完整记录（提交时间为服务端 UTC 时间）；失败（校验失败/会话不存在）则**零落库**。
- **异常映射**：必填缺失/枚举越界/短评超 200 字/请求体非合法 JSON → 422 `INVALID_REQUEST`（既有）；会话不存在 → 404 **`CONVERSATION_NOT_FOUND`**（本任务新增通道）；数据库写入异常 → 500 `INTERNAL_ERROR`（既有，事务回滚不留半截数据）。

请求/响应形态（契约 §4.5）：

```json
// 请求体
{
  "conversation_id": "9f0d1b2e-3c4a-4d5e-8f60-1a2b3c4d5e02",
  "helpful": false,
  "reason_code": "OUTDATED_CONTENT",
  "comment": "办理地点似乎已经发生变化"
}

// 响应体（仅含 status，不得携带额外信息）
{ "status": "ok" }
```

`reason_code` 四态（契约 §3.6）：`SOURCE_ERROR` / `INCOMPLETE_STEPS` / `OUTDATED_CONTENT` / `OTHER`；允许缺省（落库为空），无论 `helpful` 取值如何。

#### 服务层内部接口签名

| 接口 | 签名（方法名 / 入参 / 出参） |
|------|------------------------------|
| 事项查询服务 | `list_enabled_service_items(session: Session) -> list[ServiceItemResponse]`：入参为请求级数据库会话；出参为摘要数组 |
| 会话查询服务 | `list_conversations(session: Session, session_token: str | None, limit: int) -> ConversationListResponse`：入参含可空标识与条数；出参为包装响应 |
| 反馈写入服务 | `submit_feedback(session: Session, payload: FeedbackRequest) -> None`：入参为会话与请求模型；成功无返回值，会话不存在时抛业务异常 |
| 业务异常 | `BusinessError(status_code: int, code: str, message: str)`：三要素构造，由错误处理器渲染为统一错误体 |

## 2.3 数据模型

### 2.3.1 设计目标

- **支持场景**：三个接口的强类型请求/响应——事项摘要（契约 §3.1）、会话摘要与列表包装（§3.4）、反馈请求与确认（§4.5）；以及会话表匿名标识维度的落库支撑（spec 5.4）。
- **性能与容量**：演示数据量级（8 事项、十余会话/反馈），响应模型序列化开销可忽略；会话隔离查询依赖既有 `last_message_at` 索引 + 新增 `session_token` 索引（过滤列），无额外容量设计。
- **与存量数据的兼容策略**：`session_token` 列**可空**——既有记录（迁移前的数据）该值为 NULL，不归属任何匿名标识，隔离查询天然不命中（SQL 语义下 NULL 不等于任何非空值），防止存量数据泄露（spec 5.4.3 场景 3）；新写入由问答任务补齐。既有四张表的其余列定义**零变更**（spec 1.4 规则 6）。

### 2.3.2 模型实现

接口层领域对象与 ORM 的关系：响应模型为 ORM 行的投影（非聚合），反馈请求模型为独立的输入契约对象。

```plantuml
@startuml
class ServiceItemResponse <<响应模型>> {
  +id: str
  +title: str
  +description: str
  +category: str
}

class ConversationSummaryResponse <<响应模型>> {
  +id: str
  +question: str
  +last_intent: str | None
  +result_status: AnswerStatus
  +started_at: UtcDateTime
  +last_message_at: UtcDateTime
}

class ConversationListResponse <<响应模型>> {
  +conversations: list[ConversationSummaryResponse]
  +total: int
}

class FeedbackRequest <<输入契约>> {
  +conversation_id: str
  +helpful: bool
  +reason_code: FeedbackReasonCode | None
  +comment: str | None
}

class FeedbackResponse <<响应模型>> {
  +status: str = "ok"
}

class ServiceItem <<ORM，既有>> {
  +code: str
  +name: str
  +category: str
  +description: str
  +enabled: bool
}

class Conversation <<ORM，本任务加列>> {
  +id: str
  +question: str
  +last_intent: str | None
  +result_status: AnswerStatus
  +started_at: datetime
  +last_message_at: datetime
  +session_token: str | None
}

class Feedback <<ORM，既有>> {
  +conversation_id: str
  +helpful: bool
  +reason_code: FeedbackReasonCode | None
  +comment: str | None
}

ServiceItemResponse ..> ServiceItem : 投影\n(0..1 行 → 1 对象)
ConversationSummaryResponse ..> Conversation : 投影\n(0..1 行 → 1 对象)
ConversationListResponse o-- "0..*" ConversationSummaryResponse
FeedbackRequest ..> Conversation : 会话存在性引用\n(1 → 0..1)
FeedbackRequest ..> Feedback : 写入依据\n(1 请求 → 1 记录)
FeedbackResponse ..> FeedbackRequest : 成功确认\n(1 → 1)
@enduml
```

- **对象关系说明**：三个响应模型为 ORM 行的只读投影（组合自 ORM，生命周期随请求结束）；`ConversationListResponse` 聚合零到多个摘要；`FeedbackRequest` 是唯一输入契约，其 `conversation_id` 引用既有会话（存在性校验后写为一条 `Feedback` 记录）。
- **投影字段映射**：`ServiceItemResponse.title` ← ORM `name`（契约 §3.1 定稿映射）；摘要模型字段与 ORM 同名直取（database_modeling 已保证表列名与契约一致，spec 4.4.5 零转换）。
- **本任务唯一 ORM 变更**：`Conversation` 增加 `session_token`（字符串、可空、索引），与迁移 0002 同步（模型-迁移零漂移，既有 `compare_metadata` 断言保持通过）。
- **持久化策略**：响应模型不持久化（无表）；反馈记录经既有 ORM `Feedback` 落库（提交时间 `created_at` 由服务端 UTC 默认值填充）；会话写入路径（含 `session_token` 落库）属第 5 周问答任务，本任务不涉及。
- **创建与销毁策略**：模型对象由 Pydantic 在请求处理中构造、随请求销毁；无跨请求缓存。