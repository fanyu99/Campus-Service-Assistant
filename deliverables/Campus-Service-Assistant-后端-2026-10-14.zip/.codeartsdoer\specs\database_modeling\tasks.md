# 数据库建模（database_modeling）任务清单

> 依据：`.codeartsdoer/specs/database_modeling/spec.md`（需求规格）、`.codeartsdoer/specs/database_modeling/design.md`（技术设计）
> 任务范围：四张表 SQLAlchemy 模型定义、MySQL 建库脚本、Alembic 迁移初始化、`scripts/seed_demo_data.py` 演示数据、Pytest 测试与 MySQL 冒烟清单；**不含**业务接口、业务服务层、AgentArts 适配层
> 验证命令：`cd backend && pytest -q`（PowerShell，SQLite 内存库，零外部依赖）
> 编制日期：2026-10-10

---

## 1. 准备数据库依赖与虚拟环境

> 基础设施任务，为后续全部任务提供运行环境；设计裁决：MySQL 8 默认认证插件 `caching_sha2_password` 需要 `cryptography` 支持，四条依赖一次补齐。

- [ ] 在 `backend/requirements.txt` 追加 `sqlalchemy>=2.0`、`alembic`、`pymysql`、`cryptography` 四条依赖，不改动任何既有条目（fastapi / uvicorn / pydantic-settings 保持原样）
- [ ] 在 `backend/.venv` 虚拟环境中执行依赖安装（运行时与开发两份清单一起装），并验证 `sqlalchemy`、`alembic`、`pymysql` 三个包均可成功导入
- [ ] 确认既有骨架用例不回归：在 `backend/` 目录执行 `pytest -q`，既有 `tests/test_config.py` 与 `tests/test_health.py` 全部通过

## 2. 定义四张表的 ORM 模型（backend/app/models/）

> 按实施方案第六章目录归位；表名列名与 spec §6.1–6.4 逐字锁定（snake_case）；三组枚举以独立 Python enum 类定义，落库字符串值与契约 §3.2/§3.3/§3.6 逐值一致；依赖顺序：base → service_item → source_document / conversation → feedback。

- [ ] 创建 `backend/app/models/base.py`：定义统一声明基类 `Base`（DeclarativeBase 子类），其 metadata 携带统一约束命名约定（索引 `ix_`、唯一 `uq_`、检查 `ck_`、外键 `fk_`、主键 `pk_` 前缀），保证 Alembic autogenerate 产出稳定约束名
- [ ] 创建 `backend/app/models/service_item.py`：定义 `ServiceItem` 模型（`service_items` 表）——`id` 自增主键、`code` String(8) 唯一非空（S01–S08 业务主键）、`name`/`category`/`description` 非空、`enabled` 布尔默认 True（停用保留记录不物理删除）、`created_at`/`updated_at` 带 UTC 默认值且 `updated_at` 随更新自动维护
- [ ] 创建 `backend/app/models/source_document.py`：定义 `SourceDocument` 模型（`source_documents` 表）——字段完整覆盖契约 §4.6 全部响应字段（title、department、official_url、publish_date、effective_from、effective_to、audience、campus、status、version、reviewed_at），`service_item_id` 外键指向 `service_items.id`（RESTRICT）并建索引，`status` 为 `KnowledgeStatus` 四态枚举（draft/verified/expired/conflict，默认 draft），`effective_to` 设 CHECK 约束不得早于 `effective_from`，`reviewed_at` 允许为空
- [ ] 创建 `backend/app/models/conversation.py`：定义 `Conversation` 模型（`conversations` 表）——`id` 为 String(36) 主键且模型层默认生成 UUID v4（不可预测，禁止可枚举顺序数字）、`question` 与 `last_message_at` 按契约 §3.4 补齐（`last_message_at` 建索引）、`last_intent` 可空外键指向 `service_items.code`、`result_status` 为 `AnswerStatus` 六态枚举（answered/need_clarification/unsupported/insufficient_evidence/conflict/service_error）、时间列 `timezone=True`；**隐私红线：类属性仅限白名单六列，不含姓名、学号、身份证号、银行卡号、账号密码等任何个人身份信息字段**
- [ ] 创建 `backend/app/models/feedback.py`：定义 `Feedback` 模型（`feedback` 表）——`conversation_id` 外键指向 `conversations.id`（严格拒绝策略）并建索引、`helpful` 布尔非空、`reason_code` 为 `FeedbackReasonCode` 四态枚举且允许为空（helpful=true 时无原因码）、`comment` String(200) 可空（对齐契约 §4.5 ≤ 200 字）、`created_at` 带 UTC 默认值
- [ ] 创建 `backend/app/models/__init__.py`：汇总导出四个模型类与三个枚举类（`KnowledgeStatus`/`AnswerStatus`/`FeedbackReasonCode`），供 `alembic/env.py` 的 target_metadata 与后续业务层单点导入

## 3. 实现数据库会话管理（backend/app/db/）

> 骨架任务预留的挂载点；零改动复用 `app/core/config.py` 的 `Settings` 装载链；本任务不挂载任何路由。

- [ ] 创建 `backend/app/db/session.py`：实现同步 engine 工厂 `create_db_engine(url)`（url 缺省取 `Settings.database_url`，连接参数含 `pool_pre_ping=True` 与 `pool_recycle=3600`，惰性连接不立即触碰数据库）
- [ ] 在 `backend/app/db/session.py` 中实现会话工厂 `create_session_factory(engine)`（统一 `expire_on_commit=False`）与 FastAPI 依赖注入形态的 `get_db()` 生成器（yield 交付请求级 session，finally 必然关闭，无连接泄漏）

## 4. 初始化 Alembic 迁移并建立初始迁移（backend/）

> 迁移为表结构唯一定义点（spec 4.4.2 禁止手工改表）；连接串不写入 `alembic.ini`，由 env.py 经骨架 `Settings` 装载链注入（环境变量 > `.env` > 内置缺省），防口令入库。

- [ ] 在 `backend/` 目录下初始化 Alembic，生成 `alembic.ini` 与 `alembic/` 目录（`env.py`、`script.py.mako`、`versions/`）
- [ ] 改造 `backend/alembic/env.py`：连接串经 `Settings` 装载链注入（`alembic.ini` 中不写入任何连接串），`target_metadata` 指向 `app.models` 的 `Base.metadata`，并支持测试路径经 `set_main_option` 覆盖为内存 SQLite URL
- [ ] 编写初始迁移 `backend/alembic/versions/0001_initial_schema.py`：一次性建立全部四张表 + 索引 + 约束（spec 5.2.1 规则 2a），upgrade 含 `mysql_engine=InnoDB` 与 `mysql_charset="utf8mb4"` 方言参数（非 MySQL 方言静默忽略），downgrade 逆序 drop 四张表不留残留
- [ ] 验证迁移回环：对空库执行 upgrade head → downgrade base → upgrade head 全程成功，回滚后无表残留、再次升级结构恢复一致（spec 4.2.2）

## 5. 实现建库脚本与演示数据脚本（scripts/）

> 脚本归位仓库根 `scripts/`（实施方案第六章规划位置）；建库与建表分离——Alembic 只管表结构，建库脚本负责 utf8mb4 建库；两步固定操作序列：建库 → `alembic upgrade head`。

- [ ] 创建 `scripts/create_database.py`：实现幂等建库 `create_database(url)`——从连接串剥离库名直连 server 端执行 `CREATE DATABASE IF NOT EXISTS campus CHARACTER SET utf8mb4`，库已存在时静默跳过不破坏数据；server 不可达时输出可读错误说明（**错误信息不得包含数据库口令**）后以非零退出码退出
- [ ] 创建 `scripts/seed_demo_data.py` 的核心函数 `seed_demo_data(session)`：前置检查四张表存在性（未建表则输出可读提示「请先执行建库与 alembic upgrade head」并终止，不产生半截数据）→ 单事务按稳定逻辑键 upsert（service_items 按 `code`、source_documents 按 `service_item_id + official_url`、conversations 按固定演示 UUID、feedback 按 `conversation_id`）→ 返回各表写入/更新数量的报告，任一步骤失败整体回滚
- [ ] 完成 `scripts/seed_demo_data.py` 的演示数据内容与脚本入口：S01–S08 共 8 条事项与契约 §3.5 映射表逐项一致（S01 学生证补办 … S08 毕业手续）；每项事项至少配套一条来源文档（官方地址仅用 `example.edu.cn` 示例域名的 http/https 绝对地址，部门与人员信息全部虚构，知识状态覆盖 draft/verified/expired/conflict 四态）；写入少量演示会话（固定演示 UUID，回答状态六态取代表性子集）与配套反馈（四原因码覆盖）；入口经 `Settings` 装载配置，完成后报告各表数量且**不输出任何口令与个人身份信息**
- [ ] 验证脚本幂等与异常路径：seed 脚本连续执行两遍后各表数据总量保持不变；未建表时执行 seed 得到可读提示且数据库无脏数据残留

## 6. 编写 Pytest 测试套件（backend/tests/）

> 设计裁决：SQLite 内存库承载全量自动化测试（本机无 MySQL 也能全部通过）；每用例独立建表、不依赖执行顺序；既有 `client` / `clear_settings_cache` fixture 原样保留。

- [ ] 在 `backend/tests/conftest.py` 增量追加数据库 fixtures：内存 SQLite engine（开启 `foreign_keys=ON` PRAGMA 保证外键约束生效）、经初始迁移建表、测试级 session 供给；既有应用层 fixtures 不改动
- [ ] 编写 `backend/tests/test_models.py` 模型约束测试，覆盖五类断言：四张表字段齐备（逐列核对 spec §6.1–6.4）、`code` 重复写入被唯一约束拒绝、三组枚举非法值写入被拒绝（知识状态四态/回答状态六态/反馈原因码四态）、来源关联不存在事项与反馈关联不存在会话被引用完整性拒绝（`IntegrityError`）、conversations 表列集合白名单断言无任何个人身份信息字段
- [ ] 编写 `backend/tests/test_migrations.py` 迁移测试：程序化执行 upgrade → downgrade → upgrade 回环断言表数量与版本正确、经 `compare_metadata` 断言迁移产物与模型元数据零漂移（spec 4.2.4）
- [ ] 编写 `backend/tests/test_seed.py` 演示数据测试：seed 核心函数注入测试 session，两遍执行计数不变（幂等）、S01–S08 编码与契约 §3.5 逐项一致、全部 `official_url` 为 http/https 绝对地址、来源数据覆盖知识状态四态

## 7. 编写 MySQL 冒烟清单文档（backend/docs/）

> 设计裁决：MySQL 专属行为（utf8mb4 落库、原生 ENUM DDL、`caching_sha2_password` 认证、连接字符集）不属 SQLite 自动化覆盖范围，以文档化冒烟清单承载，真实 MySQL 可用时手动逐项核验。

- [ ] 创建 `backend/docs/mysql-smoke-checklist.md`：按固定操作序列列出逐项检查清单——建库（`python scripts/create_database.py`）→ 迁移（`alembic upgrade head`）→ 演示数据（`python scripts/seed_demo_data.py`）→ 零漂移核验（`alembic check`）→ 字符集核验（`SHOW VARIABLES LIKE 'character%'` 确认 utf8mb4）→ 认证与连接核验（PyMySQL 连接真实 MySQL 8 的 caching_sha2_password 行为）→ 时间字段抽样核验（ISO 8601 带时区还原），每项附命令形态与期待输出

## 8. 全量验证与交付检查

> 最终验证组：测试通过、安全红线、设计一致性三关全过方可交付。

- [ ] 在 `backend/` 目录执行 `pytest -q` 全部通过且退出码为 0（含既有骨架用例无回归），并观察空库迁移与 seed 耗时满足性能约束（迁移总耗时 ≤ 30 秒、seed ≤ 10 秒）
- [ ] 执行安全检查：全部交付代码无数据库口令硬编码（连接串仅经 `Settings` 装载链取得，`alembic.ini` 无连接串）、`.env` 保持 git 忽略状态未被提交、演示数据全部虚构且演示来源地址仅用示例域名、脚本输出与报告不含口令及个人身份信息
- [ ] 执行设计一致性核对：表名列名与 spec §6.1–6.4 逐字一致、枚举落库值与契约 §3.2/§3.3/§3.6 逐值一致、连接串缺省值与 `docker-compose.yml` db 注释段逐字一致、未触碰骨架交付物（`app/main.py`、`api/health.py`、`core/errors.py`、`docker-compose.yml` 保持原样）

---

## 任务依赖关系

```
1 依赖准备 ─┬─→ 2 ORM 模型 ─┬─→ 4 Alembic 迁移 ─┬─→ 5 建库/演示脚本 ─┬─→ 6 测试套件 ─┬─→ 8 全量验证
            │               │                   │                   │             │
            └─→ 3 会话管理 ─┴───────────────────┴───────────────────┴─→ 7 冒烟清单 ─┘
```

- 任务 1 为前置基础设施；任务 2 与任务 3 可并行（3 仅依赖 1 与骨架 config）
- 任务 4 依赖任务 2（target_metadata 需要模型元数据）；任务 5 依赖任务 2/3/4（seed 需模型、会话与已建表）
- 任务 6 依赖任务 2/4/5；任务 7 依赖任务 4/5 的交付物（可与 6 并行）
- 任务 8 为收尾验证，依赖全部前序任务