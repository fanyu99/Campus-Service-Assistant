# 后端骨架（backend_skeleton）需求规格

> 依据：`docs/api.md`（前后端唯一权威契约，同时为后端实现规格）、《校园办事小秘书实施方案》第五章/第六章/第十章/第3周计划/第十四章、`docker-compose.yml` 编排注释
> 任务范围：backend/ 目录结构、FastAPI 应用入口、核心配置装载、/api/health 健康检查；**不含**数据库建模、业务接口、AgentArts 适配层
> 编制日期：2026-10-08

---

# **1. 组件定位**

## **1.1 核心职责**
本组件负责提供 FastAPI 服务运行底座与健康检查接口，实现前后端联调探测与部署自测的最小可用入口。

## **1.2 核心输入**
1. **健康探测请求**：前端应用（开发环境经 Vite 代理 `/api` → `http://localhost:8000`）或开发者发起的 `GET /api/health` 请求。
2. **配置输入**：后端开发者通过环境变量或本地 `.env` 文件提供的服务运行参数（监听端口、环境标识，以及预留的数据库连接串、云服务密钥占位）。
3. **编排启动信号（计划中）**：Docker Compose 的 backend 服务段以 `./backend` 为构建上下文启动容器（当前该段处于注释状态，待后端代码就绪后启用）。
4. **测试触发**：开发者或验收人员在 `backend/` 目录执行 Pytest 测试命令（`pytest -q`）。

## **1.3 核心输出**
1. **健康检查响应**：HTTP 200 与 JSON 响应体 `{"status": "ok"}`（`Content-Type: application/json; charset=utf-8`），供前端 `checkHealth()` 与部署自测（`frontend/docs/deploy.md` §6）消费。
2. **服务监听**：服务进程在 **8000 端口**监听 HTTP 请求，与 Vite 代理目标（`localhost:8000`）及 Nginx 反代目标（`http://backend:8000`）保持一致。
3. **启动反馈**：服务启动完成后向控制台输出就绪信息（含监听地址与端口）。
4. **测试结果**：Pytest 运行的通过/失败报告（退出码 0 表示全部通过）。

## **1.4 职责边界**
本组件**不负责**以下事项（属后续任务或其他组件）：
1. 不实现任何业务接口：`/api/service-items`、`/api/chat/messages`、`/api/feedback`、`/api/conversations`、`/api/knowledge/sources` 均不在本任务范围内。
2. 不进行数据库建模、建表与数据访问：骨架不连接 MySQL（MySQL 接入属第 3 周后续清单）。
3. 不实现 AgentArts 适配层与智能体工作流（属第 4 周）。
4. 不实现认证鉴权：原型阶段全部接口匿名访问（契约 §1.1）。
5. 不引入业务错误码体系：`INVALID_REQUEST` 等业务错误码随业务接口引入（契约 §2.3）。
6. 不负责 CORS 策略配置：契约明确生产（Nginx 同域反代）与开发（Vite 代理）均无需开启 CORS。
7. 不负责容器化改造：不提供 Dockerfile、不修改 `docker-compose.yml` 的 backend/db 注释段（待后端代码整体就绪后统一启用）。

# **2. 领域术语**

**后端骨架（Backend Skeleton）**
: 仓库中新建的 `backend/` 目录及其包含的 FastAPI 应用入口、核心配置装载与健康检查接口构成的最小可运行集合。

**健康检查（Health Check）**
: 用于联调探测与部署自测的只读接口，前端 `checkHealth()` 与部署文档均依赖它判断后端是否可达。

**API 前缀（/api）**
: 前后端契约约定的统一接口路径前缀；生产由 Nginx 反代到 `http://backend:8000`，开发由 Vite 代理到 `http://localhost:8000`。

**配置装载（Configuration Loading）**
: 服务启动时从环境变量或 `.env` 文件读取服务运行参数的过程；真实密钥只存在于环境变量，绝不进入代码或版本库。

**服务名 backend**
: Docker Compose 中后端服务的约定名称；`frontend/nginx.conf` 将 `/api/` 反代到 `http://backend:8000`，服务名变更将导致生产联调 502。

# **3. 角色与边界**

## **3.1 核心角色**
后端开发者（成员三，智能体与后端架构负责人）：创建骨架、提供环境变量配置、启动服务并运行 Pytest 测试。
前端开发者（成员二，交互与前端开发负责人）：在联调阶段调用健康检查探测后端可达性。
测试与验收人员：依据第 3 周验收清单验证健康检查、密钥不入库与测试通过。

## **3.2 外部系统**
前端应用（Vue 3 + Vite）：开发环境经 Vite 代理向 `/api/health` 发起 GET 请求，消费 `{"status": "ok"}` 响应。
Docker Compose 编排：backend 服务段（注释状态）以 `./backend` 为构建上下文；本骨架需保证未来启用时可被构建启动。
Git 版本库：`.env` 必须在忽略列表中，真实密钥不得进入提交历史。
MySQL 数据库：本阶段**不存在交互**（骨架不建连），数据库接入属后续任务。

## **3.3 交互上下文**

```plantuml
@startuml
left to right direction
skinparam actorStyle awesome

actor "后端开发者\n（成员三）" as Dev
actor "前端开发者\n（成员二）" as FrontDev
actor "测试/验收人员" as Tester

rectangle "前端应用\n（Vue 3 + Vite）" as FE #F5F5F5
rectangle "Docker Compose 编排\n（backend 段计划中）" as Compose #F5F5F5
rectangle "Git 版本库" as Git #F5F5F5

rectangle "后端骨架\n（Backend Skeleton）" as BE #D6EAF8

Dev --> BE : 启动服务 / 提供环境变量配置
FrontDev --> FE : 触发联调探测
FE --> BE : GET /api/health（Vite 代理）
Tester --> BE : 运行 Pytest 验收测试
Compose --> BE : 以 ./backend 为构建上下文（未来启用）
Dev --> Git : 提交代码（.env 被忽略，密钥不入库）
@enduml
```

# **4. DFX约束**

## **4.1 性能**
1. 健康检查接口响应时间不得超过 1 秒（P95，本地开发环境；须远低于前端 8 秒请求超时阈值，契约 §1.1）。
2. 服务从启动到可响应健康检查的就绪时间不得超过 30 秒（本地环境，骨架阶段约定）。
3. 骨架阶段不设吞吐量指标（待定：正式指标随业务接口在设计阶段确定）。

## **4.2 可靠性**
1. 健康检查不得因数据库或云服务不可用而失败：骨架阶段服务无外部依赖；后续接入 MySQL 后，健康检查仍保持固定响应结构。
2. 容器化运行（计划中的 backend 段）下，服务异常退出由编排层 `restart: unless-stopped` 拉起。
3. 原型阶段可用性目标待定（以"现场演示期间服务不中断"为准）。

## **4.3 安全性**
1. 真实云服务密钥不得出现在任何代码文件中（第 3 周验收明确要求："代码中不存在真实云密钥"）。
2. `.env` 必须加入版本控制忽略列表；云密钥只存在于后端环境变量（实施方案第十四章、编排注释）。
3. 匿名访问：不采集、不传输、不记录学号 / 身份证号 / 银行卡号 / 账号密码（契约 §1.1）。
4. 错误信息不得泄露堆栈、SQL、内部主机名或密钥（契约 §2.1 安全文案要求，骨架阶段同样适用）。
5. 日志不记录账号密码与身份证号（实施方案第十四章）。

## **4.4 可维护性**
1. Pytest 测试必须可运行：在 `backend/` 目录执行 `pytest -q` 全部通过（实施方案第十二章测试命令）。
2. 健康检查接口必须有对应自动化测试用例。
3. 服务启动时必须在控制台输出可读就绪信息（含监听地址与端口）。
4. 目录结构遵循实施方案第六章 `backend/` 规划，后续模块（api/schemas/services/models/db）按既有目录归位，避免返工。

## **4.5 兼容性**
1. 接口路径前缀必须为 `/api`，健康检查路径必须为 `GET /api/health`，与契约 §4.1 完全一致（契约是唯一权威，禁止偏差）。
2. 服务必须监听 **8000 端口**（Vite 代理与 Nginx 反代目标均为该端口的 backend 服务）。
3. 响应数据格式必须为 `application/json; charset=utf-8`，字符编码 UTF-8。
4. 未来 Docker Compose 启用 backend 段时，构建上下文必须为 `./backend`，服务名必须为 `backend`。
5. 开发与生产均不要求启用 CORS；若某环境确需直连跨域，仅允许显式白名单来源，禁止 `Access-Control-Allow-Origin: *` 与 `Allow-Credentials` 同时出现（契约 §1.3）。

# **5. 核心能力**

## **5.1 服务启动与配置装载**

### **5.1.1 业务规则**
1. **服务监听规则**：服务启动后必须监听 8000 端口并提供 `/api` 前缀路由。
   a. 验收条件（EARS）：When 服务启动完成，the Backend Skeleton shall 在 8000 端口接受 HTTP 请求。
2. **配置装载规则**：服务运行参数必须从环境变量（或本地 `.env`）装载，代码中不得硬编码真实密钥。
   a. 验收条件（EARS）：When 环境变量提供某配置项的值，the Backend Skeleton shall 以该值覆盖内置缺省值。
   b. 验收条件（EARS）：The Backend Skeleton shall 为每个配置项提供安全的内置缺省值以支持开箱即用的本地开发。
3. **敏感信息禁止项**：真实密钥禁止写入代码与版本库。
   a. 验收条件（EARS）：If 仓库中存在 `.env` 文件，the Backend Skeleton 的版本控制忽略规则 shall 确保其不被提交。
   b. 验收条件（EARS）：If 对交付代码进行密钥检查，the Backend Skeleton shall 不包含任何真实云密钥。
4. **无外部依赖启动规则**：骨架阶段服务启动不得强制连接 MySQL 或 AgentArts。
   a. 验收条件（EARS）：When 数据库与云服务均不可用，the Backend Skeleton shall 仍能成功启动并正常响应健康检查。

### **5.1.2 交互流程**

```plantuml
@startuml
actor "后端开发者" as Dev
participant "后端骨架" as BE

Dev -> BE : 执行启动（本地开发运行）
BE -> BE : 从环境变量 / .env 装载配置
BE --> Dev : 就绪（监听 8000 端口，控制台输出就绪信息）
Dev -> BE : GET /api/health（自测）
BE --> Dev : 200 {"status": "ok"}
@enduml
```

### **5.1.3 异常场景**
1. **配置值非法**
   a. 触发条件：环境变量提供非法值（如监听端口不是数字）。
   b. 系统行为：启动失败并退出，输出可读的配置错误说明。
   c. 用户感知：开发者看到明确的配置错误提示，不输出堆栈细节。
2. **端口被占用**
   a. 触发条件：8000 端口已被其他进程占用。
   b. 系统行为：启动失败并退出，输出端口冲突错误。
   c. 用户感知：开发者根据提示释放端口后重新启动。
3. **密钥环境变量缺失**
   a. 触发条件：本地开发未设置 `AGENTARTS_API_KEY` 等密钥变量。
   b. 系统行为：以占位缺省值启动，健康检查不受影响。
   c. 用户感知：服务正常就绪；真实密钥仅在未来接入云服务时才成为必需（属后续任务）。

## **5.2 服务健康自测**

### **5.2.1 业务规则**
1. **健康检查契约规则**：`GET /api/health` 必须返回 200 与 `{"status": "ok"}`（契约 §4.1）。
   a. 验收条件（EARS）：When 客户端发起 GET /api/health，the Backend Skeleton shall 返回 HTTP 200 与响应体 {"status": "ok"}。
2. **匿名访问规则**：健康检查无需任何认证信息。
   a. 验收条件（EARS）：The Backend Skeleton shall 允许匿名访问 GET /api/health。
3. **无副作用规则**：健康检查为只读探测，不改变任何服务状态、不依赖外部系统。
   a. 验收条件（EARS）：When 健康检查被重复调用任意次数，the Backend Skeleton shall 始终返回相同的响应结果。
4. **方法约束规则**：该路径仅支持 GET 方法。
   a. 验收条件（EARS）：If 客户端以非 GET 方法（如 POST）请求 /api/health，the Backend Skeleton shall 返回 HTTP 405。
5. **【决策点】未定义路径的错误体格式**：契约 §2.1 要求所有 4xx/5xx 响应统一为 `{"error": {"code", "message"}}`，而框架默认 404 返回 `{"detail": "Not Found"}`。骨架阶段（最简单起步）是否即实现统一错误响应结构，需评审确认；若推迟，404 暂用框架默认格式，统一错误处理随首个业务接口引入。
   a. 验收条件（EARS，若骨架阶段采纳）：If 客户端请求未定义路径，the Backend Skeleton shall 返回 HTTP 404 与 {"error": {"code": "INVALID_REQUEST", "message": <安全文案>}} 形式的错误体。
   b. 验收条件（EARS，若推迟）：If 客户端请求未定义路径，the Backend Skeleton shall 返回 HTTP 404，且错误体不泄露堆栈或内部信息。

### **5.2.2 交互流程**

```plantuml
@startuml
participant "前端应用" as FE
participant "后端骨架" as BE

FE -> BE : GET /api/health
BE --> FE : HTTP 200 {"status": "ok"}
note right of BE : 匿名访问，无外部依赖
FE -> FE : checkHealth() 判定后端可达
@enduml
```

### **5.2.3 异常场景**
1. **请求未定义路径**
   a. 触发条件：客户端请求 `/api` 下未注册的路径。
   b. 系统行为：返回 404（错误体格式见 5.2.1 规则 5 的决策点）。
   c. 用户感知：前端按契约提示"资源不存在"。
2. **服务不可达**
   a. 触发条件：后端未启动或网络不可达。
   b. 系统行为：无（服务不可达非本组件可处理范围）。
   c. 用户感知：前端 `client.ts` 产生本地错误 `TIMEOUT` / `NETWORK_ERROR`（契约 §2.4，不来自后端）。

## **5.3 骨架交付与测试保障**

### **5.3.1 业务规则**
1. **目录交付规则**：`backend/` 目录结构遵循实施方案第六章规划，关键目录与文件就位（应用入口、核心配置、测试目录），后续模块目录（api / schemas / services / models / db）留待对应任务创建，骨架阶段不预建空壳。
   a. 验收条件（EARS）：The Backend Skeleton shall 在 backend/ 下提供 FastAPI 应用入口、核心配置装载与测试目录三部分交付物。
2. **测试可运行规则**：Pytest 测试套件必须全部通过（实施方案第 3 周测试命令 `cd backend && pytest -q`）。
   a. 验收条件（EARS）：When 验收人员在 backend/ 目录执行 pytest -q，the Backend Skeleton 的测试套件 shall 全部通过且退出码为 0。
3. **健康检查覆盖规则**：健康检查接口必须有自动化测试。
   a. 验收条件（EARS）：The Backend Skeleton shall 包含至少 1 条针对 GET /api/health 的测试用例，断言状态码 200 与响应体 {"status": "ok"}。
4. **密钥零泄露规则**：交付代码中不存在真实密钥（第 3 周预期结果）。
   a. 验收条件（EARS）：The Backend Skeleton 的全部源码 shall 不包含任何真实云服务密钥。

### **5.3.2 交互流程**

```plantuml
@startuml
actor "验收人员" as Tester
participant "Pytest 测试套件" as TS
participant "后端骨架" as BE

Tester -> TS : 在 backend/ 目录执行 pytest -q
TS -> BE : 以测试客户端请求 GET /api/health
BE --> TS : 200 {"status": "ok"}
TS --> Tester : 全部通过（退出码 0）
@enduml
```

### **5.3.3 异常场景**
1. **测试失败**
   a. 触发条件：`pytest -q` 存在失败用例。
   b. 系统行为：测试框架输出失败详情，退出码非 0。
   c. 用户感知：开发者根据失败信息修复后重跑至全部通过。
2. **测试环境缺依赖**
   a. 触发条件：本机未安装 Python 3.12 或项目依赖未安装。
   b. 系统行为：测试命令报依赖缺失错误，不执行用例。
   c. 用户感知：按依赖清单安装后重跑。

# **6. 数据约束**

## **6.1 健康检查响应体**
1. **status**：字符串类型，固定取值 `"ok"`，必返回；响应体仅含该字段，不得额外携带堆栈、内部主机名等信息。

## **6.2 服务配置项**
1. **运行端口**：整数值，目标值 `8000`，与契约及编排约定一致，可被环境变量覆盖。
2. **运行环境标识**：字符串，区分本地开发与其他环境，缺省为本地开发（待定：具体枚举值在设计阶段确定）。
3. **数据库连接串**：字符串，本阶段仅装载不使用（数据库接入属后续任务），缺省为占位值；真实值只来自环境变量。
4. **AgentArts API Key**：字符串，本阶段仅装载不使用；必须来源于环境变量，禁止出现在代码与版本库。