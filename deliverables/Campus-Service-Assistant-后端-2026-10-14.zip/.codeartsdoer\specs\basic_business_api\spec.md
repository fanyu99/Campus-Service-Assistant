# 基础业务接口（basic_business_api）需求规格

> 依据：`docs/api.md`（前后端唯一权威契约，§2 错误处理 / §3.1 ServiceItem / §3.4 ConversationSummary / §3.5 标识符规范 / §3.6 FeedbackReasonCode / §4.2 / §4.4 / §4.5）、《校园办事小秘书实施方案》第十章接口规划 / 第六章目录规划 / 第 3 周计划后续清单 / 第十四章
> 技术栈约束（上游既定）：FastAPI + Pydantic v2 + SQLAlchemy 2 + Pytest（沿用 backend_skeleton 与 database_modeling 两个组件的既有约定）
> 任务范围：三个不依赖 AgentArts 云服务的基础接口——`GET /api/service-items`（查询支持事项）、`GET /api/conversations`（最近会话查询）、`POST /api/feedback`（反馈提交）的响应模型定义、路由实现（挂载到既有 `create_app`）、业务查询/写入逻辑与 Pytest 接口测试；**不含**问答接口 `POST /api/chat/messages`、AgentArts 适配层（属第 4 / 5 周）、前端页面接线
> 编制日期：2026-10-11

---

# **1. 组件定位**

## **1.1 核心职责**
本组件负责提供支持事项查询、匿名会话查询与反馈提交三个基础业务接口，实现前端页面脱离 mock 数据后的第一组真实数据能力。

## **1.2 核心输入**
1. **支持事项查询请求**：前端应用发起的 `GET /api/service-items` 请求（无查询参数，匿名访问）。
2. **最近会话查询请求**：前端应用发起的 `GET /api/conversations?limit=<n>` 请求（limit 可缺省；匿名标识的携带形式见 5.2.1 决策点）。
3. **反馈提交请求**：前端应用发起的 `POST /api/feedback` 请求，请求体含会话标识、是否有帮助、可选反馈原因码与可选短评。
4. **数据支撑输入**：数据库建模组件（database_modeling）已交付的四张表 ORM 模型、会话管理（`get_db` 依赖）与演示数据（S01–S08 事项）。
5. **测试触发**：开发者在 `backend/` 目录执行 Pytest 测试命令（`pytest -q`）。

## **1.3 核心输出**
1. **支持事项数组**：HTTP 200 与 `ServiceItem[]` 直接数组（无包装对象），字段映射契约 §3.1，仅含 `enabled = true` 的事项。
2. **会话列表响应**：HTTP 200 与 `{"conversations": [...], "total": N}` 包装对象，元素为契约 §3.4 会话摘要（六字段），按匿名标识隔离。
3. **反馈确认响应**：HTTP 200 与 `{"status": "ok"}`，反馈记录持久化到反馈表。
4. **统一错误响应**：失败时返回契约 §2.1 统一错误体 `{"error": {"code", "message"}}`，本组件新增业务错误码 `CONVERSATION_NOT_FOUND`（契约 §2.3）。
5. **测试结果**：Pytest 通过/失败报告（退出码 0 表示全部通过）。

## **1.4 职责边界**
本组件**不负责**以下事项（属后续任务或其他组件）：
1. 不实现问答接口 `POST /api/chat/messages` 与 AgentArts 适配层（属第 4 / 5 周）；问答链路的会话创建、更新与回答状态写入均不在本任务范围。
2. 不实现 `GET /api/knowledge/sources`（契约 §4.6"建议按需实现，不阻塞 P0"）。
3. 不做前端页面接线：六个页面仍使用 mock 数据；前端后续接线时补充匿名标识的传递（属前端任务）。
4. 不实现限流：`RATE_LIMITED` 错误码的触发场景均在问答链路（契约 §2.3），本任务不引入。
5. 不实现认证鉴权：原型阶段全部接口匿名访问（契约 §1.1）。
6. 不调整四张表的既有字段定义：仅为匿名隔离需求按版本化迁移约定补充匿名标识维度（见 5.4），其余表结构保持 database_modeling 交付物原样。
7. 不实现会话数据的写入路径：`conversations` 表的创建/更新属问答接口任务；本任务的会话查询为只读（演示数据由既有 seed 脚本与测试 fixtures 提供）。
8. 不引入问答链路错误码：`MESSAGE_TOO_LONG`、`UPSTREAM_TIMEOUT`、`UPSTREAM_ERROR` 均不在本任务范围。
9. 不修改 `docker-compose.yml` 与容器化改造（与既有组件约定一致）。

# **2. 领域术语**

**基础业务接口（Basic Business API）**
: 本任务交付的三个不依赖 AgentArts 云服务的接口集合：查询支持事项、查询最近会话、提交反馈。

**支持事项（ServiceItem）**
: 系统支持的办事事务在接口层的呈现，仅包含 `enabled = true` 的事项；字段映射契约 §3.1（`title` ← 数据库 `name` 列，`id` 由事项编码派生）。

**事项编码（item_code）**
: 事项的业务标识，格式为字母 `S` 加两位数字（`S01`–`S08`）；接口层的 `id`（kebab-case 前端 UI 标识）必须依据契约 §3.5 映射表由它派生。

**会话摘要（ConversationSummary)**
: `GET /api/conversations` 响应数组的元素，含随机会话标识、最近一次用户提问、最近识别事项、最近回答状态与两个时间戳共六个字段（契约 §3.4）。

**匿名标识（Session Token）**
: 调用方持有的不可预测标识，用于会话查询的隐私隔离；会话查询必须按它过滤，禁止返回全量会话或他人会话（契约 §4.4、OWASP A01）。

**待继续 / 已完成**
: 前端对会话摘要的派生展示状态：`result_status === 'need_clarification'` → 待继续，其余 → 已完成（契约 §3.4 定稿推导规则）；该推导由前端完成，后端只原样返回 `result_status`。

**反馈原因码（FeedbackReasonCode）**
: 用户反馈"没有帮助"时的原因分类，取值仅限 `SOURCE_ERROR` / `INCOMPLETE_STEPS` / `OUTDATED_CONTENT` / `OTHER` 四态，且允许缺省（契约 §3.6 / §4.5）。

# **3. 角色与边界**

## **3.1 核心角色**
前端开发者（成员二，交互与前端开发负责人）：联调阶段调用三个接口，消费 `ServiceItem[]`、会话列表与反馈确认响应。
后端开发者（成员三，智能体与后端架构负责人）：实现三个接口的响应模型、路由与业务逻辑，补充匿名标识维度迁移，运行 Pytest 测试。
测试与验收人员：依据第 3 周后续清单验收三接口的契约一致性、隐私隔离与测试通过。

## **3.2 外部系统**
前端应用（Vue 3 + Vite）：三个接口的唯一调用方；开发环境经 Vite 代理、生产经 Nginx 反代到后端 8000 端口。
MySQL 数据库（8.x）：查询 `service_items` 与 `conversations` 表，向 `feedback` 表写入反馈记录；经既有 `get_db` 会话依赖访问。
Git 版本库：接口代码与迁移脚本入库；`.env`（含数据库口令）保持忽略状态。

## **3.3 交互上下文**

```plantuml
@startuml
left to right direction
skinparam actorStyle awesome

actor "前端开发者\n（成员二）" as FrontDev
actor "后端开发者\n（成员三）" as Dev
actor "测试/验收人员" as Tester

rectangle "前端应用\n（Vue 3 + Vite，当前 mock 未接线）" as FE #F5F5F5
rectangle "Git 版本库" as Git #F5F5F5

rectangle "基础业务接口\n（Basic Business API）" as API #D6EAF8
database "MySQL 数据库\n（四张表 + 匿名标识维度）" as DB #E8F6EF

FrontDev --> FE : 联调消费三接口
FE --> API : GET /api/service-items\nGET /api/conversations（匿名标识）\nPOST /api/feedback
API --> DB : 事项查询 / 会话隔离查询\n反馈写入
Dev --> API : 实现接口 / 迁移 / 运行测试
Tester --> API : Pytest 验收测试
API --> Git : 代码与迁移脚本入库
@enduml
```

# **4. DFX约束**

## **4.1 性能**
1. 三个接口的响应时间均不得超过 1 秒（P95，本地开发环境、演示数据量级；须远低于前端 8 秒请求超时阈值，契约 §1.1）。
2. 反馈提交从校验到持久化完成的耗时不得超过 1 秒（同上环境）。
3. 原型阶段不设吞吐量指标（待定：正式指标随问答接口在设计阶段确定）。

## **4.2 可靠性**
1. 查询幂等：两个查询接口重复调用任意次数，必须返回相同结果（只读，无副作用）。
2. 反馈写入原子性：校验失败或会话不存在时不得产生任何落库记录；落库成功则记录完整（会话标识、是否有帮助、原因码、短评、提交时间齐备）。
3. 数据库不可用时：三个接口必须在 8 秒内返回 HTTP 500 统一错误体，不得挂起连接。
4. 回归保障：既有 `GET /api/health` 与统一错误处理器（404/405/422/500 静态映射）的行为不得因本任务改动而变化。

## **4.3 安全性**
1. **匿名隔离红线**：`GET /api/conversations` 禁止返回全量会话，禁止返回非当前匿名标识下的会话（契约 §4.4、OWASP A01）。
2. 匿名标识取值必须不可预测，禁止使用顺序数字等可枚举值作为隔离维度（契约 §3.4 会话标识的不可预测要求，同等级适用）。
3. 错误信息不得泄露堆栈、SQL、内部主机名或密钥（契约 §2.1 安全文案要求）。
4. 不采集、不传输、不记录学号 / 身份证号 / 银行卡号 / 账号密码（契约 §1.1、实施方案第十四章）；反馈短评为用户自愿输入，系统不得主动关联个人身份。
5. 日志不记录账号密码、身份证号与数据库口令（实施方案第十四章）。

## **4.4 可维护性**
1. Pytest 测试必须可运行：在 `backend/` 目录执行 `pytest -q` 全部通过且退出码为 0（实施方案第十二章）。
2. 三个接口均必须有自动化测试用例，覆盖正常路径与异常路径（参数校验失败、会话不存在、隔离行为）。
3. 测试必须复用既有 fixtures（应用客户端、内存 SQLite 数据库会话），不得引入第二套测试基建；接口路由的会话依赖须可被测试替换。
4. 目录归位遵循实施方案第六章 `backend/` 规划（api / schemas / services），避免返工。
5. 契约字段映射零转换：接口取数直接按契约字段映射读取列值（database_modeling 已保证表名列名与契约一致）。

## **4.5 兼容性**
1. 接口路径必须与契约逐字一致：`GET /api/service-items`、`GET /api/conversations`、`POST /api/feedback`（契约 §4.2 / §4.4 / §4.5）。
2. 响应结构必须与前端 `client.ts` 已定义类型一致：`ServiceItem[]` 直接数组、`{"conversations", "total"}` 包装对象、`{"status": "ok"}`。
3. 统一错误体结构延续契约 §2.1（`{"error": {"code", "message"}}`）；本组件新增错误码 `CONVERSATION_NOT_FOUND`（契约 §2.3），既有静态映射错误码行为不变。
4. 数据格式 `application/json; charset=utf-8`，字符编码 UTF-8；时间字段输出 ISO 8601 带时区格式（契约 §1.1）。
5. 匿名标识机制必须向后兼容：前端后续接线补充传递匿名标识时，接口契约与响应结构不得变更。

# **5. 核心能力**

## **5.1 查询支持事项（GET /api/service-items）**

### **5.1.1 业务规则**
1. **契约响应规则**：直接返回数组，不使用 `{items, total}` 包装；仅返回开放状态的事项（契约 §3.1 / §4.2）。
   a. 验收条件（EARS）：When 客户端发起 GET /api/service-items，the Basic Business API shall 返回 HTTP 200 与 ServiceItem 数组（直接数组，无包装对象）。
   b. 验收条件（EARS）：When 数据库存在开放状态为停用的事项，the Basic Business API shall 将其从响应中排除且不删除库中记录。
   c. 验收条件（EARS）：When 无任何开放状态的事项，the Basic Business API shall 返回 HTTP 200 与空数组（不得返回 404）。
2. **字段映射规则**：响应字段按契约 §3.1 映射——`title` 取自事项名称列，`description`、`category` 直取；`id` 由事项编码派生。
   a. 验收条件（EARS）：When 构造响应元素，the Basic Business API shall 输出 id、title、description、category 四个必返字段。
   b. 验收条件（EARS）：When 派生前端 UI 标识 id，the Basic Business API shall 使其与契约 §3.5 映射表逐项一致（S01→student-card、S02→campus-card、S03→repair、S04→leave、S05→scholarship、S06→grant、S07→major-transfer、S08→graduation）。
   c. 验收条件（EARS）：When 事项编码不在契约 §3.5 映射表覆盖范围内，the Basic Business API shall 按 kebab-case 规则派生 id（具体派生算法由设计阶段确定）。
3. **可选字段规则**：`icon`、`tone`、`prompt` 为契约非必返字段，且数据库表中无对应列（前端已有本地兜底）。
   a. 验收条件（EARS）：When 构造响应元素，the Basic Business API shall 不将 icon、tone、prompt 作为必返字段（输出形态见决策点）。
   b. **【决策点】可选字段输出形态**：方案 A（缺省建议）——响应仅含四个必返字段，icon/tone/prompt 不输出，前端本地兜底生效，不改表；方案 B——扩展事项表增加三列并返回真实值（需新增迁移）。契约 §3.1 将三字段标注为"否"（非必返）且明示 icon 有前端本地兜底，两方案均与契约兼容；缺省建议方案 A（最小起步、数据库已定稿不改表）。
4. **排序规则**：结果顺序必须稳定可测，按事项编码升序排列（与契约 §3.5 映射表顺序一致）。
   a. 验收条件（EARS）：When 返回多个事项，the Basic Business API shall 按事项编码升序排列。
5. **匿名访问规则**：本接口无需任何认证信息，不区分调用方。
   a. 验收条件（EARS）：The Basic Business API shall 允许匿名访问 GET /api/service-items。
6. **参数约束规则**：本接口不定义查询参数。
   a. 验收条件（EARS）：When 请求携带未定义的查询参数，the Basic Business API shall 忽略该参数并正常返回（不得报错）。

### **5.1.2 交互流程**

```plantuml
@startuml
actor "用户" as User
participant "前端应用" as FE
participant "基础业务接口" as API
database "MySQL 数据库" as DB

User -> FE : 打开首页/支持事项页
FE -> API : GET /api/service-items
API -> DB : 查询开放状态的事项\n（按事项编码升序）
DB --> API : 事项记录列表
API --> FE : 200 ServiceItem[]（直接数组）
FE -> FE : 按契约字段渲染事项卡片\n（icon 等用本地兜底）
@enduml
```

### **5.1.3 异常场景**
1. **数据库不可用**
   a. 触发条件：查询执行时数据库连接失败或超时。
   b. 系统行为：返回 HTTP 500 统一错误体（错误码 `INTERNAL_ERROR`），不输出数据库细节。
   c. 用户感知：前端展示"服务内部错误，请稍后重试"。
2. **请求方法错误**
   a. 触发条件：客户端以非 GET 方法请求 `/api/service-items`。
   b. 系统行为：返回 HTTP 405 统一错误体（既有静态映射）。
   c. 用户感知：前端按契约提示"请求方法不支持"。
3. **库中事项为空**
   a. 触发条件：数据库无任何开放状态的事项记录。
   b. 系统行为：返回 HTTP 200 与空数组。
   c. 用户感知：前端展示空列表状态（非错误）。

## **5.2 查询最近会话（GET /api/conversations）**

### **5.2.1 业务规则**
1. **契约响应规则**：返回包装对象 `{"conversations": [...], "total": N}`，元素为契约 §3.4 会话摘要（契约 §4.4）。
   a. 验收条件（EARS）：When 客户端发起 GET /api/conversations，the Basic Business API shall 返回 HTTP 200 与 {"conversations", "total"} 包装响应体。
2. **匿名隔离规则（隐私红线）**：必须按调用方匿名标识过滤，禁止全量返回（契约 §4.4、OWASP A01）。
   a. 验收条件（EARS）：When 请求携带匿名标识，the Basic Business API shall 仅返回该匿名标识下的会话记录。
   b. 验收条件（EARS）：When 请求未携带匿名标识，the Basic Business API shall 不返回任何会话记录（响应形态见决策点）。
   c. 验收条件（EARS）：When 匿名标识 A 的请求到达，the Basic Business API shall 不在响应中包含匿名标识 B 下的任何会话。
   d. **【决策点】匿名标识的传递形式与缺失行为**：传递形式——自定义请求头（如 `X-Session-Token`，缺省建议）或查询参数（如 `session_token`）；未携带时——返回 200 空列表与 total=0（缺省建议，前端历史页显示"暂无对话"，兼容未接线状态）或返回 400 `INVALID_REQUEST`（更早暴露接线缺口）。契约 §4.4 未定稿传递形式且前端 `fetchConversations` 当前不传匿名标识，两维度均由设计阶段确定；无论采纳何种组合，禁止返回任何会话记录的红线不可妥协。
3. **条数限制规则**：`limit` 查询参数缺省为 10，取值范围 1–50（契约 §4.4）。
   a. 验收条件（EARS）：When limit 缺省，the Basic Business API shall 最多返回 10 条会话摘要。
   b. 验收条件（EARS）：When limit 取值超出 1–50 范围（如 0、负数、大于 50 或非整数），the Basic Business API shall 返回 HTTP 422 统一错误体。
4. **排序规则**：按最近一条消息时间倒序排列（"最近会话"的业务语义；契约未明确定义，本规格依据语义定稿）。
   a. 验收条件（EARS）：When 返回多条会话，the Basic Business API shall 按最近一条消息时间倒序排列。
5. **摘要字段规则**：输出契约 §3.4 六字段；时间字段为 ISO 8601 带时区格式。
   a. 验收条件（EARS）：When 构造会话摘要，the Basic Business API shall 输出 id、question、last_intent、result_status、started_at、last_message_at 六个字段（不得省略）。
   b. 验收条件（EARS）：When 会话无最近识别事项，the Basic Business API shall 将 last_intent 输出为 null（而非省略字段）。
6. **状态原样返回规则**：`result_status` 为契约 §3.3 六态之一，原样返回；"待继续/已完成"推导由前端完成。
   a. 验收条件（EARS）：When 构造会话摘要，the Basic Business API shall 原样输出 result_status 枚举值，且不输出"待继续/已完成"派生字段。
7. **只读规则**：本接口为只读查询，不产生任何会话记录的创建或变更。
   a. 验收条件（EARS）：When 本接口被调用任意次数，the Basic Business API shall 不改变会话数据的内容与数量。

### **5.2.2 交互流程**

```plantuml
@startuml
actor "用户" as User
participant "前端应用" as FE
participant "基础业务接口" as API
database "MySQL 数据库" as DB

User -> FE : 打开最近记录页
FE -> API : GET /api/conversations?limit=10\n（携带匿名标识，形式见决策点）
API -> API : 匿名标识校验（缺失则空响应）
API -> DB : 按匿名标识过滤查询\n（按最近消息时间倒序，取 limit 条）
DB --> API : 会话记录列表
API --> FE : 200 {"conversations": [...], "total": N}
FE -> FE : 按 need_clarification 推导\n「待继续/已完成」并渲染
@enduml
```

### **5.2.3 异常场景**
1. **匿名标识缺失**
   a. 触发条件：请求未携带匿名标识（前端尚未接线时必然发生）。
   b. 系统行为：不查询任何会话数据，返回决策点确定的响应形态（缺省：200 与空列表、total=0）。
   c. 用户感知：前端历史页显示"暂无对话"，不报错。
2. **limit 参数非法**
   a. 触发条件：limit 为 0、负数、大于 50 或非整数。
   b. 系统行为：返回 HTTP 422 统一错误体（错误码 `INVALID_REQUEST`，既有静态映射）。
   c. 用户感知：前端提示修改输入。
3. **数据库不可用**
   a. 触发条件：查询执行时数据库连接失败或超时。
   b. 系统行为：返回 HTTP 500 统一错误体，不泄露数据库细节。
   c. 用户感知：前端展示重试提示。

## **5.3 提交反馈（POST /api/feedback）**

### **5.3.1 业务规则**
1. **契约请求规则**：会话标识与是否有帮助为必填；反馈原因码与短评为可选（契约 §4.5）。
   a. 验收条件（EARS）：When 请求体缺少会话标识或是否有帮助字段，the Basic Business API shall 返回 HTTP 422 统一错误体。
   b. 验收条件（EARS）：When 短评超过 200 字，the Basic Business API shall 返回 HTTP 422 统一错误体。
2. **原因码枚举规则**：反馈原因码取值仅限四态（`SOURCE_ERROR` / `INCOMPLETE_STEPS` / `OUTDATED_CONTENT` / `OTHER`），且允许缺省；"没有帮助"时建议提供而非强制（契约 §3.6 / §4.5）。
   a. 验收条件（EARS）：When 反馈原因码缺省（无论是否有帮助取值如何），the Basic Business API shall 接受该反馈且原因码落库为空。
   b. 验收条件（EARS）：When 反馈原因码取值在四态之外，the Basic Business API shall 返回 HTTP 422 统一错误体。
3. **会话存在性校验规则**：反馈必须关联已存在的会话（数据库建模组件已定稿外键严格校验策略）。
   a. 验收条件（EARS）：When 会话标识在会话表中不存在，the Basic Business API shall 返回 HTTP 404 与错误码 CONVERSATION_NOT_FOUND（契约 §2.3），且不产生落库记录。
4. **反馈写入规则**：校验通过后追加独立反馈记录，提交时间由服务端生成；同一会话允许多次提交（契约未定义去重，按表结构自增主键语义定稿为追加）。
   a. 验收条件（EARS）：When 反馈通过全部校验，the Basic Business API shall 持久化包含会话标识、是否有帮助、原因码（可空）、短评（可空）与提交时间的完整记录。
   b. 验收条件（EARS）：When 同一会话被重复提交反馈，the Basic Business API shall 生成相互独立的反馈记录（不去重合并）。
5. **响应规则**：成功返回 HTTP 200 与 `{"status": "ok"}`（契约 §4.5）。
   a. 验收条件（EARS）：When 反馈成功持久化，the Basic Business API shall 返回 HTTP 200 与 {"status": "ok"}。
6. **匿名访问规则**：本接口无需任何认证信息。
   a. 验收条件（EARS）：The Basic Business API shall 允许匿名访问 POST /api/feedback。

### **5.3.2 交互流程**

```plantuml
@startuml
actor "用户" as User
participant "前端应用" as FE
participant "基础业务接口" as API
database "MySQL 数据库" as DB

User -> FE : 在反馈栏选择「有帮助/无帮助」\n（无帮助时可附原因码与短评）
FE -> API : POST /api/feedback\n{conversation_id, helpful, reason_code?, comment?}
API -> API : 请求体校验（必填/枚举/长度）
API -> DB : 会话存在性检查
DB --> API : 会话存在
API -> DB : 追加反馈记录（含服务端提交时间）
API --> FE : 200 {"status": "ok"}
FE -> FE : 展示反馈成功状态
@enduml
```

### **5.3.3 异常场景**
1. **字段校验失败**
   a. 触发条件：缺少必填字段、原因码在四态之外、短评超过 200 字或请求体不是合法 JSON。
   b. 系统行为：返回 HTTP 422 统一错误体，不产生落库记录。
   c. 用户感知：前端提示修改输入。
2. **会话不存在**
   a. 触发条件：会话标识在会话表中无对应记录。
   b. 系统行为：返回 HTTP 404 与错误码 `CONVERSATION_NOT_FOUND`，不产生落库记录。
   c. 用户感知：前端按契约提示"资源不存在"并重置会话。
3. **数据库不可用**
   a. 触发条件：写入执行时数据库连接失败或超时。
   b. 系统行为：返回 HTTP 500 统一错误体，写入失败不产生半写入记录。
   c. 用户感知：前端展示重试提示，用户可重新提交。

## **5.4 会话匿名标识支撑（数据层前置）**

### **5.4.1 业务规则**
1. **匿名标识维度规则**：会话数据必须携带匿名标识维度，支撑 5.2 的隔离查询（契约 §4.4；数据库建模规格 5.1.1 规则 7 预留该维度、落库形式待定）。
   a. 验收条件（EARS）：The Basic Business API shall 为会话数据提供匿名标识维度，使 5.2 能按匿名标识隔离查询而不暴露他人数据。
2. **迁移方式规则**：若既有会话表不包含该维度，必须通过版本化迁移补充，遵循数据库建模组件的迁移约定（可升级可回滚、禁止手工改表）。
   a. 验收条件（EARS）：When 既有会话表结构不包含匿名标识维度，the Basic Business API shall 通过新增版本化迁移补充该维度，且迁移可升级亦可回滚。
   b. 验收条件（EARS）：When 迁移执行后，the Basic Business API shall 保持既有四张表的既有字段定义与既有测试不变（回归保障）。
3. **不可预测规则**：匿名标识取值必须不可预测，禁止顺序数字等可枚举值（契约 §3.4 不可预测要求，OWASP A01）。
   a. 验收条件（EARS）：When 定义匿名标识维度的取值形态，the Basic Business API shall 保证其不可被枚举推算。
4. **写入路径归属规则**：匿名标识的写入路径（会话创建时落库调用方标识）属问答接口任务（第 5 周）；本任务交付该维度的定义与查询侧消费，演示数据与测试 fixtures 可预置标识值。
   a. 验收条件（EARS）：The Basic Business API shall 在查询侧按匿名标识过滤，且不实现会话创建时的标识写入路径。

### **5.4.2 交互流程**

```plantuml
@startuml
actor "后端开发者" as Dev
participant "基础业务接口" as API
database "MySQL 数据库" as DB

Dev -> API : 定义匿名标识维度并执行迁移
API -> DB : 版本化迁移（可升级/可回滚）
DB --> API : 会话表携带匿名标识维度
Dev -> API : 预置演示数据 / 测试 fixtures 标识值
API -> DB : 查询侧按匿名标识过滤（供 5.2 消费）
note right of API : 标识写入路径（会话创建时）\n属第 5 周问答接口任务
@enduml
```

### **5.4.3 异常场景**
1. **迁移执行失败**
   a. 触发条件：迁移命令执行报错（如数据库不可达）。
   b. 系统行为：迁移中止，数据库保持迁移前状态，输出可读错误（不含口令）。
   c. 用户感知：开发者修复连接后重试，不影响既有接口。
2. **迁移后兼容性破坏**
   a. 触发条件：迁移引入的变更影响了既有字段或既有测试。
   b. 系统行为：不得交付——既有测试套件必须全部通过方可合入。
   c. 用户感知：无（开发阶段拦截）。
3. **存量数据无匿名标识**
   a. 触发条件：补充维度前已存在的会话记录该维度为空。
   b. 系统行为：空标识记录不归属任何匿名标识，隔离查询不得将其返回（防止存量数据泄露）。
   c. 用户感知：无（存量演示数据在 seed 中预置标识值）。

# **6. 数据约束**

## **6.1 ServiceItem 响应元素**
1. **id**：字符串，kebab-case 前端 UI 标识，必返回；必须与契约 §3.5 映射表逐项一致（S01→student-card 等 8 项），映射表未覆盖的编码按 kebab-case 规则派生。
2. **title**：字符串非空，取自数据库事项名称列（上限 128 字），必返回。
3. **description**：字符串，取自数据库简要说明列（上限 255 字），必返回。
4. **category**：字符串，取自数据库类别列（上限 32 字），必返回。
5. **icon / tone / prompt**：契约非必返字段（数据库无对应列）；输出形态见 5.1.1 决策点；`tone` 若输出则取值仅限 `orange` / `blue` / `green` / `purple`。

## **6.2 ConversationSummary 响应元素**
1. **id**：字符串，随机会话标识（UUID 形态，36 位），不可预测，必返回。
2. **question**：字符串非空，该会话最近一次用户提问。
3. **last_intent**：字符串或 null，取值仅限 `S01`–`S08` 或空；无识别事项时显式输出 null。
4. **result_status**：字符串，取值仅限契约 §3.3 六态（`answered` / `need_clarification` / `unsupported` / `insufficient_evidence` / `conflict` / `service_error`）。
5. **started_at**：ISO 8601 带时区时间戳（如 `2026-09-27T09:42:00+08:00`）。
6. **last_message_at**：ISO 8601 带时区时间戳，格式同上。

## **6.3 会话列表响应体**
1. **conversations**：数组，元素为会话摘要（6.2），可为空数组；按最近消息时间倒序排列，条数受 limit 约束。
2. **total**：非负整数；语义见 5.2.1 决策点（该匿名标识下会话总数 / 本次返回条数）。

## **6.4 反馈请求体**
1. **conversation_id**：字符串非空，必填；取值必须为已存在会话的标识。
2. **helpful**：布尔，必填；表示回答是否有帮助。
3. **reason_code**：字符串或 null，可空；取值仅限 `SOURCE_ERROR` / `INCOMPLETE_STEPS` / `OUTDATED_CONTENT` / `OTHER` 四态。
4. **comment**：字符串或 null，可空；长度不超过 200 字。

## **6.5 反馈响应体**
1. **status**：字符串，固定取值 `"ok"`；响应体仅含该字段，不得携带额外信息。

## **6.6 查询参数 limit**
1. **limit**：整数，缺省 10；取值范围 1–50（含边界）；超出范围返回 HTTP 422。